# Lista de Verificación para Enterprise Architect

## ✅ Pre-Importación

### Archivos Preparados
- [ ] `epi-01-users.puml` - 6 HUs, 6 use cases
- [ ] `epi-02-search.puml` - 6 HUs, 6 use cases  
- [ ] `epi-03-comparison.puml` - 7 HUs, 7 use cases
- [ ] `epi-04-reviews.puml` - 2 HUs, 2 use cases
- [ ] `epi-05-bookings.puml` - 4 HUs, 6 use cases
- [ ] `epi-06-ai.puml` - 4 HUs, 4 use cases
- [ ] `epi-07-providers.puml` - 8 HUs, 9 use cases
- [ ] `epi-08-admin.puml` - 11 HUs, 12 use cases
- [ ] `system-complete.puml` - Vista sistema completo
- [ ] `class-diagram.puml` - Modelo de datos

### Documentación de Soporte
- [ ] `README_ENTERPRISE_ARCHITECT.md` - Guía de importación
- [ ] `historias_de_usuario.md` - 48 HUs detalladas
- [ ] `ANALISIS_COBERTURA_REQUERIMIENTOS.md` - Análisis 82 requisitos
- [ ] `requerimientos.txt` - Requisitos originales

---

## 🎯 Durante la Importación

### Paso 1: Configuración Inicial
- [ ] Enterprise Architect instalado y funcionando
- [ ] Plugin PlantUML para EA instalado (si aplica)
- [ ] Proyecto EA creado o seleccionado
- [ ] Carpeta/paquete raíz "Alto Carwash" creada

### Paso 2: Importación de Paquetes (Épicas)
- [ ] EPI-01: Usuarios y Autenticación importado
- [ ] EPI-02: Búsqueda y Filtrado importado
- [ ] EPI-03: Comparación de Precios importado
- [ ] EPI-04: Reseñas y Calificaciones importado
- [ ] EPI-05: Gestión de Reservas importado
- [ ] EPI-06: Análisis IA importado
- [ ] EPI-07: Gestión de Proveedores importado
- [ ] EPI-08: Administración y DevOps importado

### Paso 3: Verificación de Actores
#### Actores Humanos (<<Human>>)
- [ ] Cliente/Usuario
- [ ] Proveedor
- [ ] Administrador

#### Sistemas Externos (<<External System>>)
- [ ] Clerk Auth
- [ ] Google Maps API
- [ ] OpenAI API
- [ ] Email Service (Resend)
- [ ] Notification Service
- [ ] Payment Gateway
- [ ] SII API
- [ ] Image Service
- [ ] Geocoding Service

#### Bases de Datos (<<Database>>)
- [ ] PostgreSQL Database
- [ ] Redis Cache

#### Sistemas Internos (<<System>>)
- [ ] Analytics Service
- [ ] Audit Logger
- [ ] Backup Service
- [ ] CI/CD Pipeline
- [ ] Testing Framework
- [ ] Scheduler

### Paso 4: Verificación de Casos de Uso por Épica

#### EPI-01: Usuarios y Autenticación (6 UC)
- [ ] UC-001: Registrar Usuario (HU-001) - 5 pts
- [ ] UC-002: Iniciar Sesión (HU-002) - 3 pts
- [ ] UC-003: Actualizar Perfil (HU-003) - 3 pts
- [ ] UC-016: Configurar MFA/2FA (HU-004) - 8 pts
- [ ] UC-036: Implementar Accesibilidad WCAG (HU-037) - 13 pts
- [ ] UC-039: Preferencias de Búsqueda (HU-039) - 3 pts

#### EPI-02: Búsqueda y Filtrado (6 UC)
- [ ] UC-004: Búsqueda Geolocalizada (HU-005) - 13 pts
- [ ] UC-005: Filtrar Resultados (HU-006) - 5 pts
- [ ] UC-006: Ordenar Resultados (HU-007) - 3 pts
- [ ] UC-007: Ver en Mapa (HU-008) - 8 pts
- [ ] UC-040: PWA Offline (HU-040) - 13 pts
- [ ] UC-041: Deep Links (HU-041) - 5 pts

#### EPI-03: Comparación de Precios (7 UC)
- [ ] UC-013: Comparar Proveedores (HU-015) - 13 pts
- [ ] UC-014: Gestionar Favoritos (HU-016) - 5 pts
- [ ] UC-031: Alertas de Precios (HU-031) - 8 pts
- [ ] UC-033: Histórico de Precios (HU-033) - 8 pts
- [ ] UC-034: Calculadora de Ahorro (HU-034) - 5 pts
- [ ] UC-035: Exportar PDF (HU-035) - 5 pts
- [ ] UC-036: Compartir Comparación (HU-036) - 3 pts

#### EPI-04: Reseñas (2 UC)
- [ ] UC-019: Escribir Reseña (HU-013) - 8 pts
- [ ] UC-020: Responder Reseña (HU-014) - 5 pts

#### EPI-05: Reservas (6 UC)
- [ ] UC-021: Crear Reserva (HU-009) - 8 pts
- [ ] UC-022: Ver Mis Reservas (HU-010) - 5 pts
- [ ] UC-023: Cancelar Reserva (HU-011) - 5 pts
- [ ] UC-024: Modificar Reserva (HU-012) - 8 pts
- [ ] UC-025: Confirmar/Rechazar (Proveedor) - 5 pts
- [ ] UC-026: Completar Reserva (Proveedor) - 3 pts

#### EPI-06: Análisis IA (4 UC)
- [ ] UC-033: Análisis Inteligente Proveedor (HU-019) - 8 pts
- [ ] UC-034: Resumen Reseñas IA (HU-020) - 5 pts
- [ ] UC-035: Recomendaciones Personalizadas (HU-021) - 8 pts
- [ ] UC-045: Actualización Auto Precios (HU-045) - 13 pts

#### EPI-07: Proveedores (9 UC)
- [ ] UC-036: Registrar Proveedor (HU-022) - 13 pts
- [ ] UC-037: Gestionar Servicios (HU-023) - 8 pts
- [ ] UC-038: Configurar Disponibilidad (HU-024) - 5 pts
- [ ] UC-039: Ver Estadísticas Proveedor (HU-025) - 8 pts
- [ ] UC-040: Gestionar Reservas Proveedor - 5 pts
- [ ] UC-041: Actualizar Perfil Proveedor - 5 pts
- [ ] UC-042: Gestionar Imágenes (HU-024) - 5 pts
- [ ] UC-032: Importar CSV Proveedores (HU-032) - 8 pts
- [ ] UC-043: Categorización Avanzada (HU-043) - 5 pts
- [ ] UC-044: Métricas de Visualización (HU-044) - 5 pts

#### EPI-08: Admin y DevOps (12 UC)
- [ ] UC-043: Verificar Proveedores (HU-026) - 8 pts
- [ ] UC-044: Gestionar Usuarios (HU-028) - 8 pts
- [ ] UC-045: Moderar Contenido - 8 pts
- [ ] UC-046: Configurar Sistema (HU-029) - 5 pts
- [ ] UC-047: Dashboard Admin (HU-027) - 13 pts
- [ ] UC-048: Generar Reportes - 8 pts
- [ ] UC-037: Accesibilidad WCAG (HU-037) - 13 pts
- [ ] UC-038: Testing Automatizado (HU-038) - 13 pts
- [ ] UC-042: CI/CD Pipeline (HU-042) - 8 pts
- [ ] UC-046-API: API Pública Documentada (HU-046) - 8 pts
- [ ] UC-047-B: Backup Automático (HU-047) - 5 pts
- [ ] UC-048-A: Audit Trail (HU-048) - 8 pts

### Paso 5: Verificación de Relaciones

#### Tipos de Relaciones
- [ ] Association (→): Actores a Use Cases
- [ ] Include (..> <<include>>): Dependencias obligatorias
- [ ] Extend (..> <<extend>>): Extensiones opcionales  
- [ ] Use (..> <<use>>): Uso de servicios externos
- [ ] Notify (..> <<notify>>): Notificaciones
- [ ] Cache (..> <<cache>>): Operaciones de caché

#### Relaciones Clave a Verificar
- [ ] Cliente → Búsqueda Geolocalizada
- [ ] Búsqueda → Google Maps API
- [ ] Crear Reserva → Email Service
- [ ] Análisis IA → OpenAI API
- [ ] Registro Proveedor → Verificación Admin
- [ ] Testing → CI/CD Pipeline

---

## 📋 Post-Importación

### Verificación de Propiedades

#### Para cada Use Case verificar:
- [ ] Nombre completo (UC-XXX: Descripción)
- [ ] Alias/Tagged Value con código HU (HU-XXX)
- [ ] Story Points documentados
- [ ] Prioridad asignada (Must/Should/Could)
- [ ] Descripción funcional completa
- [ ] Punto de entrada (URL/ruta)
- [ ] Requerimientos relacionados (REQ-XX)
- [ ] Criterios de aceptación
- [ ] Restricciones técnicas

### Trazabilidad de Requerimientos

#### Crear Requirement Elements
- [ ] REQ-001 a REQ-050 (Funcionales)
- [ ] REQ-051 a REQ-082 (No Funcionales)

#### Establecer Trace Relationships
- [ ] Todos los Must Have (26 HUs) trazados
- [ ] Todos los Should Have (15 HUs) trazados
- [ ] Todos los Could Have (7 HUs) trazados

### Diagrama de Clases

#### Entidades Core
- [ ] User (id, clerkId, email, name, role, etc.)
- [ ] Provider (id, businessName, rut, address, etc.)
- [ ] Service (id, providerId, name, price, duration, etc.)
- [ ] Booking (id, userId, serviceId, status, etc.)
- [ ] Review (id, bookingId, rating, comment, etc.)

#### Entidades Nuevas v3.0
- [ ] PriceAlert (id, userId, serviceId, targetPrice, etc.)
- [ ] PriceHistory (id, serviceId, price, recordedAt, etc.)
- [ ] UserPreferences (id, userId, defaultRadius, etc.)
- [ ] Tag (id, name, category, etc.)
- [ ] ProviderTag (providerId, tagId)
- [ ] ViewMetrics (id, providerId, views, clicks, etc.)
- [ ] AuditLog (id, userId, action, before, after, etc.)

#### Relaciones Verificadas
- [ ] User 1:N Booking
- [ ] User 1:N Review
- [ ] User 1:N PriceAlert
- [ ] User 1:1 UserPreferences
- [ ] Provider 1:N Service
- [ ] Provider 1:N Booking
- [ ] Provider N:M Tag
- [ ] Service 1:N Booking
- [ ] Service 1:N PriceHistory

---

## 📊 Métricas Finales

### Conteo de Elementos
- [ ] **Total Épicas:** 8
- [ ] **Total HUs:** 48 (30 originales + 18 nuevas)
- [ ] **Total Story Points:** 354
- [ ] **Total Use Cases:** 48+
- [ ] **Total Actores:** ~15
- [ ] **Total Requerimientos:** 82 (50 func + 32 no-func)
- [ ] **Cobertura:** 90.2% (74/82 req)

### Distribución por Prioridad
- [ ] Must Have: 26 HUs (180 pts)
- [ ] Should Have: 15 HUs (121 pts)
- [ ] Could Have: 7 HUs (53 pts)

### Distribución por Épica
- [ ] EPI-01: 6 HUs (35 pts)
- [ ] EPI-02: 6 HUs (47 pts)
- [ ] EPI-03: 7 HUs (47 pts)
- [ ] EPI-04: 2 HUs (13 pts)
- [ ] EPI-05: 4 HUs (26 pts)
- [ ] EPI-06: 4 HUs (34 pts)
- [ ] EPI-07: 8 HUs (73 pts)
- [ ] EPI-08: 11 HUs (79 pts)

---

## 🎨 Presentación y Documentación

### Diagramas Generados
- [ ] Use Case Diagram por épica (8 diagramas)
- [ ] System Context Diagram (vista completa)
- [ ] Class Diagram (modelo de datos)
- [ ] Traceability Matrix (req → HU → UC)

### Reportes EA
- [ ] Requirements Coverage Report
- [ ] Use Case Specification Report
- [ ] Actor-Use Case Matrix
- [ ] Traceability Report
- [ ] Metrics Dashboard

### Exports
- [ ] PDF de todos los diagramas
- [ ] RTF/Word de especificaciones
- [ ] Excel de trazabilidad
- [ ] HTML navegable

---

## ✨ Validación Final

### Checklist Crítico
- [ ] Todos los diagramas visibles y navegables
- [ ] Todas las HUs tienen UC correspondiente
- [ ] Todos los UC tienen requisito trazado
- [ ] Todos los actores tienen conexiones
- [ ] Todas las relaciones correctamente etiquetadas
- [ ] Modelo de clases completo y consistente
- [ ] Metadata de épicas presente
- [ ] Story points sumados correctamente
- [ ] Prioridades asignadas a todos los elementos
- [ ] Documentación anexa referenciada

### Prueba de Navegación
- [ ] Desde Requerimiento → HU → UC → Actor
- [ ] Desde Épica → UC → Relaciones
- [ ] Desde Actor → Use Cases que participa
- [ ] Desde Clase → Relaciones con otras clases

---

## 📝 Notas Finales

**Fecha de Verificación:** ___________  
**Verificador:** ___________  
**Versión EA:** ___________  
**Estado:** ⬜ Completo ⬜ Parcial ⬜ Pendiente

**Observaciones:**
```
[Espacio para notas del verificador]
```

**Problemas Encontrados:**
```
[Espacio para documentar issues]
```

**Próximos Pasos:**
```
[Acciones pendientes post-importación]
```

---

**Documento creado:** 21 de Octubre de 2025  
**Última revisión:** 21 de Octubre de 2025  
**Versión:** 1.0
