# Guía de Importación a Enterprise Architect

## 📋 Resumen del Proyecto

**Nombre:** Alto Carwash - Plataforma de Comparación y Reserva de Carwash  
**Versión:** 3.0  
**Fecha:** 21 de Octubre de 2025  
**Cobertura de Requerimientos:** 90.2% (74/82 requisitos)  
**Total de Historias de Usuario:** 48 (354 story points)

---

## 📁 Archivos PlantUML Incluidos

### Diagramas de Casos de Uso por Épica

| Archivo | Épica | HUs | Use Cases | Descripción |
|---------|-------|-----|-----------|-------------|
| `epi-01-users.puml` | Usuarios y Autenticación | HU-001 a HU-004, HU-037, HU-039 | UC-001 a UC-016, UC-036, UC-039 | Registro, login, perfiles, autenticación 2FA, accesibilidad WCAG, preferencias de búsqueda |
| `epi-02-search.puml` | Búsqueda y Filtrado | HU-005 a HU-008, HU-040, HU-041 | UC-004 a UC-009, UC-040, UC-041 | Búsqueda geolocalizada, filtros, ordenamiento, PWA offline, deep links |
| `epi-03-comparison.puml` | Comparación de Precios | HU-015, HU-016, HU-031, HU-033, HU-034, HU-035, HU-036 | UC-013, UC-014, UC-031, UC-033, UC-034, UC-035, UC-036 | Comparativa, favoritos, alertas de precios, histórico, ahorro, PDF, compartir |
| `epi-04-reviews.puml` | Reseñas y Calificaciones | HU-013, HU-014 | UC-019, UC-020 | Sistema de reviews, respuestas, moderación |
| `epi-05-bookings.puml` | Gestión de Reservas | HU-009 a HU-012 | UC-021 a UC-026 | Reservas, cancelaciones, modificaciones, historial |
| `epi-06-ai.puml` | Análisis IA | HU-019, HU-020, HU-021, HU-045 | UC-033, UC-034, UC-035, UC-045 | IA análisis, resumen reviews, recomendaciones, actualización automática precios |
| `epi-07-providers.puml` | Gestión de Proveedores | HU-022 a HU-025, HU-032, HU-043, HU-044 | UC-036 a UC-044 | Registro proveedor, servicios, disponibilidad, import CSV, tags, métricas |
| `epi-08-admin.puml` | Administración y DevOps | HU-026 a HU-030, HU-037, HU-038, HU-042, HU-046, HU-047, HU-048 | UC-043 a UC-048 | Admin dashboard, verificación, configuración, testing, CI/CD, API docs, backups, audit |

### Diagramas del Sistema

| Archivo | Tipo | Descripción |
|---------|------|-------------|
| `system-complete.puml` | Sistema Completo | Vista integral con todos los actores y use cases del sistema |
| `class-diagram.puml` | Modelo de Datos | Diagrama de clases con entidades, relaciones y atributos |

---

## 🚀 Pasos para Importar a Enterprise Architect

### Opción 1: Importación Directa de PlantUML

1. **Abrir Enterprise Architect**
   - Crear un nuevo proyecto o abrir uno existente

2. **Importar PlantUML**
   - Ir a `Extensions` → `PlantUML` → `Import PlantUML File`
   - Seleccionar los archivos `.puml` del directorio `docs/plantuml/`
   - EA generará automáticamente los diagramas

3. **Verificar Elementos**
   - Los actores con estereotipos `<<Human>>`, `<<External System>>`, `<<Database>>`, `<<System>>` deberían ser reconocidos
   - Los casos de uso deberían aparecer en paquetes organizados
   - Las relaciones `<<include>>`, `<<extend>>`, `<<use>>` deberían estar mapeadas

### Opción 2: Importación Manual de Casos de Uso

Si la importación directa falla, seguir estos pasos:

#### 2.1. Crear Paquetes (Packages)

Crear un paquete principal "Alto Carwash" con los siguientes sub-paquetes:
- `EPI-01: Usuarios y Autenticación`
- `EPI-02: Búsqueda y Filtrado`
- `EPI-03: Comparación de Precios`
- `EPI-04: Reseñas y Calificaciones`
- `EPI-05: Gestión de Reservas`
- `EPI-06: Análisis IA`
- `EPI-07: Gestión de Proveedores`
- `EPI-08: Administración y DevOps`

#### 2.2. Crear Actores

Para cada paquete, crear los actores correspondientes según esta tabla:

| Actor | Estereotipo | Descripción |
|-------|-------------|-------------|
| Cliente | Human | Usuario final de la plataforma |
| Proveedor | Human | Dueño de carwash |
| Administrador | Human | Admin del sistema |
| Clerk Auth | External System | Sistema de autenticación |
| Google Maps API | External System | Geolocalización y mapas |
| OpenAI API | External System | IA generativa |
| Email Service | External System | Envío de emails |
| Notification Service | External System | Push notifications |
| Payment Gateway | External System | Procesador de pagos |
| Database | Database | PostgreSQL + PostGIS |
| Redis Cache | Database | Cache y sesiones |
| Analytics Service | System | Servicio de métricas |
| Audit Logger | System | Sistema de auditoría |
| Backup Service | System | Servicio de backups |
| CI/CD Pipeline | System | GitHub Actions |

#### 2.3. Crear Casos de Uso

Para cada paquete, crear los casos de uso listados en el diagrama correspondiente.

**Ejemplo para EPI-01:**
- UC-001: Registrar Usuario (HU-001)
- UC-002: Iniciar Sesión (HU-002)
- UC-003: Actualizar Perfil (HU-003)
- UC-016: Configurar MFA/2FA (HU-004)
- UC-036: Implementar Accesibilidad WCAG (HU-037)
- UC-039: Configurar Preferencias Búsqueda (HU-039)

#### 2.4. Crear Relaciones

**Tipos de relaciones:**
- **Association** (→): Actor hacia Use Case (participación)
- **Include** (..>): Use Case que incluye otro obligatoriamente
- **Extend** (..>): Use Case que extiende otro opcionalmente
- **Dependency** (..>): Uso de servicios externos

#### 2.5. Agregar Notas y Propiedades

Para cada Use Case, agregar:
- **Nombre:** Código UC + Nombre descriptivo
- **Alias:** Código de Historia de Usuario (ej: HU-001)
- **Prioridad:** Must / Should / Could / Won't
- **Complejidad:** Story Points (1, 2, 3, 5, 8, 13, 21)
- **Descripción:** Funcionalidad detallada
- **Pre-condiciones:** Entrada del sistema
- **Post-condiciones:** Resultado esperado
- **Requerimientos:** IDs de requisitos (REQ-XX)

---

## 📊 Trazabilidad de Requerimientos

### Mapeo de Requerimientos a Historias de Usuario

Usar la siguiente tabla para establecer trazabilidad en EA:

| Requerimiento | Tipo | HU Relacionadas | Prioridad |
|---------------|------|-----------------|-----------|
| REQ-1 | Funcional | HU-001 | Must |
| REQ-2 | Funcional | HU-002, HU-004 | Must |
| REQ-3 | Funcional | HU-003 | Must |
| REQ-4 | Funcional | HU-005 | Must |
| REQ-5 | Funcional | HU-005 | Must |
| REQ-6 | Funcional | HU-031 | Should |
| REQ-7 | Funcional | HU-006, HU-007, HU-008 | Must |
| REQ-8 | Funcional | HU-015, HU-016 | Must |
| REQ-9 | Funcional | HU-009 | Must |
| REQ-10 | Funcional | HU-010, HU-011 | Must |
| REQ-11 | Funcional | HU-010 | Must |
| REQ-12 | Funcional | HU-013 | Must |
| REQ-13 | Funcional | HU-014 | Should |
| REQ-14 | Funcional | HU-032 | Should |
| REQ-15 | Funcional | HU-022, HU-026 | Must |
| REQ-16 | Funcional | HU-045 | Should |
| REQ-17 | Funcional | HU-027 | Must |
| REQ-18 | Funcional | HU-043, HU-044 | Should |
| REQ-19 | Funcional | HU-015 | Must |
| REQ-20 | Funcional | HU-015 | Must |
| REQ-21, REQ-22 | Funcional | HU-019, HU-020, HU-021 | Should/Could |
| REQ-30, REQ-31, REQ-32 | Funcional | HU-033, HU-034, HU-035, HU-036 | Should |
| REQ-35 | Funcional | HU-046 | Should |
| REQ-40, REQ-41 | Funcional | HU-040, HU-041 | Must |
| REQ-51 | No Funcional | HU-002, HU-004 | Must |
| REQ-52, REQ-53, REQ-54 | No Funcional | Arquitectura | Must |
| REQ-62, REQ-67 | No Funcional | HU-028, HU-048 | Must |
| REQ-66 | No Funcional | HU-047 | Must |
| REQ-72 | No Funcional | HU-037 | Must |
| REQ-75 | No Funcional | HU-040 | Must |
| REQ-76 | No Funcional | HU-027, HU-046 | Should |
| REQ-79 | No Funcional | HU-042 | Must |
| REQ-80 | No Funcional | HU-029 | Must |
| REQ-82 | No Funcional | HU-038 | Must |

**Requerimientos sin cobertura directa (10):**
- REQ-23 a REQ-29: Features de búsqueda/agregación (parcialmente en scraper)
- REQ-33, REQ-34: API externa sin especificar
- REQ-36 a REQ-39: Features avanzadas análisis precios (potenciales HU futuras)

---

## 🏗️ Modelo de Datos (Clase Diagram)

### Entidades Principales

**Core Entities:**
- `User` - Usuarios del sistema
- `Provider` - Proveedores de carwash
- `Service` - Servicios ofrecidos
- `Booking` - Reservas
- `Review` - Reseñas

**Nuevas Entidades (v3.0):**
- `PriceAlert` - Alertas de precios (HU-031)
- `PriceHistory` - Histórico de precios (HU-033)
- `UserPreferences` - Preferencias de búsqueda (HU-039)
- `Tag` - Sistema de etiquetas (HU-043)
- `ProviderTag` - Relación provider-tags
- `ViewMetrics` - Métricas de visualización (HU-044)
- `AuditLog` - Registro de auditoría (HU-048)

### Relaciones

- User 1:N Booking
- User 1:N Review
- User 1:N PriceAlert
- User 1:1 UserPreferences
- Provider 1:N Service
- Provider 1:N Booking
- Provider 1:N Review (recibe)
- Provider N:M Tag (via ProviderTag)
- Service 1:N Booking
- Service 1:N PriceHistory
- Provider 1:N ViewMetrics

---

## 🔍 Verificación de Importación

### Checklist de Validación

- [ ] Todos los paquetes creados (8 épicas)
- [ ] Todos los actores importados con estereotipos correctos
- [ ] 48+ casos de uso identificados
- [ ] Relaciones entre actores y use cases
- [ ] Relaciones include/extend entre use cases
- [ ] Notas y descripciones visibles
- [ ] Trazabilidad a requerimientos establecida
- [ ] Diagrama de clases con todas las entidades
- [ ] Modelo completo navegable

### Métricas Esperadas en EA

- **Actores:** ~15 (10 humanos/externos, 5 sistemas)
- **Use Cases:** 48+
- **Paquetes:** 8 (épicas)
- **Relaciones:** 100+
- **Clases:** 20+ entidades
- **Requerimientos:** 82 (50 funcionales, 32 no funcionales)
- **Cobertura:** 90.2% (74/82 req cubiertos)

---

## 📝 Notas Adicionales

### Metadata de los Diagramas

Todos los diagramas incluyen metadatos EA en comentarios:
```plantuml
' @name EPI-XX: Nombre de la Épica
' @version 3.0
' @date 2025-10-21
' @author Alto Carwash Team
```

### Convenciones de Nomenclatura

- **Use Cases:** `UC-XXX: Descripción` (numeración secuencial)
- **Historias de Usuario:** `HU-XXX: Descripción` (001-048)
- **Requerimientos:** `REQ-XX` (001-082)
- **Épicas:** `EPI-XX: Nombre` (01-08)

### Stack Tecnológico (para contexto)

**Backend:**
- NestJS + TypeScript
- PostgreSQL + PostGIS
- Prisma ORM
- Redis (cache)

**Frontend:**
- Next.js 14 (App Router)
- React + TypeScript
- Tailwind CSS + shadcn/ui

**Integraciones:**
- Clerk (Auth)
- OpenAI API (IA)
- Google Maps API (Geo)
- Resend (Email)

**DevOps:**
- GitHub Actions (CI/CD)
- Docker
- Vercel (Frontend)
- Railway/Render (Backend)

---

## 📞 Soporte

Para preguntas o problemas con la importación:
1. Revisar la documentación oficial de PlantUML en EA
2. Consultar `ANALISIS_COBERTURA_REQUERIMIENTOS.md` para detalles de cobertura
3. Revisar `historias_de_usuario.md` para especificaciones completas

**Última actualización:** 21 de Octubre de 2025  
**Versión del documento:** 1.0
