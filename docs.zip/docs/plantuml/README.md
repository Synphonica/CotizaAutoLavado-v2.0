# PlantUML Diagrams - Alto Carwash

Esta carpeta contiene todos los diagramas PlantUML del proyecto Alto Carwash.

## 📁 Contenido

### Diagramas de Casos de Uso (por Épica)
- `epi-01-users.puml` - Gestión de Usuarios y Personalización
- `epi-02-search.puml` - Búsqueda y Descubrimiento
- `epi-03-comparison.puml` - Comparación y Evaluación
- `epi-04-reviews.puml` - Reseñas y Reputación
- `epi-05-bookings.puml` - Gestión de Reservas
- `epi-06-ai.puml` - IA y Agregación de Datos
- `epi-07-providers.puml` - Portal de Proveedores
- `epi-08-admin.puml` - Administración y Moderación
- `system-complete.puml` - Diagrama completo del sistema

### Modelo de Dominio
- `class-diagram.puml` - Diagrama de clases completo del sistema

## 🔧 Cómo usar

### Opción 1: Visual Studio Code
1. Instala la extensión "PlantUML" (jebbs.plantuml)
2. Abre cualquier archivo `.puml`
3. Presiona `Alt+D` para ver el preview

### Opción 2: PlantUML Online
1. Visita http://www.plantuml.com/plantuml/uml/
2. Copia y pega el contenido del archivo `.puml`
3. El diagrama se genera automáticamente

### Opción 3: Exportar imágenes
```bash
# Instalar PlantUML (requiere Java)
# En VSCode con la extensión PlantUML:
# Click derecho en el archivo .puml > "Export Current Diagram"

# O usar línea de comandos:
java -jar plantuml.jar *.puml
```

## 📊 Formatos de exportación disponibles
- PNG (recomendado para documentación)
- SVG (vectorial, escalable)
- PDF
- EPS

## 🎨 Personalización

Todos los diagramas usan el tema por defecto de PlantUML. Puedes cambiar el estilo agregando al inicio del archivo:

```plantuml
!theme cerulean
' Otros temas: bluegray, plain, amiga, sketchy-outline, etc.
```

## 📚 Referencias
- [PlantUML Official Site](https://plantuml.com/)
- [PlantUML Cheat Sheet](https://plantuml.com/use-case-diagram)
- [PlantUML Class Diagram Guide](https://plantuml.com/class-diagram)
