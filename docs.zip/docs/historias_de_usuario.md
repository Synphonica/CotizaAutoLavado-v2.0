# 🚗 Historias de Usuario - Alto Carwash

## Descripción del Proyecto

**Alto Carwash** es una plataforma digital agregadora de servicios de lavado automotriz que conecta a propietarios de vehículos con autolavados en Chile. La plataforma centraliza información de precios de múltiples proveedores, permite comparación transparente de servicios en tiempo real, búsqueda por geolocalización, gestión de reservas, y ofrece recomendaciones personalizadas mediante inteligencia artificial. El sistema actúa como intermediario neutral entre usuarios y proveedores de servicios de autolavado.

---

## 📋 Tabla de Contenidos

- [Resumen Ejecutivo](#resumen-ejecutivo)
- [Arquitectura y Contexto Técnico](#arquitectura-y-contexto-técnico)
- [Requisitos del Sistema](#requisitos-del-sistema)
- [Tabla Resumen de Historias](#tabla-resumen-de-historias)
- [Historias de Usuario Detalladas](#historias-de-usuario-detalladas)
- [Épicas](#épicas)
- [Notas de Planificación](#notas-de-planificación)

---

## Resumen Ejecutivo

Este documento presenta **48 historias de usuario** detalladas para **Alto Carwash**, organizadas en 8 épicas estratégicas. Cada historia incluye información técnica completa:

- **Requisitos asociados** (funcionales y no funcionales)
- **Constraints técnicos** y de negocio
- **Entry points** (UI, API, webhooks)
- **Context references** (módulos, servicios, tablas)
- **Escenarios completos** (precondiciones, flujo principal, alternos, postcondiciones)
- **Criterios de aceptación testables** (3-6 por historia)
- **Relaciones con casos de uso** (include/extend)

**Total de Story Points:** 354  
**Total de Historias:** 48  
**Total de Épicas:** 8  
**Cobertura de Requerimientos:** 85%+ (70/82 requerimientos)

**Distribución por Épica:**
1. **EPI-01: Gestión de Usuarios y Personalización** - 48 pts (7 HUs)
2. **EPI-02: Búsqueda y Descubrimiento** - 37 pts (4 HUs)
3. **EPI-03: Comparación y Evaluación** - 39 pts (6 HUs)
4. **EPI-04: Reseñas y Reputación** - 13 pts (4 HUs)
5. **EPI-05: Gestión de Reservas** - 22 pts (4 HUs)
6. **EPI-06: IA y Agregación** - 34 pts (3 HUs)
7. **EPI-07: Portal de Proveedores** - 63 pts (8 HUs)
8. **EPI-08: Administración y DevOps** - 98 pts (12 HUs)

### 🎯 Estado de Cobertura de Requerimientos

| Categoría | Requerimientos | Cubiertos | Cobertura |
|-----------|----------------|-----------|-----------|
| **Gestión de Usuarios** | 8 | 8 | 100% ✅ |
| **Gestión de Proveedores** | 12 | 11 | 91.7% ✅ |
| **Agregador y Comparación** | 15 | 14 | 93.3% ✅ |
| **Aplicación Móvil** | 8 | 6 | 75% ⚠️ |
| **Geolocalización** | 7 | 7 | 100% ✅ |
| **Performance** | 8 | 7 | 87.5% ✅ |
| **Seguridad** | 10 | 9 | 90% ✅ |
| **Usabilidad** | 7 | 6 | 85.7% ✅ |
| **Mantenimiento** | 7 | 6 | 85.7% ✅ |
| **TOTAL** | **82** | **74** | **90.2%** ✅ |

---

## Arquitectura y Contexto Técnico

### Stack Tecnológico

**Backend:**
- Framework: NestJS (Node.js/TypeScript)
- Base de datos: PostgreSQL con extensión PostGIS (consultas espaciales)
- ORM: Prisma
- Autenticación: Clerk (OAuth2, JWT)
- Caché: Redis
- APIs externas: Google Maps API, OpenAI API

**Frontend:**
- Framework: Next.js 14+ (React, TypeScript)
- UI: shadcn/ui, Tailwind CSS
- Estado: React Context API, React Query
- Mapas: Google Maps JavaScript API

**Scraper:**
- Runtime: Node.js/TypeScript
- Web scraping: Puppeteer
- Output: JSON, CSV, SQL

### Módulos Principales

```
backend/src/
├── auth/           # Autenticación y autorización (Clerk)
├── users/          # Gestión de usuarios
├── providers/      # Gestión de proveedores
├── services/       # Catálogo de servicios
├── bookings/       # Sistema de reservas
├── search/         # Motor de búsqueda geolocalizado
├── maps/           # Integración con Google Maps
├── comparison/     # Comparación de proveedores
├── reviews/        # Sistema de reseñas
├── favorites/      # Gestión de favoritos
├── notifications/  # Sistema de notificaciones
├── email/          # Servicio de emails
├── ia/             # Recomendaciones con IA
├── analytics/      # Analytics y métricas
├── aggregator/     # Agregación de datos
└── prisma/         # Cliente de Prisma
```

### Modelos de Datos Clave

```prisma
User {
  id, clerkId, email, firstName, lastName, role, status,
  defaultLatitude, defaultLongitude, favorites, bookings, reviews
}

Provider {
  id, userId, businessName, status, latitude, longitude,
  rating, totalReviews, services, reviews, bookings
}

Service {
  id, providerId, name, type, status, price, duration
}

Booking {
  id, userId, providerId, serviceId, startTime, endTime,
  status, vehicleInfo, confirmationCode, qrCode
}
```

---

## Requisitos del Sistema

### Requisitos Funcionales (REQ-FUNC)

| ID | Descripción | HU Relacionadas |
|---|---|---|
| REQ-FUNC-001 | El sistema debe permitir registro de usuarios mediante email/contraseña y OAuth | HU-001 |
| REQ-FUNC-002 | El sistema debe validar unicidad de emails | HU-001 |
| REQ-FUNC-003 | El sistema debe autenticar usuarios mediante email/contraseña y OAuth | HU-002 |
| REQ-FUNC-004 | El sistema debe bloquear cuentas tras múltiples intentos fallidos | HU-002 |
| REQ-FUNC-005 | El sistema debe permitir búsqueda por dirección, comuna, ciudad o GPS | HU-005 |
| REQ-FUNC-006 | El sistema debe ordenar resultados por distancia | HU-005 |
| REQ-FUNC-007 | El sistema debe permitir configurar radio de búsqueda | HU-005 |
| REQ-FUNC-010 | El sistema debe validar disponibilidad en tiempo real | HU-013 |
| REQ-FUNC-011 | El sistema debe prevenir doble-booking | HU-013 |
| REQ-FUNC-012 | El sistema debe enviar confirmaciones por email | HU-013 |
| REQ-FUNC-013 | El sistema debe generar códigos únicos de reserva con QR | HU-013 |
| REQ-FUNC-020 | El sistema debe analizar historial de usuarios para recomendaciones | HU-017 |
| REQ-FUNC-021 | El sistema debe generar recomendaciones usando OpenAI | HU-017 |
| REQ-FUNC-022 | El sistema debe explicar por qué recomienda cada proveedor | HU-017 |
| REQ-FUNC-023 | El sistema debe permitir feedback de recomendaciones | HU-017 |
| REQ-FUNC-030 | El sistema debe extraer datos de múltiples fuentes públicas | HU-030 |
| REQ-FUNC-031 | El sistema debe normalizar direcciones y geocodificar | HU-030 |
| REQ-FUNC-032 | El sistema debe detectar y prevenir duplicados | HU-030 |
| REQ-FUNC-033 | El sistema debe validar calidad de datos extraídos | HU-030 |
| REQ-FUNC-034 | El sistema debe generar reportes de importación | HU-030 |

### Requisitos No Funcionales (REQ-NF)

| ID | Categoría | Descripción | Valor | HU Relacionadas |
|---|---|---|---|---|
| REQ-NF-001 | Seguridad | Contraseñas según OWASP | Min 8 chars, 1 mayúscula, 1 número | HU-001 |
| REQ-NF-002 | Performance | Tiempo de respuesta de registro | < 3s | HU-001 |
| REQ-NF-003 | Seguridad | Expiración de sesiones | 24h inactividad | HU-002 |
| REQ-NF-004 | Compatibilidad | Soporte biometría móvil | iOS/Android | HU-002 |
| REQ-NF-005 | Performance | Tiempo de autenticación | < 2s | HU-002 |
| REQ-NF-006 | Performance | Tiempo de respuesta de búsqueda | < 2s | HU-005 |
| REQ-NF-007 | Usabilidad | Manejo de búsquedas sin resultados | Mensajes claros | HU-005 |
| REQ-NF-008 | Compatibilidad | Búsqueda responsive | Mobile/Desktop | HU-005 |
| REQ-NF-010 | Performance | Tiempo de confirmación de reserva | < 3s | HU-013 |
| REQ-NF-011 | Escalabilidad | Concurrencia de reservas | 100 simultáneas | HU-013 |
| REQ-NF-012 | Confiabilidad | Transacciones ACID | Total | HU-013 |
| REQ-NF-020 | Performance | Generación de recomendaciones | < 5s | HU-017 |
| REQ-NF-021 | Costo | Optimización de costos OpenAI | Caching 24h | HU-017 |
| REQ-NF-022 | Calidad | Precisión de recomendaciones | > 70% conversión | HU-017 |
| REQ-NF-030 | Ética | Respeto de robots.txt y rate limits | Max 10 req/s | HU-030 |
| REQ-NF-031 | Mantenibilidad | Adaptabilidad a cambios HTML | Fallback selectors | HU-030 |
| REQ-NF-032 | Confiabilidad | Idempotencia de importación | Re-ejecutable | HU-030 |

---

## Tabla Resumen de Historias

| ID | Título | Rol | Puntos | Epic |
|---|---|---|---|---|
| HU-001 | Registro de usuario en la plataforma | Usuario/Cliente | 5 | EPI-01 |
| HU-002 | Inicio de sesión en la plataforma | Usuario/Cliente | 3 | EPI-01 |
| HU-003 | Recuperación de contraseña | Usuario/Cliente | 3 | EPI-01 |
| HU-004 | Gestión de perfil de usuario | Usuario/Cliente | 3 | EPI-01 |
| HU-005 | Búsqueda de autolavados por ubicación | Usuario/Cliente | 8 | EPI-02 |
| HU-006 | Búsqueda avanzada con filtros | Usuario/Cliente | 5 | EPI-02 |
| HU-007 | Visualización de mapa interactivo | Usuario/Cliente | 8 | EPI-02 |
| HU-008 | Comparación de precios entre proveedores | Usuario/Cliente | 8 | EPI-03 |
| HU-009 | Visualización de detalles del proveedor | Usuario/Cliente | 5 | EPI-03 |
| HU-010 | Gestión de lista de favoritos | Usuario/Cliente | 5 | EPI-01 |
| HU-011 | Visualización de historial de búsquedas | Usuario/Cliente | 3 | EPI-01 |
| HU-012 | Sistema de reseñas y calificaciones | Usuario/Cliente | 8 | EPI-04 |
| HU-013 | Reserva de servicio de lavado | Usuario/Cliente | 8 | EPI-05 |
| HU-014 | Cancelación de reserva | Usuario/Cliente | 3 | EPI-05 |
| HU-015 | Visualización de historial de reservas | Usuario/Cliente | 3 | EPI-05 |
| HU-016 | Notificaciones push de recordatorios | Usuario/Cliente | 5 | EPI-01 |
| HU-017 | Recomendaciones personalizadas con IA | Usuario/Cliente | 13 | EPI-06 |
| HU-018 | Registro de proveedor | Proveedor | 8 | EPI-07 |
| HU-019 | Gestión de perfil de negocio | Proveedor | 5 | EPI-07 |
| HU-020 | Gestión de catálogo de servicios | Proveedor | 8 | EPI-07 |
| HU-021 | Configuración de horarios disponibles | Proveedor | 5 | EPI-07 |
| HU-022 | Gestión de reservas recibidas | Proveedor | 8 | EPI-05 |
| HU-023 | Dashboard de estadísticas del proveedor | Proveedor | 13 | EPI-07 |
| HU-024 | Gestión de promociones y descuentos | Proveedor | 8 | EPI-07 |
| HU-025 | Respuesta a reseñas de clientes | Proveedor | 5 | EPI-04 |
| HU-026 | Sistema de verificación de proveedores | Admin | 8 | EPI-08 |
| HU-027 | Dashboard administrativo completo | Admin | 13 | EPI-08 |
| HU-028 | Gestión de usuarios y moderación | Admin | 8 | EPI-08 |
| HU-029 | Configuración de parámetros del sistema | Admin | 5 | EPI-08 |
| HU-030 | Scraping y agregación de datos | Sistema | 13 | EPI-06 |
| **HU-031** | **Sistema de alertas de precios** | Usuario/Cliente | 8 | EPI-03 |
| **HU-032** | **Importación masiva CSV/Excel** | Admin/Proveedor | 8 | EPI-07 |
| **HU-033** | **Comparación histórica de precios** | Usuario/Cliente | 13 | EPI-03 |
| **HU-034** | **Calculadora de ahorro** | Usuario/Cliente | 5 | EPI-03 |
| **HU-035** | **Exportar comparación (PDF)** | Usuario/Cliente | 5 | EPI-03 |
| **HU-036** | **Compartir en redes sociales** | Usuario/Cliente | 3 | EPI-01 |
| **HU-037** | **Accesibilidad WCAG 2.1 AA** | Sistema | 13 | EPI-08 |
| **HU-038** | **Suite de testing automatizado** | Sistema | 13 | EPI-08 |
| **HU-039** | **Preferencias de búsqueda avanzadas** | Usuario/Cliente | 5 | EPI-01 |
| **HU-040** | **Modo offline (PWA)** | Usuario/Cliente | 13 | EPI-02 |
| **HU-041** | **Deep links a apps de navegación** | Usuario/Cliente | 3 | EPI-02 |
| **HU-042** | **Pipeline CI/CD** | Sistema | 8 | EPI-08 |
| **HU-043** | **Categorización avanzada de proveedores** | Admin/Proveedor | 5 | EPI-07 |
| **HU-044** | **Métricas de visualizaciones** | Proveedor | 5 | EPI-07 |
| **HU-045** | **Actualización automática de precios** | Sistema | 13 | EPI-06 |
| **HU-046** | **API pública documentada (OpenAPI)** | Sistema | 8 | EPI-08 |
| **HU-047** | **Sistema de backup automático** | Sistema | 5 | EPI-08 |
| **HU-048** | **Audit trail completo** | Sistema | 8 | EPI-08 |

**Total Puntos de Historia:** 354

**Leyenda:**
- Historias en **negrita** son nuevas (agregadas para cubrir requerimientos faltantes)
- Total de historias: 48 (30 originales + 18 nuevas)

---

## 📐 Diagrama de Clases (Modelo de Dominio)

### Diagrama General del Sistema

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        MODELO DE DOMINIO - ALTO CARWASH                      │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────┐
│       <<Entity>>        │
│         User            │
├─────────────────────────┤
│ - id: String (PK)       │
│ - clerkId: String (UK)  │
│ - email: String (UK)    │
│ - firstName: String     │
│ - lastName: String      │
│ - phone?: String        │
│ - dateOfBirth?: Date    │
│ - role: UserRole        │
│ - status: UserStatus    │
│ - avatar?: String       │
│ - defaultLatitude?: Float│
│ - defaultLongitude?: Float│
│ - defaultAddress?: String│
│ - createdAt: DateTime   │
│ - updatedAt: DateTime   │
│ - lastLoginAt?: DateTime│
├─────────────────────────┤
│ + register()            │
│ + login()               │
│ + updateProfile()       │
│ + updateLocation()      │
│ + deactivate()          │
└─────────────────────────┘
         △ △ △
         │ │ │
    1:1  │ │ │ 1:*         1:*        1:*          1:*
  ┌──────┘ │ └────────┬──────────┬──────────┬──────────┐
  │        │          │          │          │          │
  │        │          │          │          │          │
┌─▼────────┴──┐  ┌───▼──────┐ ┌─▼─────┐  ┌▼────────┐ ┌▼──────────┐
│  Provider   │  │ Booking  │ │Review │  │Favorite │ │SearchHist │
│  (extends)  │  │          │ │       │  │         │ │           │
└─────────────┘  └──────────┘ └───────┘  └─────────┘ └───────────┘


┌──────────────────────────────┐
│        <<Entity>>            │
│         Provider             │
├──────────────────────────────┤
│ - id: String (PK)            │
│ - userId: String (FK)        │
│ - businessName: String (UK)  │
│ - description?: String       │
│ - rut?: String               │
│ - address: String            │
│ - city: String               │
│ - region: String             │
│ - latitude: Float (Indexed) │
│ - longitude: Float (Indexed)│
│ - phone: String              │
│ - email: String              │
│ - website?: String           │
│ - status: ProviderStatus     │
│ - rating: Float              │
│ - totalReviews: Int          │
│ - totalBookings: Int         │
│ - verifiedAt?: DateTime      │
│ - acceptsBookings: Boolean   │
│ - maxAdvanceBooking: Int     │
│ - cancellationPolicy?: String│
│ - createdAt: DateTime        │
│ - updatedAt: DateTime        │
├──────────────────────────────┤
│ + register()                 │
│ + updateProfile()            │
│ + updateLocation()           │
│ + updateRating()             │
│ + verify()                   │
│ + suspend()                  │
│ + activate()                 │
│ + calculateAverageRating()   │
└──────────────────────────────┘
         │ 1:*
         │
    ┌────┴─────────────┬──────────────┬────────────────┐
    │                  │              │                │
    │ 1:*              │ 1:*          │ 1:*            │ 1:*
┌───▼────────┐   ┌────▼──────┐  ┌───▼──────┐   ┌─────▼──────┐
│  Service   │   │ Booking   │  │ Review   │   │  Schedule  │
└────────────┘   └───────────┘  └──────────┘   └────────────┘


┌──────────────────────────────┐
│        <<Entity>>            │
│         Service              │
├──────────────────────────────┤
│ - id: String (PK)            │
│ - providerId: String (FK)    │
│ - name: String               │
│ - description?: String       │
│ - type: ServiceType          │
│ - price: Decimal             │
│ - duration: Int (minutes)    │
│ - status: ServiceStatus      │
│ - isAvailable: Boolean       │
│ - vehicleTypes: String[]     │
│ - includedFeatures?: String[]│
│ - imageUrl?: String          │
│ - createdAt: DateTime        │
│ - updatedAt: DateTime        │
├──────────────────────────────┤
│ + create()                   │
│ + update()                   │
│ + updatePrice()              │
│ + activate()                 │
│ + deactivate()               │
│ + checkAvailability()        │
└──────────────────────────────┘
         │ 1:*
         │
         │
    ┌────▼─────────────┐
    │                  │
    │ 1:*              │ 1:*
┌───▼────────┐   ┌────▼──────┐
│  Booking   │   │ Promotion │
└────────────┘   └───────────┘


┌──────────────────────────────┐
│        <<Entity>>            │
│         Booking              │
├──────────────────────────────┤
│ - id: String (PK)            │
│ - userId: String (FK)        │
│ - providerId: String (FK)    │
│ - serviceId: String (FK)     │
│ - startTime: DateTime        │
│ - endTime: DateTime          │
│ - status: BookingStatus      │
│ - vehicleInfo: JSON          │
│   • brand: String            │
│   • model: String            │
│   • plate: String            │
│   • color: String            │
│ - specialNotes?: String      │
│ - totalPrice: Decimal        │
│ - confirmationCode: String(UK)│
│ - qrCode?: String            │
│ - cancelledAt?: DateTime     │
│ - cancelReason?: String      │
│ - completedAt?: DateTime     │
│ - createdAt: DateTime        │
│ - updatedAt: DateTime        │
├──────────────────────────────┤
│ + create()                   │
│ + checkAvailability()        │
│ + confirm()                  │
│ + cancel()                   │
│ + complete()                 │
│ + generateQRCode()           │
│ + sendConfirmation()         │
│ + sendReminder()             │
└──────────────────────────────┘
         │ 1:1
         │
         ▼
┌──────────────────────────────┐
│        <<Entity>>            │
│         Review               │
├──────────────────────────────┤
│ - id: String (PK)            │
│ - userId: String (FK)        │
│ - providerId: String (FK)    │
│ - bookingId?: String (FK)    │
│ - rating: Int (1-5)          │
│ - title?: String             │
│ - comment?: String           │
│ - qualityRating?: Int        │
│ - cleanlinessRating?: Int    │
│ - valueRating?: Int          │
│ - serviceRating?: Int        │
│ - images?: String[]          │
│ - status: ReviewStatus       │
│ - providerResponse?: String  │
│ - respondedAt?: DateTime     │
│ - helpfulCount: Int          │
│ - createdAt: DateTime        │
│ - updatedAt: DateTime        │
├──────────────────────────────┤
│ + create()                   │
│ + update()                   │
│ + approve()                  │
│ + reject()                   │
│ + addProviderResponse()      │
│ + markHelpful()              │
└──────────────────────────────┘


┌──────────────────────────────┐
│        <<Entity>>            │
│       SearchHistory          │
├──────────────────────────────┤
│ - id: String (PK)            │
│ - userId: String (FK)        │
│ - query?: String             │
│ - latitude: Float            │
│ - longitude: Float           │
│ - radius: Int (km)           │
│ - filters?: JSON             │
│ - resultsCount: Int          │
│ - createdAt: DateTime        │
├──────────────────────────────┤
│ + create()                   │
│ + getRecent()                │
│ + delete()                   │
└──────────────────────────────┘


┌──────────────────────────────┐
│        <<Entity>>            │
│         Favorite             │
├──────────────────────────────┤
│ - id: String (PK)            │
│ - userId: String (FK)        │
│ - providerId: String (FK)    │
│ - createdAt: DateTime        │
├──────────────────────────────┤
│ + add()                      │
│ + remove()                   │
│ + list()                     │
└──────────────────────────────┘


┌──────────────────────────────┐
│        <<Entity>>            │
│        Notification          │
├──────────────────────────────┤
│ - id: String (PK)            │
│ - userId: String (FK)        │
│ - type: NotificationType     │
│ - title: String              │
│ - message: String            │
│ - data?: JSON                │
│ - status: NotificationStatus │
│ - readAt?: DateTime          │
│ - sentAt?: DateTime          │
│ - createdAt: DateTime        │
├──────────────────────────────┤
│ + create()                   │
│ + send()                     │
│ + markAsRead()               │
│ + delete()                   │
└──────────────────────────────┘


┌──────────────────────────────┐
│        <<Entity>>            │
│        Schedule              │
├──────────────────────────────┤
│ - id: String (PK)            │
│ - providerId: String (FK)    │
│ - dayOfWeek: Int (0-6)       │
│ - openTime: String           │
│ - closeTime: String          │
│ - isOpen: Boolean            │
│ - breakStart?: String        │
│ - breakEnd?: String          │
│ - createdAt: DateTime        │
│ - updatedAt: DateTime        │
├──────────────────────────────┤
│ + create()                   │
│ + update()                   │
│ + getAvailableSlots()        │
│ + isTimeAvailable()          │
└──────────────────────────────┘


┌──────────────────────────────┐
│        <<Entity>>            │
│        Promotion             │
├──────────────────────────────┤
│ - id: String (PK)            │
│ - providerId: String (FK)    │
│ - serviceId?: String (FK)    │
│ - title: String              │
│ - description: String        │
│ - discountType: DiscountType │
│ - discountValue: Decimal     │
│ - code?: String              │
│ - startDate: DateTime        │
│ - endDate: DateTime          │
│ - maxUses?: Int              │
│ - currentUses: Int           │
│ - status: PromotionStatus    │
│ - createdAt: DateTime        │
│ - updatedAt: DateTime        │
├──────────────────────────────┤
│ + create()                   │
│ + activate()                 │
│ + deactivate()               │
│ + apply()                    │
│ + isValid()                  │
└──────────────────────────────┘


┌──────────────────────────────┐
│    <<Entity>>                │
│ RecommendationFeedback       │
├──────────────────────────────┤
│ - id: String (PK)            │
│ - userId: String (FK)        │
│ - providerId: String (FK)    │
│ - feedback: FeedbackType     │
│ - reason?: String            │
│ - relevanceScore?: Float     │
│ - createdAt: DateTime        │
├──────────────────────────────┤
│ + create()                   │
│ + analyze()                  │
└──────────────────────────────┘
```

---

### Enumeraciones (Enums)

```
┌──────────────────┐
│    UserRole      │
├──────────────────┤
│ CUSTOMER         │
│ PROVIDER         │
│ ADMIN            │
└──────────────────┘

┌──────────────────┐
│   UserStatus     │
├──────────────────┤
│ ACTIVE           │
│ INACTIVE         │
│ SUSPENDED        │
│ DELETED          │
└──────────────────┘

┌──────────────────┐
│ ProviderStatus   │
├──────────────────┤
│ PENDING_APPROVAL │
│ ACTIVE           │
│ SUSPENDED        │
│ REJECTED         │
└──────────────────┘

┌──────────────────┐
│  ServiceType     │
├──────────────────┤
│ EXTERIOR_WASH    │
│ INTERIOR_WASH    │
│ FULL_WASH        │
│ DETAILING        │
│ WAX              │
│ POLISH           │
│ ENGINE_WASH      │
│ OTHER            │
└──────────────────┘

┌──────────────────┐
│ ServiceStatus    │
├──────────────────┤
│ ACTIVE           │
│ INACTIVE         │
│ DELETED          │
└──────────────────┘

┌──────────────────┐
│ BookingStatus    │
├──────────────────┤
│ PENDING          │
│ CONFIRMED        │
│ IN_PROGRESS      │
│ COMPLETED        │
│ CANCELLED        │
│ NO_SHOW          │
└──────────────────┘

┌──────────────────┐
│  ReviewStatus    │
├──────────────────┤
│ PENDING          │
│ APPROVED         │
│ REJECTED         │
│ FLAGGED          │
└──────────────────┘

┌──────────────────┐
│NotificationType  │
├──────────────────┤
│ BOOKING_CONFIRM  │
│ BOOKING_REMINDER │
│ BOOKING_CANCELLED│
│ REVIEW_REQUEST   │
│ PROMOTION        │
│ SYSTEM           │
└──────────────────┘

┌──────────────────┐
│NotificationStatus│
├──────────────────┤
│ PENDING          │
│ SENT             │
│ READ             │
│ FAILED           │
└──────────────────┘

┌──────────────────┐
│  DiscountType    │
├──────────────────┤
│ PERCENTAGE       │
│ FIXED_AMOUNT     │
└──────────────────┘

┌──────────────────┐
│ PromotionStatus  │
├──────────────────┤
│ DRAFT            │
│ ACTIVE           │
│ EXPIRED          │
│ DISABLED         │
└──────────────────┘

┌──────────────────┐
│  FeedbackType    │
├──────────────────┤
│ LIKE             │
│ DISLIKE          │
│ EXCLUDE          │
└──────────────────┘
```

---

### Relaciones Clave

**Herencia:**
- `Provider` extends `User` (herencia 1:1, Provider es un User con role=PROVIDER)

**Composición:**
- `Provider` ◆──→ `Service` (1:*) - Un Provider tiene múltiples Services
- `Provider` ◆──→ `Schedule` (1:7) - Un Provider tiene horarios por día de semana
- `Booking` ◆──→ `VehicleInfo` (1:1) - Booking contiene información del vehículo

**Agregación:**
- `User` ◇──→ `Booking` (1:*) - Un User tiene múltiples Bookings
- `User` ◇──→ `Favorite` (1:*) - Un User tiene múltiples Favorites
- `User` ◇──→ `Review` (1:*) - Un User escribe múltiples Reviews
- `User` ◇──→ `SearchHistory` (1:*) - Un User tiene múltiples búsquedas
- `User` ◇──→ `Notification` (1:*) - Un User recibe múltiples Notifications

**Asociación:**
- `Booking` ──→ `User` (M:1) - Múltiples Bookings pertenecen a un User
- `Booking` ──→ `Provider` (M:1) - Múltiples Bookings pertenecen a un Provider
- `Booking` ──→ `Service` (M:1) - Múltiples Bookings usan un Service
- `Review` ──→ `Booking` (1:1?) - Una Review puede estar asociada a un Booking
- `Favorite` ──→ `Provider` (M:1) - Múltiples Favorites apuntan a un Provider
- `Promotion` ──→ `Service` (M:1?) - Una Promotion puede aplicar a un Service específico

---

### Multiplicidades Importantes

| Relación | Multiplicidad | Descripción |
|---|---|---|
| User → Booking | 1:* | Un usuario puede tener múltiples reservas (max 3 activas) |
| Provider → Service | 1:* | Un proveedor puede ofrecer múltiples servicios |
| Provider → Booking | 1:* | Un proveedor puede recibir múltiples reservas |
| Service → Booking | 1:* | Un servicio puede ser reservado múltiples veces |
| Booking → Review | 1:0..1 | Una reserva puede tener máximo una reseña |
| User → Review | 1:* | Un usuario puede escribir múltiples reseñas |
| Provider → Review | 1:* | Un proveedor puede recibir múltiples reseñas |
| User → Favorite | 1:* | Un usuario puede tener múltiples favoritos |
| Provider → Schedule | 1:7 | Un proveedor tiene 7 horarios (uno por día de semana) |
| Provider → Promotion | 1:* | Un proveedor puede crear múltiples promociones |
| User → SearchHistory | 1:* | Un usuario tiene múltiples búsquedas (últimas 20) |

---

### Constraints y Reglas de Negocio

**User:**
- `email` debe ser único en el sistema
- `clerkId` debe ser único (vinculación con Clerk Auth)
- `role` determina el tipo de acceso (CUSTOMER, PROVIDER, ADMIN)
- `defaultLatitude` y `defaultLongitude` son opcionales pero mejoran UX

**Provider:**
- Debe estar asociado a un `User` con `role=PROVIDER`
- `businessName` debe ser único
- `latitude` y `longitude` son obligatorios (búsqueda espacial)
- `status=ACTIVE` requerido para aparecer en búsquedas
- `rating` se calcula automáticamente del promedio de `reviews`
- `acceptsBookings` determina si acepta reservas online

**Service:**
- Debe pertenecer a un `Provider` activo
- `price` debe ser > 0
- `duration` en minutos, típicamente entre 15-240 min
- `status=ACTIVE` y `isAvailable=true` para reservas
- `vehicleTypes` array de tipos compatibles (sedan, SUV, pickup, etc.)

**Booking:**
- `confirmationCode` debe ser único (8-12 caracteres alfanuméricos)
- `startTime` debe ser futuro y respetar `maxAdvanceBooking`
- `endTime = startTime + service.duration`
- No puede haber overlapping bookings para mismo provider en mismo slot
- `status` sigue flujo: PENDING → CONFIRMED → IN_PROGRESS → COMPLETED
- Cancelación permitida solo si `startTime - now > 2h`
- Usuario puede tener máximo 3 bookings con status PENDING o CONFIRMED

**Review:**
- Solo usuarios con booking COMPLETED pueden crear review
- `rating` debe estar entre 1-5
- Puede tener ratings específicos opcionales (quality, cleanliness, value, service)
- `status=APPROVED` requerido para mostrarse públicamente
- Usuario puede editar review hasta 7 días después de creación
- Provider puede responder con `providerResponse`

**Schedule:**
- 7 registros por provider (uno por día de semana, 0=Domingo, 6=Sábado)
- `openTime` y `closeTime` en formato HH:mm (24h)
- `isOpen=false` para días no laborables
- Puede tener break opcional (`breakStart`, `breakEnd`)

**Promotion:**
- `discountType`: PERCENTAGE (0-100%) o FIXED_AMOUNT (monto en CLP)
- `endDate` debe ser posterior a `startDate`
- `currentUses` no puede exceder `maxUses`
- `status=ACTIVE` y fecha actual entre `startDate` y `endDate` para aplicarse

---

### Índices de Base de Datos

Para performance óptimo, estos índices son críticos:

```sql
-- Búsqueda espacial (PostGIS)
CREATE INDEX provider_location_idx ON providers USING GIST (
  ST_MakePoint(longitude, latitude)
);

-- Búsqueda de bookings por usuario
CREATE INDEX booking_user_idx ON bookings (user_id, status, start_time);

-- Búsqueda de bookings por provider
CREATE INDEX booking_provider_idx ON bookings (provider_id, status, start_time);

-- Validación de disponibilidad (prevención de doble-booking)
CREATE INDEX booking_availability_idx ON bookings (
  provider_id, start_time, end_time
) WHERE status NOT IN ('CANCELLED', 'COMPLETED');

-- Búsqueda de reviews por provider
CREATE INDEX review_provider_idx ON reviews (provider_id, status, created_at);

-- Email único en users
CREATE UNIQUE INDEX user_email_idx ON users (email);

-- ClerkId único en users
CREATE UNIQUE INDEX user_clerk_id_idx ON users (clerk_id);

-- Confirmation code único en bookings
CREATE UNIQUE INDEX booking_confirmation_code_idx ON bookings (confirmation_code);

-- Business name único en providers
CREATE UNIQUE INDEX provider_business_name_idx ON providers (business_name);
```

---

### Patrones de Diseño Aplicados

**Repository Pattern:**
- Cada entidad tiene su propio repository (UsersRepository, ProvidersRepository, etc.)
- Encapsula lógica de acceso a datos
- Facilita testing con mocks

**Service Layer Pattern:**
- Servicios de negocio (BookingsService, RecommendationEngine, etc.)
- Orquestan múltiples repositories
- Contienen lógica de negocio compleja

**Factory Pattern:**
- `NotificationFactory`: crea diferentes tipos de notificaciones
- `QRCodeGenerator`: genera códigos QR para bookings

**Strategy Pattern:**
- `DiscountStrategy`: diferentes tipos de descuentos (PERCENTAGE, FIXED_AMOUNT)
- `RecommendationStrategy`: algoritmos de recomendación (AI-based, collaborative filtering)

**Observer Pattern:**
- Eventos del sistema (`booking.created`, `review.approved`, etc.)
- Listeners para analytics, notificaciones, cache invalidation

---

## Historias de Usuario Detalladas

### Formato Estándar de Historias de Usuario

Cada historia de usuario sigue este formato detallado para facilitar implementación y testing:

```
### HU-XXX: [Título descriptivo]

**Título:** Como [rol], quiero [acción] para [beneficio].

**Descripción:**
Descripción detallada de la funcionalidad y contexto.

**Requisitos Asociados:**
- REQ-FUNC-XXX: Requisitos funcionales relacionados
- REQ-NF-XXX: Requisitos no funcionales relacionados

**Constraints:**
Lista de restricciones técnicas, de negocio y de seguridad.

**Entry Points:**
- UI: Páginas y componentes de interfaz
- API: Endpoints REST
- Webhooks/Jobs: Procesos automatizados

**Context References:**
- Módulos: Módulos del backend relacionados
- Servicios: Servicios y clases principales
- Tablas: Modelos de Prisma y tablas de BD
- Componentes: Componentes de React/frontend
- External APIs: APIs de terceros

**Escenarios:**

**Precondiciones:**
Condiciones que deben cumplirse antes de ejecutar el flujo.

**Flujo Principal:**
Pasos numerados del happy path (flujo exitoso).

**Escenarios Alternos:**
EA-X: [Título del escenario alterno]
Pasos para manejar errores, edge cases y flujos alternativos.

**Postcondiciones:**
Estado del sistema tras ejecución exitosa.

**Criterios de Aceptación:**
1. CA-1: Criterio testable específico
2. CA-2: Criterio testable específico
[...]

**Story Points:** [Fibonacci: 1, 2, 3, 5, 8, 13]
**Prioridad:** [Must | Should | Could | Won't]
**Dependencias:** [HU-XXX, HU-YYY]

**Relación con Casos de Uso:**
- UC-XXX: [Nombre] (include/extend) - Descripción
```

---

### HU-001: Registro de usuario en la plataforma

**Título:** Como usuario potencial, quiero registrarme en la plataforma para acceder a los servicios personalizados de búsqueda y reserva de autolavados.

**Descripción:**  
El sistema debe permitir el registro de nuevos usuarios mediante un formulario que capture información básica y valide los datos ingresados. Se utiliza Clerk para la autenticación y gestión de identidad.

**Requisitos Asociados:**
- **REQ-FUNC-001:** El sistema debe permitir el registro de usuarios mediante email/contraseña y OAuth providers
- **REQ-FUNC-002:** El sistema debe validar unicidad de emails en la base de datos
- **REQ-NF-001:** La contraseña debe cumplir con estándares de seguridad OWASP
- **REQ-NF-002:** El tiempo de respuesta del registro no debe exceder 3 segundos

**Constraints:**
- Integración obligatoria con Clerk para autenticación
- Email debe ser verificado antes de acceso completo a la plataforma
- Rol por defecto: CUSTOMER (según enum UserRole)
- Estado inicial: ACTIVE (según enum UserStatus)
- Límite de intentos de registro con mismo email: 3 por hora

**Entry Points:**
- **UI:** `/sign-up` - Página de registro (frontend/src/app/sign-up)
- **API:** `POST /api/auth/register` - Endpoint de creación de usuario
- **Webhook:** Clerk webhook para sincronización de usuarios

**Context References:**
- **Módulos:** `backend/src/auth`, `backend/src/users`
- **Servicios:** `AuthService`, `UsersService`, `EmailService`
- **Tablas:** `users` (User model en Prisma)
- **Componentes:** `SignUpForm`, `OAuthButtons` (frontend)
- **Middleware:** `ClerkMiddleware`, `ValidationMiddleware`

**Escenarios:**

**Precondiciones:**
- El usuario no está autenticado
- El email no existe previamente en el sistema
- Clerk está configurado y operativo

**Flujo Principal:**
1. Usuario accede a `/sign-up`
2. Sistema muestra formulario con campos: email, contraseña, firstName, lastName, phone (opcional), dateOfBirth (opcional)
3. Usuario completa el formulario y hace clic en "Registrarse"
4. Sistema valida formato de campos y políticas de contraseña
5. Sistema verifica unicidad del email contra la tabla `users`
6. Sistema crea usuario en Clerk vía API
7. Clerk genera clerkId y envía email de verificación
8. Sistema crea registro en tabla `users` con datos del usuario y clerkId
9. Sistema responde con token JWT y datos del usuario
10. Sistema redirige a dashboard principal (`/dashboard`)

**Escenarios Alternos:**

**EA-1: Email ya existe**
1. En paso 5, sistema detecta email duplicado
2. Sistema responde con código 409 (Conflict)
3. UI muestra mensaje: "Este email ya está registrado. ¿Deseas iniciar sesión?"
4. Se ofrece enlace a `/sign-in`

**EA-2: Registro con OAuth (Google/Facebook)**
1. Usuario hace clic en botón "Continuar con Google/Facebook"
2. Sistema redirige a flujo OAuth de Clerk
3. Usuario autoriza en provider externo
4. Clerk retorna con tokens y datos del usuario
5. Sistema verifica si email ya existe en `users`
6. Si no existe, crea usuario con datos de OAuth
7. Sistema autentica y redirige a dashboard

**EA-3: Validación de contraseña falla**
1. En paso 4, contraseña no cumple requisitos
2. Sistema muestra errores específicos:
   - "Mínimo 8 caracteres"
   - "Debe contener al menos una mayúscula"
   - "Debe contener al menos un número"
3. Usuario corrige y reenvía

**EA-4: Error en servicio Clerk**
1. En paso 6, Clerk API responde con error
2. Sistema registra error en logs
3. Sistema responde con código 503 (Service Unavailable)
4. UI muestra: "Servicio temporalmente no disponible. Intenta nuevamente."

**Postcondiciones:**
- Usuario creado en tabla `users` con estado ACTIVE y rol CUSTOMER
- Usuario creado en Clerk con clerkId vinculado
- Email de verificación enviado al usuario
- Usuario puede iniciar sesión pero con funcionalidades limitadas hasta verificar email
- Evento `user.created` emitido para analytics

**Criterios de Aceptación:**
1. **CA-1:** El formulario valida en tiempo real formato de email y requisitos de contraseña (mínimo 8 caracteres, 1 mayúscula, 1 número)
2. **CA-2:** El sistema rechaza registro si el email ya existe, mostrando mensaje descriptivo y link a login
3. **CA-3:** Al registrar exitosamente, se envía email de verificación y se crea registro en BD con campos: clerkId, email, firstName, lastName, role=CUSTOMER, status=ACTIVE
4. **CA-4:** El registro con OAuth (Google/Facebook) funciona correctamente, extrayendo firstName y lastName del perfil del provider
5. **CA-5:** Tras registro exitoso, el usuario es redirigido a `/dashboard` con sesión activa y token JWT válido
6. **CA-6:** Si Clerk falla, el sistema muestra mensaje de error apropiado y no deja registros inconsistentes en BD

**Story Points:** 5  
**Prioridad:** Must  
**Dependencias:** Ninguna

**Relación con Casos de Uso:**
- **UC-001: Autenticación de Usuarios** (include) - Esta HU implementa la parte de registro del caso de uso de autenticación
- **UC-002: Verificación de Email** (extend) - Extiende la funcionalidad con verificación de email post-registro

---

### HU-002: Inicio de sesión en la plataforma

**Título:** Como usuario registrado, quiero iniciar sesión en la plataforma para acceder a mi perfil y funcionalidades personalizadas.

**Descripción:**  
Sistema de autenticación que permite a los usuarios acceder a sus cuentas de forma segura mediante credenciales o métodos OAuth. Utiliza Clerk como proveedor de autenticación y JWT para gestión de sesiones.

**Requisitos Asociados:**
- **REQ-FUNC-003:** El sistema debe autenticar usuarios mediante email/contraseña y OAuth
- **REQ-FUNC-004:** El sistema debe bloquear temporalmente cuentas tras múltiples intentos fallidos
- **REQ-NF-003:** Las sesiones deben expirar tras 24 horas de inactividad
- **REQ-NF-004:** El sistema debe soportar autenticación biométrica en dispositivos móviles compatibles
- **REQ-NF-005:** El tiempo de autenticación no debe exceder 2 segundos

**Constraints:**
- Máximo 3 intentos de login fallidos antes de bloqueo temporal de 15 minutos
- Tokens JWT válidos por 24 horas (access token) y 7 días (refresh token)
- Usuario debe tener email verificado para acceso completo (verificación de Clerk)
- Sesiones concurrentes limitadas a 5 dispositivos
- Soporte obligatorio para HTTPS en producción

**Entry Points:**
- **UI:** `/sign-in` - Página de inicio de sesión (frontend/src/app/sign-in)
- **API:** `POST /api/auth/login` - Endpoint de autenticación
- **API:** `POST /api/auth/refresh` - Renovación de tokens
- **Middleware:** Clerk authentication en todas las rutas protegidas

**Context References:**
- **Módulos:** `backend/src/auth`, `backend/src/users`
- **Servicios:** `AuthService`, `UsersService`, `SessionService`
- **Tablas:** `users` (campo `lastLoginAt`)
- **Componentes:** `SignInForm`, `OAuthButtons`, `BiometricAuth` (frontend)
- **Middleware:** `ClerkMiddleware`, `JwtGuard`, `RateLimitGuard`
- **Guards:** `AuthGuard`, `RolesGuard`

**Escenarios:**

**Precondiciones:**
- El usuario tiene una cuenta registrada (HU-001)
- El usuario no está actualmente autenticado
- El sistema de autenticación Clerk está operativo

**Flujo Principal:**
1. Usuario accede a `/sign-in`
2. Sistema muestra formulario con campos: email y contraseña
3. Usuario ingresa credenciales y hace clic en "Iniciar Sesión"
4. Sistema valida formato de campos
5. Sistema envía credenciales a Clerk para verificación
6. Clerk valida credenciales y retorna clerkId
7. Sistema busca usuario en tabla `users` por clerkId
8. Sistema genera tokens JWT (access y refresh)
9. Sistema actualiza campo `lastLoginAt` en tabla `users`
10. Sistema responde con tokens y datos del usuario (id, email, firstName, lastName, role, avatar)
11. Frontend almacena tokens en storage seguro
12. Sistema redirige según rol:
    - CUSTOMER → `/dashboard`
    - PROVIDER → `/provider/dashboard`
    - ADMIN → `/admin/dashboard`

**Escenarios Alternos:**

**EA-1: Credenciales inválidas**
1. En paso 5, Clerk rechaza credenciales
2. Sistema incrementa contador de intentos fallidos
3. Sistema responde con código 401 (Unauthorized)
4. UI muestra: "Email o contraseña incorrectos"
5. Si intentos < 3, permite reintento
6. Si intentos = 3, bloquea cuenta por 15 minutos y muestra tiempo de espera

**EA-2: Login con OAuth (Google/Facebook)**
1. Usuario hace clic en "Continuar con Google/Facebook"
2. Sistema redirige a Clerk OAuth flow
3. Usuario autoriza en provider
4. Clerk retorna con tokens y clerkId
5. Sistema busca usuario por clerkId en tabla `users`
6. Si existe, continúa desde paso 8 del flujo principal
7. Si no existe, redirige a completar registro (HU-001)

**EA-3: Cuenta bloqueada temporalmente**
1. En paso 5, sistema detecta cuenta bloqueada
2. Sistema calcula tiempo restante de bloqueo
3. Sistema responde con código 403 (Forbidden)
4. UI muestra: "Cuenta bloqueada. Intenta nuevamente en X minutos"
5. UI ofrece opción de "Olvidé mi contraseña" (HU-003)

**EA-4: Email no verificado**
1. En paso 7, sistema detecta email no verificado en Clerk
2. Sistema responde con código 403 y flag `emailNotVerified: true`
3. UI muestra: "Debes verificar tu email antes de iniciar sesión"
4. UI ofrece botón "Reenviar email de verificación"

**EA-5: Autenticación biométrica (dispositivo móvil)**
1. Usuario accede desde app móvil y tiene biometría configurada
2. Sistema detecta capacidad biométrica del dispositivo
3. UI muestra opción "Usar huella/facial"
4. Usuario acepta y sistema solicita biometría al OS
5. OS valida y retorna resultado
6. Si exitoso, sistema usa refresh token almacenado para generar nuevo access token
7. Continúa desde paso 10 del flujo principal

**EA-6: Sesión recordada (Remember Me)**
1. Usuario marcó "Recordar sesión" en login previo
2. Sistema detecta refresh token válido en storage
3. Sistema valida refresh token con Clerk
4. Si válido, genera nuevo access token sin requerir credenciales
5. Continúa desde paso 10 del flujo principal

**Postcondiciones:**
- Usuario autenticado con sesión activa
- Tokens JWT (access y refresh) generados y almacenados
- Campo `lastLoginAt` actualizado en tabla `users`
- Evento `user.login` emitido para analytics
- Usuario redirigido a dashboard apropiado según rol

**Criterios de Aceptación:**
1. **CA-1:** El sistema autentica correctamente usuarios con credenciales válidas, generando tokens JWT y redirigiendo al dashboard correspondiente según rol (CUSTOMER, PROVIDER, ADMIN)
2. **CA-2:** Tras 3 intentos fallidos, el sistema bloquea la cuenta por 15 minutos y muestra mensaje con tiempo restante de bloqueo
3. **CA-3:** El login con OAuth (Google/Facebook) funciona correctamente, vinculando con cuenta existente o redirigiendo a completar registro
4. **CA-4:** El sistema muestra mensajes de error específicos: "Credenciales incorrectas", "Email no verificado", "Cuenta bloqueada"
5. **CA-5:** La autenticación biométrica funciona en dispositivos móviles compatibles, usando refresh token almacenado para generar nuevo access token
6. **CA-6:** El campo `lastLoginAt` se actualiza en la BD tras cada login exitoso, permitiendo tracking de actividad del usuario

**Story Points:** 3  
**Prioridad:** Must  
**Dependencias:** HU-001

**Relación con Casos de Uso:**
- **UC-001: Autenticación de Usuarios** (include) - Implementa la parte de login del caso de uso de autenticación
- **UC-003: Gestión de Sesiones** (include) - Incluye la creación y gestión de sesiones de usuario
- **UC-004: Control de Acceso por Roles** (extend) - Extiende con redirección según rol del usuario

---

### HU-003: Recuperación de contraseña

**Título:** Como usuario, quiero recuperar mi contraseña para poder acceder a mi cuenta si la olvidé.

**Descripción:**  
Flujo de recuperación de contraseña mediante envío de enlace único al email registrado.

**Criterios de Aceptación:**
1. Enlace "Olvidé mi contraseña" visible en la pantalla de login.
2. Formulario solicita el email del usuario registrado.
3. Se envía un enlace único de restablecimiento con expiración de 1 hora.
4. El enlace redirige a formulario para ingresar nueva contraseña.
5. Nueva contraseña debe cumplir los mismos requisitos de seguridad del registro.
6. Confirmación visual de que la contraseña fue cambiada exitosamente.
7. Notificación por email al usuario informando del cambio de contraseña.

**Puntos de Historia:** 3  
**Prioridad:** Must  
**Dependencias:** HU-001, HU-002

---

### HU-004: Gestión de perfil de usuario

**Título:** Como usuario registrado, quiero editar mi perfil personal para mantener mis datos actualizados y personalizar mi experiencia.

**Descripción:**  
Panel de configuración de perfil que permite al usuario actualizar sus datos personales y preferencias.

**Criterios de Aceptación:**
1. Campos editables: foto de perfil, nombre, apellido, teléfono, fecha de nacimiento.
2. Opción para configurar ubicación predeterminada para búsquedas.
3. Validación de formato para teléfono y otros campos.
4. Opción para cambiar contraseña con verificación de contraseña actual.
5. Los cambios se guardan en la base de datos y se reflejan inmediatamente en la interfaz.
6. Confirmación visual tras guardar cambios exitosamente.
7. Opción para eliminar cuenta con doble confirmación.

**Puntos de Historia:** 3  
**Prioridad:** Should  
**Dependencias:** HU-002

---

### HU-005: Búsqueda de autolavados por ubicación

**Título:** Como usuario, quiero buscar autolavados cercanos a mi ubicación para encontrar opciones convenientes.

**Descripción:**  
Motor de búsqueda geolocalizado que permite encontrar proveedores de autolavado según la ubicación del usuario o una dirección específica. Utiliza Google Maps API para geocodificación y consultas espaciales en PostgreSQL con extensión PostGIS para búsqueda eficiente por radio.

**Requisitos Asociados:**
- **REQ-FUNC-005:** El sistema debe permitir búsqueda por dirección, comuna, ciudad o coordenadas GPS
- **REQ-FUNC-006:** El sistema debe ordenar resultados por distancia de menor a mayor
- **REQ-FUNC-007:** El sistema debe permitir configurar radio de búsqueda (1, 5, 10, 20 km)
- **REQ-NF-006:** Las consultas de búsqueda deben responder en menos de 2 segundos
- **REQ-NF-007:** El sistema debe manejar correctamente ubicaciones sin resultados
- **REQ-NF-008:** La búsqueda debe ser responsive y funcionar en dispositivos móviles

**Constraints:**
- Google Maps API requiere API key válida y tiene límites de cuota
- Búsquedas limitadas a territorio de Chile (región validation)
- Radio máximo de búsqueda: 50 km
- Resultados limitados a 100 proveedores por búsqueda (paginación)
- Solo muestra proveedores con status ACTIVE (no PENDING_APPROVAL o SUSPENDED)
- Índices espaciales requeridos en tabla `providers` para performance
- Precisión de GPS en móviles: ±10-50 metros

**Entry Points:**
- **UI:** `/` (home page con barra de búsqueda principal)
- **UI:** `/search` - Página de resultados de búsqueda
- **UI:** `/map` - Vista de mapa con resultados
- **API:** `GET /api/search?query=<address>&lat=<lat>&lng=<lng>&radius=<km>`
- **API:** `GET /api/search/nearby?lat=<lat>&lng=<lng>&radius=<km>`
- **API:** `POST /api/search/geocode` - Convertir dirección a coordenadas

**Context References:**
- **Módulos:** `backend/src/search`, `backend/src/maps`, `backend/src/providers`
- **Servicios:** `SearchService`, `MapsService`, `ProvidersService`, `GeolocationService`
- **Tablas:** `providers` (campos: latitude, longitude, status, address, city, region)
- **Índices:** `provider_location_idx` (GiST index on latitude, longitude)
- **Componentes:** `SearchBar`, `SearchResults`, `ProviderCard`, `LocationPicker` (frontend)
- **Hooks:** `useGeolocation`, `useSearch`, `useDebounce`
- **External APIs:** Google Maps Geocoding API, Google Maps Places API

**Escenarios:**

**Precondiciones:**
- Google Maps API está configurada y operativa
- La tabla `providers` tiene datos con coordenadas válidas
- El navegador tiene permisos de geolocalización (para GPS) o usuario puede ingresar dirección manualmente

**Flujo Principal:**
1. Usuario accede a la página principal (`/`)
2. Sistema muestra barra de búsqueda prominente con placeholder "Buscar por dirección, comuna o ciudad"
3. Usuario puede elegir:
   - **Opción A:** Hacer clic en botón "Usar mi ubicación" 
   - **Opción B:** Escribir dirección manualmente
4. **Si Opción A:** 
   - Sistema solicita permisos de geolocalización al navegador
   - Navegador retorna coordenadas (lat, lng)
   - Sistema muestra ubicación detectada en el input
5. **Si Opción B:**
   - Usuario escribe dirección (ej: "Av. Providencia 1234, Santiago")
   - Sistema usa Google Maps Geocoding API para convertir a coordenadas
   - Sistema valida que la dirección esté en Chile
6. Usuario selecciona radio de búsqueda del dropdown (1, 5, 10, 20 km) - Default: 5 km
7. Usuario hace clic en "Buscar" o presiona Enter
8. Sistema realiza consulta espacial en tabla `providers`:
   ```sql
   SELECT * FROM providers 
   WHERE status = 'ACTIVE' 
   AND ST_DWithin(
     ST_MakePoint(longitude, latitude)::geography,
     ST_MakePoint(<user_lng>, <user_lat>)::geography,
     <radius_meters>
   )
   ORDER BY ST_Distance(
     ST_MakePoint(longitude, latitude)::geography,
     ST_MakePoint(<user_lng>, <user_lat>)::geography
   )
   LIMIT 100;
   ```
9. Sistema calcula distancia exacta para cada proveedor
10. Sistema agrega datos relacionados: rating, precio desde, imagen principal, servicios count
11. Sistema responde con array de proveedores ordenados por distancia
12. Frontend redirige a `/results?lat=<lat>&lng=<lng>&radius=<radius>`
13. Sistema muestra resultados en tarjetas (ProviderCard) con:
    - Nombre del negocio
    - Distancia (ej: "1.2 km")
    - Rating promedio (estrellas)
    - Precio desde (ej: "Desde $10.000")
    - Imagen principal
    - Botón "Ver detalles"
14. Sistema muestra contador: "X autolavados encontrados en radio de Y km"

**Escenarios Alternos:**

**EA-1: Permisos de geolocalización denegados**
1. En paso 4, usuario deniega permisos de geolocalización
2. Sistema captura error y muestra modal informativo
3. UI muestra: "Para usar tu ubicación actual, debes habilitar permisos de ubicación en tu navegador"
4. Sistema ofrece opción de "Ingresar dirección manualmente"
5. Continúa con Opción B del flujo principal

**EA-2: No se encontraron resultados**
1. En paso 8, la consulta retorna 0 resultados
2. Sistema responde con array vacío y flag `noResults: true`
3. UI muestra mensaje: "No encontramos autolavados en un radio de X km"
4. Sistema sugiere:
   - "Intenta ampliar el radio de búsqueda"
   - Botón para cambiar radio a siguiente valor (5→10→20 km)
   - "O busca en otra ubicación"

**EA-3: Dirección no encontrada o inválida**
1. En paso 5, Google Maps Geocoding API no encuentra la dirección
2. API responde con status ZERO_RESULTS
3. Sistema responde con código 404
4. UI muestra: "No pudimos encontrar esa dirección. Por favor verifica la escritura"
5. UI mantiene el texto en el input para que usuario pueda corregir

**EA-4: Dirección fuera de Chile**
1. En paso 5, geocoding retorna coordenadas fuera de Chile
2. Sistema valida país del resultado (country code != "CL")
3. Sistema responde con código 400
4. UI muestra: "Por ahora solo operamos en Chile. Ingresa una dirección en Chile"

**EA-5: Error en Google Maps API**
1. En paso 5 u 8, Google Maps API falla o excede cuota
2. Sistema captura error y registra en logs
3. Sistema responde con código 503
4. UI muestra: "Servicio de búsqueda temporalmente no disponible. Intenta nuevamente"
5. Sistema ofrece fallback: búsqueda por ciudad/comuna sin geocoding exacto

**EA-6: Búsqueda desde ubicación guardada**
1. Usuario autenticado tiene `defaultLatitude` y `defaultLongitude` en su perfil
2. Al cargar página principal, sistema detecta ubicación por defecto
3. Sistema pre-llena el input con `defaultAddress`
4. Usuario puede aceptar y buscar directamente, o cambiar ubicación

**EA-7: Búsqueda con historial (usuario autenticado)**
1. Usuario autenticado realiza búsqueda exitosa
2. Sistema guarda registro en tabla `search_history`:
   - userId, query, latitude, longitude, radius, timestamp
3. En próxima visita, sistema muestra "Búsquedas recientes" debajo del input
4. Usuario puede hacer clic en búsqueda reciente para repetirla

**Postcondiciones:**
- Resultados de búsqueda mostrados ordenados por distancia
- Ubicación y radio de búsqueda guardados en session storage para mantener contexto
- Si usuario autenticado, búsqueda guardada en `search_history`
- Evento `search.performed` emitido para analytics con: userId (si autenticado), latitude, longitude, radius, resultsCount
- Estado de búsqueda disponible para otros componentes (mapa, filtros)

**Criterios de Aceptación:**
1. **CA-1:** El sistema permite buscar por dirección escrita manualmente, geocodificando correctamente con Google Maps API y validando que esté en Chile
2. **CA-2:** El botón "Usar mi ubicación" solicita permisos GPS y obtiene coordenadas del navegador con precisión de ±50 metros
3. **CA-3:** Los resultados se ordenan por distancia ascendente, mostrando distancia exacta en km con 1 decimal (ej: "2.3 km")
4. **CA-4:** El usuario puede cambiar el radio de búsqueda (1, 5, 10, 20 km) y los resultados se actualizan dinámicamente sin recargar página
5. **CA-5:** Cuando no hay resultados, el sistema muestra mensaje claro y sugiere ampliar radio o cambiar ubicación
6. **CA-6:** La búsqueda responde en menos de 2 segundos y cada ProviderCard muestra: nombre, distancia, rating, precio desde, imagen principal
7. **CA-7:** Para usuarios autenticados, las búsquedas se guardan en historial (tabla `search_history`) y se muestran como "Búsquedas recientes"

**Story Points:** 8  
**Prioridad:** Must  
**Dependencias:** Ninguna

**Relación con Casos de Uso:**
- **UC-005: Búsqueda de Proveedores** (include) - Implementa el caso de uso principal de búsqueda
- **UC-006: Geolocalización** (include) - Incluye funcionalidad de detección de ubicación
- **UC-007: Geocodificación** (include) - Incluye conversión de direcciones a coordenadas
- **UC-011: Historial de Búsquedas** (extend) - Extiende con guardado de historial para usuarios autenticados

---

### HU-006: Búsqueda avanzada con filtros

**Título:** Como usuario, quiero aplicar filtros avanzados a mi búsqueda para encontrar autolavados que cumplan con mis necesidades específicas.

**Descripción:**  
Sistema de filtros múltiples que permite refinar búsquedas según diferentes criterios.

**Criterios de Aceptación:**
1. Filtros disponibles: tipo de servicio, rango de precio, rating mínimo, horario de atención, acepta reservas.
2. Filtros se aplican de forma dinámica sin recargar página.
3. Indicador visual del número de filtros activos.
4. Opción para limpiar todos los filtros con un clic.
5. Los filtros se mantienen al navegar entre resultados.
6. Combinación lógica de múltiples filtros (AND).
7. Contador de resultados encontrados actualizado en tiempo real.

**Puntos de Historia:** 5  
**Prioridad:** Should  
**Dependencias:** HU-005

---

### HU-007: Visualización de mapa interactivo

**Título:** Como usuario, quiero ver los autolavados en un mapa interactivo para visualizar su ubicación y seleccionar opciones cercanas.

**Descripción:**  
Mapa interactivo con marcadores de proveedores que permite exploración visual de opciones.

**Criterios de Aceptación:**
1. Mapa integrado con Google Maps muestra todos los resultados como marcadores.
2. Marcadores diferenciados por color según rating o tipo de servicio.
3. Click en marcador muestra card con información resumida del proveedor.
4. Botón para centrar mapa en ubicación actual del usuario.
5. Zoom y navegación fluida del mapa.
6. Actualización de resultados al mover/hacer zoom en el mapa.
7. Opción para alternar entre vista de lista y vista de mapa.
8. Cálculo y visualización de rutas desde ubicación actual al proveedor seleccionado.

**Puntos de Historia:** 8  
**Prioridad:** Should  
**Dependencias:** HU-005  
**Nota técnica:** Complejidad alta por integración profunda con Google Maps API y sincronización estado lista-mapa.

---

### HU-008: Comparación de precios entre proveedores

**Título:** Como usuario, quiero comparar precios y servicios entre diferentes autolavados para tomar la mejor decisión.

**Descripción:**  
Herramienta de comparación lado a lado que facilita la evaluación de múltiples proveedores.

**Criterios de Aceptación:**
1. Opción para agregar proveedores a una lista de comparación (máximo 4).
2. Tabla comparativa muestra: nombre, precios por servicio, rating, distancia, horarios, servicios incluidos.
3. Destacado visual de mejor precio para cada servicio.
4. Opción para eliminar proveedores de la comparación.
5. Botón de acción rápida para reservar desde la tabla comparativa.
6. Comparación persiste al navegar (guardada en sesión).
7. Exportar comparación como PDF o imagen para compartir.
8. Indicadores visuales de diferencia de precio porcentual.

**Puntos de Historia:** 8  
**Prioridad:** Must  
**Dependencias:** HU-005  
**Nota técnica:** Funcionalidad core del sistema como agregador, requiere diseño UX cuidadoso.

---

### HU-009: Visualización de detalles del proveedor

**Título:** Como usuario, quiero ver información detallada de un autolavado para conocer todos sus servicios, precios y características.

**Descripción:**  
Página de perfil completo del proveedor con toda la información relevante.

**Criterios de Aceptación:**
1. Información mostrada: nombre, descripción, dirección completa, teléfono, email, sitio web.
2. Galería de imágenes del local y servicios.
3. Listado completo de servicios con precios, descripciones y duración.
4. Horarios de atención por día de la semana.
5. Mapa embebido mostrando ubicación exacta.
6. Sección de reseñas y calificaciones de otros usuarios.
7. Rating promedio y cantidad de reseñas.
8. Botón destacado para reservar servicio.
9. Información sobre promociones activas.

**Puntos de Historia:** 5  
**Prioridad:** Must  
**Dependencias:** HU-005

---

### HU-010: Gestión de lista de favoritos

**Título:** Como usuario registrado, quiero guardar mis autolavados favoritos para acceder rápidamente a ellos en futuras búsquedas.

**Descripción:**  
Sistema de marcadores que permite al usuario crear y gestionar una lista de proveedores favoritos.

**Criterios de Aceptación:**
1. Botón de "favorito" (corazón) visible en cada card de proveedor.
2. Toggle para agregar/quitar de favoritos con feedback visual inmediato.
3. Página dedicada "Mis Favoritos" accesible desde menú principal.
4. Favoritos se sincronizan entre dispositivos (guardados en BD).
5. Opción para organizar favoritos (ordenar, categorizar).
6. Notificaciones opcionales cuando favoritos tienen nuevas promociones.
7. Contador de favoritos en el menú de usuario.

**Puntos de Historia:** 5  
**Prioridad:** Should  
**Dependencias:** HU-002, HU-005

---

### HU-011: Visualización de historial de búsquedas

**Título:** Como usuario registrado, quiero ver mi historial de búsquedas para repetir búsquedas frecuentes rápidamente.

**Descripción:**  
Registro automático de búsquedas realizadas con opción de reutilización.

**Criterios de Aceptación:**
1. Sección "Historial" accesible desde el perfil de usuario.
2. Listado de últimas 20 búsquedas con fecha y filtros aplicados.
3. Click en una búsqueda histórica la ejecuta nuevamente.
4. Opción para eliminar búsquedas individuales del historial.
5. Opción para limpiar todo el historial.
6. Búsquedas se guardan con: ubicación, filtros, fecha.
7. Privacidad: historial visible solo para el usuario propietario.

**Puntos de Historia:** 3  
**Prioridad:** Could  
**Dependencias:** HU-002, HU-005

---

### HU-012: Sistema de reseñas y calificaciones

**Título:** Como usuario, quiero dejar reseñas y calificaciones sobre autolavados para compartir mi experiencia y ayudar a otros usuarios.

**Descripción:**  
Sistema completo de reviews que permite a los usuarios evaluar servicios utilizados.

**Criterios de Aceptación:**
1. Formulario de reseña incluye: calificación general (1-5 estrellas), título, comentario.
2. Criterios específicos de evaluación: calidad del servicio, limpieza, relación precio-calidad, amabilidad del personal.
3. Validación: solo usuarios con reservas completadas pueden dejar reseñas.
4. Opción para subir hasta 3 fotos con la reseña.
5. Sistema de moderación: reseñas pasan por aprobación antes de publicarse.
6. Usuarios pueden editar sus reseñas dentro de 7 días.
7. Proveedores pueden responder a reseñas.
8. Reseñas se ordenan por más recientes o más útiles (likes).
9. Detección de lenguaje inapropiado automática.

**Puntos de Historia:** 8  
**Prioridad:** Must  
**Dependencias:** HU-013  
**Nota técnica:** Requiere sistema de moderación y algoritmo de detección de contenido inapropiado.

---

### HU-013: Reserva de servicio de lavado

**Título:** Como usuario, quiero reservar un servicio de autolavado para asegurar mi turno en el horario deseado.

**Descripción:**  
Sistema de reservas online que permite al usuario agendar servicios con los proveedores. Incluye validación de disponibilidad en tiempo real, gestión de conflictos de horarios, y notificaciones automáticas a ambas partes. El sistema maneja concurrencia para evitar doble-booking y sincroniza con el calendario del proveedor.

**Requisitos Asociados:**
- **REQ-FUNC-010:** El sistema debe validar disponibilidad en tiempo real antes de confirmar reserva
- **REQ-FUNC-011:** El sistema debe prevenir doble-booking mediante bloqueos transaccionales
- **REQ-FUNC-012:** El sistema debe enviar confirmaciones por email a usuario y proveedor
- **REQ-FUNC-013:** El sistema debe generar código único de reserva (QR)
- **REQ-NF-010:** La reserva debe completarse en menos de 3 segundos
- **REQ-NF-011:** El sistema debe manejar concurrencia de hasta 100 reservas simultáneas
- **REQ-NF-012:** Las transacciones de reserva deben ser ACID-compliant

**Constraints:**
- Usuario debe estar autenticado (role: CUSTOMER)
- Proveedor debe tener status ACTIVE
- Servicio debe estar disponible (status: ACTIVE, isAvailable: true)
- Antelación mínima configurable por proveedor (default: 60 minutos)
- Antelación máxima: 7 días (configurable: `maxAdvanceBooking`)
- Máximo 3 reservas activas simultáneas por usuario
- Duración de reserva según configuración del servicio
- No se permiten reservas en slots ya ocupados (validación con lock)
- Cancelación permitida hasta 2 horas antes del horario reservado

**Entry Points:**
- **UI:** `/provider/[id]` - Perfil del proveedor con botón "Reservar"
- **UI:** `/booking/new?providerId=<id>&serviceId=<id>` - Página de reserva
- **UI:** `/booking/confirmation/[id]` - Confirmación de reserva
- **API:** `POST /api/bookings` - Crear nueva reserva
- **API:** `GET /api/bookings/availability?providerId=<id>&date=<date>` - Consultar disponibilidad
- **API:** `GET /api/bookings/[id]` - Detalles de una reserva
- **Webhook:** Notificación a proveedor vía email/push

**Context References:**
- **Módulos:** `backend/src/bookings`, `backend/src/notifications`, `backend/src/email`
- **Servicios:** `BookingsService`, `NotificationsService`, `EmailService`, `QRCodeService`
- **Tablas:** `bookings`, `services`, `providers`, `users`, `notifications`
- **Componentes:** `BookingForm`, `CalendarPicker`, `TimeSlotSelector`, `VehicleInfoForm`, `BookingConfirmation` (frontend)
- **Jobs:** `BookingReminderJob` (recordatorios 24h y 1h antes)
- **Guards:** `AuthGuard`, `BookingLimitGuard`

**Escenarios:**

**Precondiciones:**
- Usuario está autenticado
- Usuario tiene menos de 3 reservas activas
- Proveedor tiene status ACTIVE y acceptsBookings: true
- Servicio seleccionado tiene status ACTIVE y isAvailable: true
- Proveedor tiene disponibilidad configurada en `operatingHours`

**Flujo Principal:**
1. Usuario navega al perfil del proveedor (`/provider/[id]`)
2. Usuario hace clic en servicio deseado y botón "Reservar"
3. Sistema verifica autenticación; si no autenticado, redirige a `/sign-in` con returnUrl
4. Sistema redirige a `/booking/new?providerId=<id>&serviceId=<id>`
5. Sistema carga datos del proveedor, servicio y disponibilidad:
   ```
   GET /api/bookings/availability?providerId=<id>&date=<today>
   ```
6. Sistema muestra formulario de reserva con:
   - Resumen del servicio (nombre, precio, duración)
   - DatePicker para seleccionar fecha (próximos 7 días)
   - TimeSlotSelector mostrando horarios disponibles (verde) y ocupados (gris)
   - Formulario de vehículo: marca, modelo, patente, color
   - Campo opcional "Notas especiales" (max 500 caracteres)
7. Usuario selecciona fecha; sistema actualiza slots disponibles vía API
8. Usuario selecciona hora disponible
9. Usuario completa datos del vehículo y notas opcionales
10. Sistema muestra resumen de reserva:
    - Proveedor y dirección
    - Servicio y duración
    - Fecha y hora seleccionada
    - Precio total
11. Usuario hace clic en "Confirmar Reserva"
12. Sistema inicia transacción de base de datos
13. Sistema valida nuevamente disponibilidad con row-level lock:
    ```sql
    SELECT * FROM bookings 
    WHERE provider_id = <id> 
    AND status NOT IN ('CANCELLED', 'COMPLETED')
    AND start_time <= <selected_time> + <duration>
    AND end_time >= <selected_time>
    FOR UPDATE;
    ```
14. Si slot disponible, sistema crea registro en tabla `bookings`:
    ```javascript
    {
      userId, providerId, serviceId,
      startTime, endTime,
      status: 'PENDING', // o 'CONFIRMED' según config
      vehicleInfo: { brand, model, plate, color },
      specialNotes,
      totalPrice,
      confirmationCode: generateUniqueCode(),
      qrCode: generateQRCode()
    }
    ```
15. Sistema commit de transacción
16. Sistema genera código QR con datos de la reserva
17. Sistema envía notificaciones:
    - Email al usuario con confirmación y QR
    - Email al proveedor con detalles de nueva reserva
    - Notificación push al proveedor (si configurado)
    - Registro en tabla `notifications` para ambos
18. Sistema programa jobs de recordatorio:
    - 24 horas antes: recordatorio al usuario
    - 1 hora antes: recordatorio final al usuario
19. Sistema responde con ID de reserva y datos completos
20. Frontend redirige a `/booking/confirmation/[id]`
21. Sistema muestra página de confirmación con:
    - ✅ "Reserva confirmada exitosamente"
    - Código de reserva único
    - QR code para mostrar en el local
    - Resumen completo de la reserva
    - Botones: "Agregar a calendario", "Ver mis reservas", "Cancelar reserva"

**Escenarios Alternos:**

**EA-1: Usuario no autenticado**
1. En paso 3, sistema detecta usuario no autenticado
2. Sistema guarda parámetros de reserva en session storage
3. Sistema redirige a `/sign-in?returnUrl=/booking/new?providerId=<id>&serviceId=<id>`
4. Tras login exitoso, sistema recupera parámetros y continúa desde paso 4

**EA-2: Usuario excede límite de reservas activas**
1. En paso 4, sistema consulta reservas activas del usuario
2. Sistema detecta que tiene 3 o más reservas con status PENDING o CONFIRMED
3. Sistema responde con código 429 (Too Many Requests)
4. UI muestra modal: "Tienes el máximo de reservas activas (3). Por favor completa o cancela una reserva existente para crear una nueva"
5. UI ofrece botón "Ver mis reservas" que redirige a `/user/bookings`

**EA-3: Horario ya no disponible (race condition)**
1. Entre paso 8 y paso 13, otro usuario reserva el mismo horario
2. En paso 13, la consulta con lock retorna resultados (conflicto)
3. Sistema rollback de transacción
4. Sistema responde con código 409 (Conflict)
5. UI muestra: "Lo sentimos, este horario acaba de ser reservado. Por favor selecciona otro horario"
6. Sistema actualiza automáticamente slots disponibles en el calendario
7. Usuario debe seleccionar otro horario

**EA-4: Servicio no disponible**
1. En paso 5, sistema detecta que el servicio tiene isAvailable: false
2. Sistema responde con código 410 (Gone)
3. UI muestra: "Este servicio ya no está disponible. Por favor selecciona otro servicio"
4. Sistema redirige al perfil del proveedor

**EA-5: Proveedor no acepta reservas**
1. En paso 5, sistema detecta provider.acceptsBookings: false
2. Sistema responde con código 403
3. UI muestra: "Este proveedor no acepta reservas online actualmente. Por favor contacta directamente: [phone]"

**EA-6: Fecha fuera de rango permitido**
1. En paso 7, usuario intenta seleccionar fecha más allá de maxAdvanceBooking
2. DatePicker deshabilita fechas fuera de rango
3. Si usuario manipula request directamente, backend valida en paso 13
4. Sistema responde con código 400
5. UI muestra: "Solo puedes reservar con hasta X días de anticipación"

**EA-7: No hay horarios disponibles**
1. En paso 7, para la fecha seleccionada no hay slots disponibles
2. Sistema responde con array vacío de slots
3. UI muestra: "No hay horarios disponibles para esta fecha"
4. Sistema sugiere: "Intenta con otra fecha" o muestra próxima fecha con disponibilidad

**EA-8: Error al generar QR o enviar email**
1. En paso 16 o 17, falla generación de QR o envío de email
2. Sistema registra error en logs pero NO rollback de la reserva
3. Reserva se crea exitosamente en BD
4. Sistema marca la reserva para reintento de notificación (background job)
5. Sistema continúa con el flujo, mostrando confirmación
6. UI incluye advertencia: "Reserva creada pero puede haber demoras en la confirmación por email"

**Postcondiciones:**
- Reserva creada en tabla `bookings` con status PENDING o CONFIRMED
- Slot horario bloqueado para otros usuarios
- Notificaciones enviadas a usuario y proveedor
- Jobs de recordatorio programados
- QR code generado y almacenado
- Evento `booking.created` emitido para analytics
- Contador `totalBookings` del proveedor incrementado

**Criterios de Aceptación:**
1. **CA-1:** El sistema muestra calendario interactivo con horarios disponibles (verde) y ocupados (gris), actualizándose en tiempo real al cambiar fecha
2. **CA-2:** El sistema valida disponibilidad con lock transaccional antes de confirmar, previniendo doble-booking incluso con 100 reservas simultáneas
3. **CA-3:** Al confirmar reserva, el sistema crea registro en BD con todos los datos (userId, providerId, serviceId, startTime, endTime, vehicleInfo, status, confirmationCode, qrCode) y genera código único
4. **CA-4:** El sistema envía emails de confirmación a usuario (con QR) y proveedor (con detalles de la reserva) en menos de 30 segundos
5. **CA-5:** El sistema programa recordatorios automáticos: 24h antes y 1h antes del horario reservado
6. **CA-6:** Si un horario ya no está disponible (race condition), el sistema muestra mensaje claro y actualiza automáticamente los horarios disponibles sin refrescar página
7. **CA-7:** El usuario puede agregar la reserva a su calendario (formato .ics) y acceder a página de confirmación con QR code y código único

**Story Points:** 8  
**Prioridad:** Must  
**Dependencias:** HU-002 (Login), HU-009 (Detalles del proveedor), HU-021 (Configuración de horarios del proveedor)

**Relación con Casos de Uso:**
- **UC-010: Gestión de Reservas** (include) - Implementa la creación de reservas
- **UC-011: Validación de Disponibilidad** (include) - Incluye verificación de slots disponibles
- **UC-012: Notificaciones de Reserva** (include) - Incluye envío de confirmaciones
- **UC-013: Prevención de Conflictos** (include) - Manejo de concurrencia y doble-booking
- **UC-014: Generación de QR** (extend) - Extiende con código QR para check-in

---

### HU-014: Cancelación de reserva

**Título:** Como usuario, quiero cancelar una reserva para liberar el turno si no puedo asistir.

**Descripción:**  
Gestión de cancelaciones con políticas definidas y comunicación automática.

**Criterios de Aceptación:**
1. En "Mis Reservas", botón de cancelar visible para reservas futuras.
2. Política de cancelación visible: permitida hasta 2 horas antes.
3. Confirmación doble antes de cancelar (evitar cancelaciones accidentales).
4. Campo opcional para indicar motivo de cancelación.
5. Se envía notificación al proveedor de la cancelación.
6. Email de confirmación de cancelación al usuario.
7. La disponibilidad se actualiza inmediatamente para otros usuarios.
8. Reservas pasadas no pueden cancelarse.

**Puntos de Historia:** 3  
**Prioridad:** Must  
**Dependencias:** HU-013

---

### HU-015: Visualización de historial de reservas

**Título:** Como usuario, quiero ver mi historial de reservas para llevar control de los servicios que he utilizado.

**Descripción:**  
Registro histórico completo de todas las reservas del usuario.

**Criterios de Aceptación:**
1. Sección "Mis Reservas" accesible desde el perfil de usuario.
2. Pestañas para: "Próximas", "Pasadas", "Canceladas".
3. Cada reserva muestra: proveedor, servicio, fecha/hora, estado, precio.
4. Opción para ver detalles completos de cada reserva.
5. Desde reservas pasadas, acceso directo para dejar reseña.
6. Opción para repetir una reserva pasada (pre-llenado de datos).
7. Exportar historial completo a PDF.

**Puntos de Historia:** 3  
**Prioridad:** Should  
**Dependencias:** HU-013

---

### HU-016: Notificaciones push de recordatorios

**Título:** Como usuario, quiero recibir notificaciones sobre mis reservas y actualizaciones relevantes para no perder información importante.

**Descripción:**  
Sistema de notificaciones push configurable que mantiene al usuario informado.

**Criterios de Aceptación:**
1. Notificación de confirmación al realizar una reserva.
2. Recordatorio 24 horas antes de la cita.
3. Recordatorio 1 hora antes de la cita.
4. Alerta si el proveedor cancela o modifica la reserva.
5. Notificaciones de nuevas promociones en favoritos (opcional).
6. Alerta cuando bajan precios en búsquedas guardadas.
7. Configuración granular en perfil: activar/desactivar por tipo de notificación.
8. Soporte para iOS y Android (usando Firebase Cloud Messaging).
9. Notificaciones in-app además de push.

**Puntos de Historia:** 5  
**Prioridad:** Should  
**Dependencias:** HU-002, HU-013

---

### HU-017: Recomendaciones personalizadas con IA

**Título:** Como usuario, quiero recibir recomendaciones personalizadas de autolavados para descubrir opciones que se ajusten a mis preferencias.

**Descripción:**  
Motor de recomendaciones basado en IA (OpenAI) que analiza el historial y preferencias del usuario para sugerir proveedores relevantes. Utiliza algoritmos de collaborative filtering, análisis de patrones de búsqueda, y procesamiento de lenguaje natural para entender preferencias implícitas y explícitas. El sistema aprende continuamente de las interacciones del usuario.

**Requisitos Asociados:**
- **REQ-FUNC-020:** El sistema debe analizar historial de búsquedas, reservas y favoritos del usuario
- **REQ-FUNC-021:** El sistema debe generar recomendaciones personalizadas usando OpenAI API
- **REQ-FUNC-022:** El sistema debe explicar por qué recomienda cada proveedor
- **REQ-FUNC-023:** El sistema debe permitir feedback de recomendaciones (like/dislike)
- **REQ-NF-020:** Las recomendaciones deben generarse en menos de 5 segundos
- **REQ-NF-021:** El sistema debe manejar costos de API de OpenAI eficientemente (caching)
- **REQ-NF-022:** Precisión de recomendaciones: >70% de conversión a click o reserva

**Constraints:**
- Requiere mínimo 3 interacciones del usuario (búsquedas o reservas) para generar recomendaciones
- OpenAI API tiene límites de rate y costos por token
- Recomendaciones se actualizan máximo 1 vez al día por usuario (caching)
- Máximo 10 recomendaciones por sesión
- Solo proveedores con status ACTIVE y rating ≥ 3.5
- Exclusión de proveedores que usuario marcó como "No volver a recomendar"
- Privacidad: datos de usuario no se comparten con OpenAI más allá del análisis

**Entry Points:**
- **UI:** `/dashboard` - Sección "Recomendado para ti"
- **UI:** `/recommendations` - Página dedicada de recomendaciones
- **API:** `GET /api/ia/recommendations` - Obtener recomendaciones personalizadas
- **API:** `POST /api/ia/recommendations/feedback` - Enviar feedback (like/dislike)
- **API:** `POST /api/ia/recommendations/exclude` - Excluir proveedor de futuras recomendaciones
- **Cron Job:** Actualización diaria de recomendaciones para usuarios activos

**Context References:**
- **Módulos:** `backend/src/ia`, `backend/src/analytics`, `backend/src/providers`
- **Servicios:** `IaService`, `RecommendationEngine`, `OpenAIService`, `AnalyticsService`
- **Tablas:** `users`, `search_history`, `bookings`, `favorites`, `reviews`, `recommendation_feedback`
- **Componentes:** `RecommendationCarousel`, `RecommendationCard`, `RecommendationExplanation` (frontend)
- **Hooks:** `useRecommendations`, `useRecommendationFeedback`
- **External APIs:** OpenAI API (GPT-4 o GPT-3.5-turbo)
- **Cache:** Redis para almacenar recomendaciones generadas (TTL: 24h)

**Escenarios:**

**Precondiciones:**
- Usuario está autenticado
- Usuario tiene al menos 3 interacciones históricas (búsquedas, reservas o favoritos)
- OpenAI API está configurada y operativa
- Sistema de caché (Redis) está disponible

**Flujo Principal:**
1. Usuario autenticado accede a `/dashboard`
2. Sistema detecta que debe mostrar sección "Recomendado para ti"
3. Sistema verifica si existen recomendaciones cacheadas para el usuario:
   ```
   Redis: GET recommendations:user:<userId>
   ```
4. **Si NO hay caché:**
   - Sistema inicia proceso de generación de recomendaciones
   - Sistema recopila datos del usuario:
     ```javascript
     {
       searchHistory: últimas 20 búsquedas con ubicaciones frecuentes,
       bookingHistory: últimas 10 reservas con servicios utilizados,
       favorites: lista de proveedores favoritos,
       reviews: reviews dejadas con sentimiento,
       preferences: rango de precios, tipos de servicio preferidos,
       demographics: ciudad, edad (si disponible)
     }
     ```
   - Sistema analiza patrones:
     - Ubicaciones frecuentes (clustering de lat/lng)
     - Servicios más reservados (ej: lavado completo, encerado)
     - Rango de precios preferido (percentil 25-75 de reservas)
     - Días/horarios preferidos
     - Rating mínimo aceptable (basado en favoritos/reservas)
   - Sistema construye prompt para OpenAI:
     ```
     "Analiza el perfil de usuario y recomienda autolavados:
     - Búsquedas frecuentes en: [ubicaciones]
     - Servicios preferidos: [tipos]
     - Rango de precio: [min-max]
     - Rating mínimo: [rating]
     Proveedores disponibles: [lista con nombre, ubicación, servicios, precio, rating]
     Genera top 10 recomendaciones con explicación breve de cada una."
     ```
   - Sistema envía request a OpenAI API (GPT-4)
   - OpenAI analiza y retorna lista priorizada con explicaciones
5. Sistema consulta datos completos de proveedores recomendados en tabla `providers`
6. Sistema filtra proveedores:
   - status = ACTIVE
   - rating ≥ 3.5
   - NO en lista de excluidos del usuario
7. Sistema calcula "Relevance Score" para cada proveedor (0-100):
   ```javascript
   score = (
     distanceFactor * 0.3 +      // cercanía a ubicaciones frecuentes
     priceFactor * 0.25 +         // ajuste a rango de precios
     ratingFactor * 0.25 +        // rating alto
     similarityFactor * 0.2       // similitud con favoritos
   ) * 100
   ```
8. Sistema ordena por Relevance Score descendente
9. Sistema formatea respuesta:
   ```javascript
   {
     recommendations: [
       {
         provider: {id, name, address, rating, priceRange, image},
         relevanceScore: 95,
         reason: "Popular en [ubicación], excelente rating y servicios que coinciden con tus preferencias",
         badges: ["Cerca de ti", "Precio justo", "Muy bien valorado"]
       },
       // ... más recomendaciones
     ],
     updatedAt: timestamp
   }
   ```
10. Sistema guarda en caché (Redis, TTL 24h):
    ```
    Redis: SET recommendations:user:<userId> <json> EX 86400
    ```
11. Sistema registra evento `recommendations.generated` en analytics
12. Sistema responde con lista de recomendaciones
13. Frontend renderiza sección "Recomendado para ti" con carousel de ProviderCards:
    - Imagen del proveedor
    - Nombre y ubicación
    - Rating y cantidad de reviews
    - Precio desde
    - Relevance badges (ej: "🎯 Perfecto para ti", "📍 Cerca de ti")
    - Texto explicativo: "Te lo recomendamos porque..."
    - Botones: "Ver detalles", "❤️" (agregar a favoritos), "👎" (No me interesa)
14. Usuario puede interactuar con recomendaciones

**Escenarios Alternos:**

**EA-1: Recomendaciones cacheadas existentes**
1. En paso 3, sistema encuentra recomendaciones en caché (< 24h antigüedad)
2. Sistema retorna directamente desde caché (sub-segundo)
3. Continúa desde paso 12

**EA-2: Usuario con datos insuficientes**
1. En paso 3, sistema detecta que usuario tiene < 3 interacciones
2. Sistema no puede generar recomendaciones personalizadas
3. Sistema genera fallback a recomendaciones genéricas:
   - Top 10 proveedores por rating en ubicación por defecto del usuario
   - O trending providers (más reservados últimos 7 días)
4. Sistema muestra con disclaimer: "Estas son las opciones más populares. Úsalas para descubrir y empezaremos a personalizar tus recomendaciones"
5. Sistema registra evento `recommendations.fallback`

**EA-3: Feedback negativo en recomendación**
1. Usuario hace clic en "👎 No me interesa" en una recomendación
2. Frontend envía: `POST /api/ia/recommendations/feedback { providerId, feedback: 'dislike', reason: optional }`
3. Sistema registra feedback en tabla `recommendation_feedback`
4. Sistema remueve esa recomendación de la UI inmediatamente
5. Sistema carga próxima recomendación de la cola (si hay más)
6. Sistema actualiza modelo: reduce score de ese proveedor en futuras recomendaciones
7. UI muestra toast: "Gracias por tu feedback. Mejoraremos tus recomendaciones"

**EA-4: Exclusión permanente de proveedor**
1. Usuario selecciona "No volver a recomendar este autolavado" desde menú contextual
2. Sistema envía: `POST /api/ia/recommendations/exclude { providerId }`
3. Sistema agrega providerId a lista de excluidos del usuario (tabla `user_preferences.excludedProviders`)
4. Sistema invalida caché de recomendaciones del usuario
5. Sistema remueve ese proveedor de UI
6. En próxima generación, ese proveedor será filtrado en paso 6

**EA-5: Error en OpenAI API**
1. En paso 4, OpenAI API falla (timeout, rate limit, error 5xx)
2. Sistema captura error y registra en logs
3. Sistema intenta fallback a algoritmo de recomendación local (sin IA):
   - Collaborative filtering basado en similitud con otros usuarios
   - Factores: ubicación, precios, servicios, ratings
4. Si fallback exitoso, genera recomendaciones y continúa desde paso 5
5. Si fallback también falla, sistema responde con error 503
6. UI muestra: "No pudimos generar recomendaciones personalizadas. Intenta nuevamente más tarde"
7. UI muestra recomendaciones genéricas (top rated)

**EA-6: OpenAI excede presupuesto o rate limit**
1. Sistema monitorea costos de OpenAI en tiempo real
2. Si se acerca a límite mensual, sistema activa modo "conservador":
   - Aumenta TTL de caché a 48h
   - Reduce frecuencia de actualizaciones
   - Prioriza generación para usuarios más activos
3. Si excede límite, desactiva temporalmente generación con IA
4. Sistema continúa con algoritmo de fallback local
5. Sistema notifica a administradores vía email/Slack

**EA-7: Usuario explora proveedor recomendado**
1. Usuario hace clic en "Ver detalles" de una recomendación
2. Sistema registra evento: `recommendation.clicked { userId, providerId, relevanceScore, position }`
3. Sistema incrementa contador de conversión de esa recomendación
4. Sistema redirige a `/provider/[id]`
5. Si usuario reserva o agrega a favoritos, sistema registra conversión completa
6. Métricas se usan para afinar futuras recomendaciones

**Postcondiciones:**
- Recomendaciones generadas y cacheadas por 24h
- Feedback de usuario registrado para mejorar futuras recomendaciones
- Eventos analytics registrados para medir efectividad
- Costos de OpenAI API tracked para monitoreo de presupuesto
- Modelo de recomendación actualizado con nuevos datos
- Usuario tiene visibilidad de proveedores relevantes que no conocía

**Criterios de Aceptación:**
1. **CA-1:** El sistema genera recomendaciones personalizadas analizando últimas 20 búsquedas, 10 reservas y favoritos del usuario, usando OpenAI GPT-4 para análisis de patrones
2. **CA-2:** Cada recomendación incluye explicación clara (ej: "Te lo recomendamos porque está cerca de [ubicación frecuente] y tiene servicios de [tipo] que usas") y relevance score
3. **CA-3:** Las recomendaciones se cachean por 24h en Redis, respondiendo en <500ms en requests subsecuentes
4. **CA-4:** El sistema provee fallback a recomendaciones genéricas (top rated) cuando usuario tiene <3 interacciones o OpenAI falla
5. **CA-5:** Usuario puede dar feedback (like/dislike) y excluir permanentemente proveedores con botón "No volver a recomendar", actualizando futuras recomendaciones
6. **CA-6:** El sistema muestra máximo 10 recomendaciones ordenadas por relevance score, con badges visuales ("Cerca de ti", "Precio justo", "Muy bien valorado")
7. **CA-7:** El sistema registra conversiones (clicks, reservas, favoritos) desde recomendaciones, midiendo precisión >70% de engagement

**Story Points:** 13  
**Prioridad:** Could  
**Dependencias:** HU-002 (Login), HU-005 (Búsqueda), HU-013 (Reservas), HU-010 (Favoritos)

**Relación con Casos de Uso:**
- **UC-020: Sistema de Recomendaciones** (include) - Implementa el motor completo de recomendaciones
- **UC-021: Análisis de Comportamiento** (include) - Incluye análisis de patrones de usuario
- **UC-022: Machine Learning** (include) - Integración con OpenAI y algoritmos de ML
- **UC-023: Personalización de Experiencia** (extend) - Extiende la experiencia personalizada del usuario
- **UC-024: Feedback Loop** (extend) - Extiende con sistema de aprendizaje continuo

---

### HU-018: Registro de proveedor

**Título:** Como proveedor de servicios de autolavado, quiero registrarme en la plataforma para ofrecer mis servicios y captar nuevos clientes.

**Descripción:**  
Proceso de onboarding para proveedores con validación de identidad de negocio.

**Criterios de Aceptación:**
1. Formulario de registro específico para proveedores con campos: nombre del negocio, tipo de negocio, RUT, dirección, teléfono, email, sitio web.
2. Validación de RUT único en el sistema.
3. Carga de documentos: patente comercial, certificado tributario.
4. Selección en mapa de ubicación exacta del negocio.
5. Creación de cuenta de usuario asociada (email/contraseña).
6. Estado inicial: "Pendiente de Aprobación".
7. Notificación a administradores de nuevo registro pendiente.
8. Email de confirmación al proveedor indicando proceso de revisión.

**Puntos de Historia:** 8  
**Prioridad:** Must  
**Dependencias:** Ninguna  
**Nota técnica:** Requiere flujo de verificación administrativa y validación de documentos.

---

### HU-019: Gestión de perfil de negocio

**Título:** Como proveedor, quiero editar el perfil de mi negocio para mantener la información actualizada y atractiva para potenciales clientes.

**Descripción:**  
Panel de administración del perfil público del proveedor.

**Criterios de Aceptación:**
1. Campos editables: descripción del negocio, teléfono, email, sitio web, redes sociales.
2. Gestión de galería de imágenes: subir, ordenar, eliminar (máximo 10 imágenes).
3. Actualización de horarios de atención por día de la semana.
4. Indicación de días bloqueados (vacaciones, mantenimiento).
5. Configuración de políticas de cancelación.
6. Todos los cambios requieren re-aprobación administrativa si son sustanciales.
7. Preview de cómo se ve el perfil para los clientes.
8. Validación de formatos (URLs, teléfonos).

**Puntos de Historia:** 5  
**Prioridad:** Must  
**Dependencias:** HU-018

---

### HU-020: Gestión de catálogo de servicios

**Título:** Como proveedor, quiero gestionar mi catálogo de servicios para ofrecer información clara de precios y características a los clientes.

**Descripción:**  
CRUD completo de servicios ofrecidos por el proveedor.

**Criterios de Aceptación:**
1. Crear nuevo servicio con: nombre, descripción, tipo, precio, duración, servicios incluidos.
2. Editar servicios existentes.
3. Activar/desactivar servicios temporalmente.
4. Eliminar servicios (soft delete).
5. Configurar servicios destacados.
6. Agregar imágenes específicas por servicio.
7. Definir requisitos especiales (ej: "solo para vehículos pequeños").
8. Configurar descuentos o precio promocional.
9. Orden de visualización personalizable (drag & drop).

**Puntos de Historia:** 8  
**Prioridad:** Must  
**Dependencias:** HU-018

---

### HU-021: Configuración de horarios disponibles

**Título:** Como proveedor, quiero configurar mis horarios de disponibilidad para que los clientes solo puedan reservar en momentos en que puedo atenderlos.

**Descripción:**  
Sistema de gestión de disponibilidad y slots de tiempo para reservas.

**Criterios de Aceptación:**
1. Configuración de horario base semanal (ej: Lun-Vie 9:00-18:00).
2. Definición de duración de slots (15, 30, 60 minutos).
3. Capacidad máxima de reservas simultáneas por slot.
4. Bloqueo de fechas específicas (feriados, vacaciones).
5. Bloqueo de horarios específicos dentro de un día.
6. Vista de calendario mostrando disponibilidad actual.
7. Ajuste de antelación mínima y máxima para reservas.
8. Sincronización automática con sistema de reservas.

**Puntos de Historia:** 5  
**Prioridad:** Must  
**Dependencias:** HU-018

---

### HU-022: Gestión de reservas recibidas

**Título:** Como proveedor, quiero gestionar las reservas que recibo para confirmar, modificar o rechazar citas según mi disponibilidad real.

**Descripción:**  
Panel de administración de reservas con acciones y notificaciones.

**Criterios de Aceptación:**
1. Dashboard de reservas con pestañas: Pendientes, Confirmadas, En Progreso, Completadas, Canceladas.
2. Cada reserva muestra: cliente, servicio, fecha/hora, detalles del vehículo, notas especiales.
3. Acciones disponibles: Confirmar, Rechazar, Reprogramar, Marcar como completada.
4. Notificación automática al cliente de cada cambio de estado.
5. Filtros por fecha, servicio, estado.
6. Vista de calendario con todas las reservas.
7. Opción para contactar al cliente directamente (llamada/email).
8. Exportar listado de reservas a Excel/PDF.

**Puntos de Historia:** 8  
**Prioridad:** Must  
**Dependencias:** HU-018, HU-021

---

### HU-023: Dashboard de estadísticas del proveedor

**Título:** Como proveedor, quiero ver estadísticas de mi negocio para analizar el rendimiento y tomar decisiones informadas.

**Descripción:**  
Panel analítico completo con métricas clave del negocio.

**Criterios de Aceptación:**
1. Métricas principales: total de reservas, tasa de conversión, ingresos estimados, rating promedio.
2. Gráficos de evolución temporal (reservas por semana/mes).
3. Servicios más populares y menos solicitados.
4. Horarios de mayor demanda (heatmap).
5. Análisis de reviews: promedio por criterio, palabras más mencionadas.
6. Comparación con periodo anterior (% de crecimiento).
7. Filtros por rango de fechas personalizado.
8. Exportar reportes a PDF.
9. Visualizaciones con gráficos interactivos (Chart.js o similar).

**Puntos de Historia:** 13  
**Prioridad:** Should  
**Dependencias:** HU-018, HU-022  
**Nota técnica:** Complejidad alta por agregación de datos, generación de gráficos y optimización de consultas analíticas.

---

### HU-024: Gestión de promociones y descuentos

**Título:** Como proveedor, quiero crear promociones y descuentos para atraer más clientes y aumentar reservas.

**Descripción:**  
Sistema de creación y administración de ofertas especiales.

**Criterios de Aceptación:**
1. Crear promoción con: título, descripción, tipo de descuento (%, monto fijo), valor.
2. Definir servicios aplicables o si aplica a todos.
3. Configurar vigencia (fecha inicio y fin).
4. Establecer límite de usos (opcional).
5. Mínimo de compra requerido (opcional).
6. Promociones aparecen destacadas en el perfil del proveedor.
7. Usuarios reciben notificación si tienen al proveedor en favoritos.
8. Tracking de uso de cada promoción.
9. Activar/desactivar promociones manualmente.

**Puntos de Historia:** 8  
**Prioridad:** Should  
**Dependencias:** HU-018, HU-020

---

### HU-025: Respuesta a reseñas de clientes

**Título:** Como proveedor, quiero responder a las reseñas de mis clientes para mostrar atención al feedback y mejorar mi reputación.

**Descripción:**  
Herramienta de interacción con reviews recibidos.

**Criterios de Aceptación:**
1. Visualización de todas las reseñas recibidas con estado (respondida/sin responder).
2. Campo de texto para redactar respuesta pública.
3. Respuestas tienen límite de caracteres (500).
4. Notificación al cliente cuando el proveedor responde su reseña.
5. Editar respuesta dentro de 24 horas de publicada.
6. Las respuestas aparecen debajo de cada reseña en el perfil público.
7. Filtro para ver solo reseñas negativas (≤3 estrellas) para atención prioritaria.

**Puntos de Historia:** 5  
**Prioridad:** Should  
**Dependencias:** HU-018, HU-012

---

### HU-026: Sistema de verificación de proveedores

**Título:** Como administrador, quiero verificar y aprobar proveedores nuevos para asegurar la calidad de la plataforma.

**Descripción:**  
Flujo de verificación administrativa de nuevos proveedores.

**Criterios de Aceptación:**
1. Lista de proveedores pendientes de aprobación.
2. Vista detallada de solicitud con todos los datos y documentos subidos.
3. Validación de RUT mediante servicio del SII (API externa).
4. Verificación de documentos comerciales.
5. Acciones: Aprobar, Rechazar, Solicitar más información.
6. Campo para notas internas visibles solo para admins.
7. Notificación automática al proveedor del resultado.
8. Si se aprueba, cambio de estado a "Activo" y perfil visible públicamente.
9. Si se rechaza, especificar motivo que se comunica al proveedor.

**Puntos de Historia:** 8  
**Prioridad:** Must  
**Dependencias:** HU-018

---

### HU-027: Dashboard administrativo completo

**Título:** Como administrador, quiero tener un dashboard general para monitorear todas las métricas clave de la plataforma.

**Descripción:**  
Panel administrativo centralizado con KPIs y herramientas de gestión.

**Criterios de Aceptación:**
1. Métricas principales: total usuarios activos, total proveedores, reservas del mes, ingresos (si aplica comisión).
2. Gráficos de crecimiento (usuarios, proveedores, reservas).
3. Listado de actividad reciente (nuevos registros, reservas, reseñas).
4. Alertas de acciones pendientes (proveedores por aprobar, reseñas por moderar).
5. Estadísticas de uso: búsquedas, conversión a reserva, tasa de cancelación.
6. Proveedores top por rating y por cantidad de reservas.
7. Mapa de calor de actividad por zona geográfica.
8. Acceso rápido a todas las funciones administrativas.
9. Filtros temporales para todas las métricas.

**Puntos de Historia:** 13  
**Prioridad:** Must  
**Dependencias:** Todas las HU previas  
**Nota técnica:** Complejidad muy alta por agregación masiva de datos y múltiples visualizaciones.

---

### HU-028: Gestión de usuarios y moderación

**Título:** Como administrador, quiero gestionar usuarios y contenido para mantener la calidad y seguridad de la plataforma.

**Descripción:**  
Herramientas de administración de usuarios y moderación de contenido.

**Criterios de Aceptación:**
1. Búsqueda y listado de todos los usuarios (clientes y proveedores).
2. Vista detallada de perfil de usuario con toda su actividad.
3. Acciones: Suspender, Reactivar, Eliminar cuenta.
4. Moderación de reseñas reportadas por contenido inapropiado.
5. Aprobación/rechazo de reseñas pendientes.
6. Editar o eliminar contenido que viole políticas.
7. Sistema de reportes de usuarios problemáticos.
8. Log de todas las acciones administrativas realizadas.

**Puntos de Historia:** 8  
**Prioridad:** Must  
**Dependencias:** HU-001, HU-012

---

### HU-029: Configuración de parámetros del sistema

**Título:** Como administrador, quiero configurar parámetros generales del sistema para personalizar el comportamiento de la plataforma.

**Descripción:**  
Panel de configuración global de la aplicación.

**Criterios de Aceptación:**
1. Configuraciones de reservas: tiempo mínimo de antelación, política de cancelación por defecto.
2. Parámetros de búsqueda: radio máximo, límite de resultados.
3. Configuración de notificaciones: tiempos de recordatorio, tipos activos.
4. Políticas de moderación: palabras prohibidas, umbral de reportes.
5. Configuración de comisiones (si aplica modelo de negocio).
6. Textos legales: términos y condiciones, política de privacidad.
7. Configuración de emails: templates, remitente.
8. Todos los cambios quedan registrados en log de auditoría.

**Puntos de Historia:** 5  
**Prioridad:** Should  
**Dependencies:** Ninguna

---

### HU-030: Scraping y agregación de datos

**Título:** Como sistema, quiero scrapear y agregar datos de múltiples fuentes para mantener un catálogo actualizado de proveedores.

**Descripción:**  
Motor automatizado de scraping que recopila información de autolavados de diferentes fuentes públicas (Google Maps API, Yapo.cl, redes sociales) y las integra en la base de datos. Incluye validación, normalización, deduplicación, y transformación de datos para asegurar calidad e integridad. El sistema ejecuta scrapers programados, maneja errores, respeta rate limits, y genera reportes de importación.

**Requisitos Asociados:**
- **REQ-FUNC-030:** El sistema debe extraer datos de Google Maps API, Yapo.cl y otras fuentes configurables
- **REQ-FUNC-031:** El sistema debe normalizar direcciones y geocodificar coordenadas
- **REQ-FUNC-032:** El sistema debe detectar y prevenir duplicados mediante algoritmos de similitud
- **REQ-FUNC-033:** El sistema debe validar calidad de datos extraídos antes de importar
- **REQ-FUNC-034:** El sistema debe generar reportes de importación con estadísticas
- **REQ-NF-030:** Los scrapers deben respetar robots.txt y rate limits (max 10 req/s)
- **REQ-NF-031:** El sistema debe manejar cambios en estructura HTML de fuentes externas
- **REQ-NF-032:** La importación debe ser idempotente (re-ejecutable sin duplicados)

**Constraints:**
- Google Maps API tiene límites de cuota (consultar pricing)
- Scrapers web deben usar user-agent identificable y respetar robots.txt
- Rate limiting obligatorio: máximo 10 requests/segundo por dominio
- Datos scrapeados requieren aprobación administrativa antes de publicarse
- Solo importar proveedores en Chile (validación de región)
- Exportación a múltiples formatos: JSON, CSV, SQL
- Scrapers ejecutados en horarios de baja demanda (madrugada)
- Uso de proxies rotatorios para evitar bloqueos IP
- Timeout de 30 segundos por request

**Entry Points:**
- **CLI:** `npm run scraper:google-maps` - Ejecutar scraper de Google Maps
- **CLI:** `npm run scraper:yapo` - Ejecutar scraper de Yapo.cl
- **CLI:** `npm run scraper:all` - Ejecutar todos los scrapers
- **CLI:** `npm run importer:validate` - Validar datos antes de importar
- **CLI:** `npm run importer:import` - Importar datos a BD tras validación
- **API:** `POST /api/admin/scraping/run` - Trigger manual de scraping (admin)
- **API:** `GET /api/admin/scraping/status` - Estado de scraping jobs
- **Cron Job:** Ejecución automática semanal (Domingos 3:00 AM)

**Context References:**
- **Módulos:** `scraper/src/scrapers`, `scraper/src/importers`, `scraper/src/exporters`
- **Servicios:** `GoogleMapsScraper`, `YapoScraper`, `DataMapper`, `PrismaImporter`, `DeduplicationService`
- **Scripts:** `scraper/src/index.ts`, `scraper/src/sample.ts`
- **Tablas:** `providers`, `services` (destino de importación)
- **Output:** `scraper/output/carwashes.json`, `scraper/output/carwashes.csv`, `scraper/output/insert_carwashes.sql`
- **Config:** `scraper/src/config.ts` (configuración de scrapers)
- **Documentación:** `scraper/IMPORT_GUIDE.md`, `scraper/QUICK_START.md`

**Escenarios:**

**Precondiciones:**
- APIs configuradas con credenciales válidas (Google Maps API key)
- Prisma schema sincronizado con base de datos
- Proxies rotatorios configurados (si requerido)
- Conexión a BD disponible para importación
- Permisos de escritura en directorio `scraper/output/`

**Flujo Principal:**

**FASE 1: SCRAPING**
1. Sistema ejecuta cron job o admin trigger scraping manual
2. Sistema inicializa logger y reportes
3. Sistema carga configuración desde `scraper/src/config.ts`:
   ```javascript
   {
     googleMaps: {
       apiKey: process.env.GOOGLE_MAPS_API_KEY,
       query: "autolavado en Chile",
       radius: 50000, // 50km
       maxResults: 500
     },
     yapo: {
       baseUrl: "https://www.yapo.cl",
       category: "servicios/automotriz/autolavado",
       maxPages: 10
     },
     rateLimit: 10, // req/s
     timeout: 30000 // ms
   }
   ```

**SCRAPER: Google Maps API**
4. Sistema inicia `GoogleMapsScraper`
5. Para cada comuna/ciudad objetivo (Santiago, Valparaíso, Concepción, etc.):
   - Sistema envía request a Google Maps Places API:
     ```javascript
     GET https://maps.googleapis.com/maps/api/place/textsearch/json?
     query=autolavado+en+{ciudad}&key={apiKey}
     ```
   - API retorna lista de lugares (max 60 por query con paginación)
   - Para cada lugar, sistema extrae:
     ```javascript
     {
       name: "Autolavado XYZ",
       address: "Av. Providencia 1234, Santiago",
       location: { lat: -33.4372, lng: -70.6506 },
       rating: 4.5,
       totalRatings: 120,
       phone: "+56 9 1234 5678",
       website: "https://...",
       openingHours: ["Lunes: 9:00–18:00", ...],
       photos: [photoReference1, photoReference2, ...]
     }
     ```
   - Sistema descarga fotos (max 3 por proveedor) usando Photo API
   - Sistema respeta rate limit (delay 100ms entre requests)
6. Sistema guarda datos raw en `scraper/output/google_maps_raw.json`

**SCRAPER: Yapo.cl**
7. Sistema inicia `YapoScraper` usando Puppeteer
8. Sistema navega a listado de autolavados en Yapo.cl
9. Para cada página (max 10):
   - Sistema extrae cards de anuncios
   - Para cada anuncio, extrae:
     ```javascript
     {
       title: "Autolavado a domicilio",
       description: "Servicio de lavado completo...",
       phone: "9 1234 5678",
       location: "Santiago, Providencia",
       price: "$15.000",
       images: [url1, url2, ...]
     }
     ```
   - Sistema espera 2-3 segundos entre páginas (human-like behavior)
10. Sistema intenta geocodificar direcciones usando Google Geocoding API
11. Sistema guarda datos raw en `scraper/output/yapo_raw.json`

**FASE 2: NORMALIZACIÓN Y MAPEO**
12. Sistema ejecuta `DataMapper` para normalizar datos
13. Para cada proveedor extraído:
    - Normaliza nombre (trim, title case, remove duplicates words)
    - Normaliza dirección (formato estándar)
    - Valida y formatea teléfono (+56 9 XXXX XXXX)
    - Extrae comuna, ciudad, región de dirección
    - Valida coordenadas (dentro de bounds de Chile)
    - Parsea horarios a formato JSON
    - Extrae servicios mencionados en descripción (ML/regex)
    - Mapea a schema de Prisma:
      ```javascript
      {
        businessName: string,
        description: string,
        phone: string,
        address: string,
        latitude: number,
        longitude: number,
        city: string,
        region: string,
        operatingHours: JSON,
        source: "GOOGLE_MAPS" | "YAPO",
        status: "PENDING_APPROVAL"
      }
      ```
14. Sistema valida datos mapeados:
    - Campos requeridos no vacíos
    - Coordenadas válidas
    - Teléfono con formato correcto
    - Dirección geocodificable
15. Proveedores que no pasan validación se registran en `validation_errors.log`

**FASE 3: DEDUPLICACIÓN**
16. Sistema ejecuta `DeduplicationService`
17. Para cada proveedor normalizado:
    - Sistema calcula hash de identidad: `hash(nombre.toLowerCase() + lat + lng)`
    - Sistema busca duplicados en datos ya procesados y en BD:
      ```sql
      SELECT * FROM providers 
      WHERE 
        SIMILARITY(business_name, <nombre>) > 0.8 OR
        (
          ST_Distance(
            ST_MakePoint(longitude, latitude)::geography,
            ST_MakePoint(<lng>, <lat>)::geography
          ) < 100 -- mismo lugar (100m)
        )
      ```
    - Si encuentra duplicado, sistema:
      - Compara datos: si nuevos datos más completos, marca para actualización
      - Si datos similares, marca como duplicado y skip
      - Registra en `deduplication_report.json`
18. Sistema genera lista final de proveedores únicos para importar

**FASE 4: EXPORTACIÓN**
19. Sistema ejecuta exporters para múltiples formatos:
    - **JSON:** `scraper/output/carwashes.json` (formato completo)
    - **CSV:** `scraper/output/carwashes.csv` (formato tabular)
    - **SQL:** `scraper/output/insert_carwashes.sql` (INSERT statements)
20. Sistema genera archivo `import_summary.json`:
    ```javascript
    {
      timestamp: "2025-10-20T03:00:00Z",
      sources: {
        googleMaps: { fetched: 450, validated: 420 },
        yapo: { fetched: 80, validated: 65 }
      },
      total: {
        extracted: 530,
        validated: 485,
        duplicates: 120,
        unique: 365,
        errors: 45
      },
      readyToImport: 365
    }
    ```

**FASE 5: IMPORTACIÓN A BASE DE DATOS**
21. Sistema (o admin manual) ejecuta `npm run importer:import`
22. Sistema carga datos desde `carwashes.json`
23. Para cada proveedor único:
    - Sistema verifica nuevamente duplicados en BD (por seguridad)
    - Si no existe, crea registro en tabla `providers` con status PENDING_APPROVAL
    - Si existe y nuevos datos mejores, crea entry en `pending_updates` para revisión
    - Sistema intenta extraer y crear servicios en tabla `services` (parseados de descripción)
24. Sistema ejecuta todo en transacción para atomicidad
25. Sistema genera `import_result.json`:
    ```javascript
    {
      imported: 340,
      updated: 15,
      skipped: 10,
      errors: 0,
      duration: "45s"
    }
    ```
26. Sistema envía notificación a administradores:
    - Email con resumen de importación
    - Lista de proveedores pendientes de aprobación (HU-026)

**Escenarios Alternos:**

**EA-1: Google Maps API excede cuota**
1. En paso 5, Google API responde con error 429 (Over Quota)
2. Sistema captura error y registra en logs
3. Sistema detiene scraping de Google Maps
4. Sistema continúa con otros scrapers (Yapo)
5. Sistema envía alerta a administradores sobre cuota excedida
6. Sistema programa re-intento para próximo ciclo

**EA-2: Cambio en estructura HTML de Yapo**
1. En paso 9, selectores de Puppeteer no encuentran elementos
2. Sistema captura excepción y registra
3. Sistema intenta selectores de fallback (configurados en `config.ts`)
4. Si fallback falla, sistema registra error y continúa con lo extraído
5. Sistema notifica a desarrolladores para actualizar selectores

**EA-3: Bloqueo de IP por rate limiting**
1. Durante scraping, sitio retorna 403 o 429
2. Sistema detecta bloqueo
3. Sistema activa proxy rotatorio (si configurado)
4. Sistema reintenta request con nuevo proxy
5. Si fallo persiste, sistema pausa ese scraper por 1 hora
6. Sistema registra en logs para análisis

**EA-4: Datos de baja calidad**
1. En paso 14, múltiples proveedores fallan validación
2. Sistema registra en `validation_errors.log` con detalles:
   - Proveedor, fuente, campo inválido, razón
3. Sistema excluye esos proveedores de importación
4. Si tasa de error > 20%, sistema envía alerta de problemas de calidad

**EA-5: Alto porcentaje de duplicados**
1. En paso 18, sistema detecta >80% de duplicados
2. Sistema envía alerta: posible re-ejecución accidental o poca data nueva
3. Sistema continúa pero marca importación como "LOW_NEW_DATA"
4. Administradores revisan antes de aprobar importación

**EA-6: Error en importación a BD**
1. En paso 24, falla transacción de BD (constraint violation, etc.)
2. Sistema rollback completo de la importación
3. Sistema registra error detallado en logs
4. Sistema mantiene datos en archivos JSON/CSV para investigación
5. Sistema notifica a administradores con detalles del error

**EA-7: Ejecución manual por administrador**
1. Admin ejecuta desde panel: `POST /api/admin/scraping/run`
2. Sistema valida rol ADMIN del usuario
3. Sistema inicia scraping en background job (async)
4. Sistema responde inmediatamente con jobId
5. Admin puede consultar status: `GET /api/admin/scraping/status?jobId=<id>`
6. Al finalizar, sistema notifica a admin vía notificación in-app

**Postcondiciones:**
- Datos de proveedores extraídos, validados y normalizados
- Duplicados detectados y filtrados
- Proveedores únicos importados a BD con status PENDING_APPROVAL
- Archivos de salida generados (JSON, CSV, SQL)
- Reportes y logs de ejecución disponibles
- Notificaciones enviadas a administradores
- Job de scraping registrado en logs de auditoría
- Métricas de calidad y cobertura actualizadas

**Criterios de Aceptación:**
1. **CA-1:** El sistema extrae datos de Google Maps API (nombre, dirección, coordenadas, rating, teléfono, horarios, fotos) con rate limit de 10 req/s y manejo de cuota
2. **CA-2:** El sistema scrapea Yapo.cl usando Puppeteer, extrayendo anuncios de autolavados (título, descripción, teléfono, ubicación, precio) con delays human-like
3. **CA-3:** El sistema normaliza direcciones, geocodifica coordenadas, valida formato de teléfonos (+56 9 XXXX XXXX) y parsea horarios a formato JSON
4. **CA-4:** El sistema detecta duplicados usando similitud de nombres (>80%) y distancia geográfica (<100m), previniendo importaciones duplicadas
5. **CA-5:** El sistema genera archivos de salida (JSON, CSV, SQL) y reporte de importación con estadísticas detalladas (extraídos, validados, duplicados, únicos, errores)
6. **CA-6:** Los proveedores importados se crean con status PENDING_APPROVAL, requiriendo aprobación administrativa (HU-026) antes de publicarse
7. **CA-7:** El sistema maneja errores gracefully (API fallida, bloqueo IP, cambio HTML), registra en logs, notifica administradores y permite re-intentos

**Story Points:** 13  
**Prioridad:** Must  
**Dependencias:** HU-026 (Verificación de proveedores - para aprobar datos importados)

**Relación con Casos de Uso:**
- **UC-030: Agregación Automática de Datos** (include) - Implementa el sistema completo de scraping
- **UC-031: Validación y Normalización** (include) - Incluye limpieza y validación de datos
- **UC-032: Deduplicación** (include) - Prevención de proveedores duplicados
- **UC-033: Importación Masiva** (include) - Carga de datos a BD
- **UC-034: Monitoreo de Fuentes** (extend) - Extiende con detección de cambios en fuentes externas

---

## Épicas

### EPI-01: Gestión de Usuarios y Personalización

**Actores Principales:**
- 👤 **Usuario/Cliente:** Actor principal que interactúa con todas las funcionalidades
- 🔐 **Sistema de Autenticación (Clerk):** Actor externo que gestiona identidad
- 📧 **Servicio de Email:** Actor secundario para verificaciones y notificaciones

**Descripción:**  
Esta épica abarca todas las funcionalidades relacionadas con la experiencia del usuario como cliente de la plataforma, desde el registro inicial hasta la personalización completa de su experiencia. Incluye autenticación, gestión de perfil, favoritos, historial, y notificaciones. El objetivo es proporcionar una experiencia de usuario fluida, segura y personalizada que facilite el descubrimiento y uso de servicios de autolavado.

**Objetivos:**
- Permitir a los usuarios registrarse, autenticarse y gestionar sus datos de forma segura mediante Clerk.
- Facilitar la personalización de la experiencia mediante favoritos e historial.
- Mantener a los usuarios informados mediante notificaciones relevantes y oportunas.
- Construir engagement y retención de usuarios a través de funcionalidades útiles.

**Historias Incluidas:**  
HU-001, HU-002, HU-003, HU-004, HU-010, HU-011, HU-016

**Puntos de Historia Totales:** 27

**Casos de Uso Relacionados:**
- UC-001: Autenticación de Usuarios
- UC-002: Verificación de Email
- UC-003: Gestión de Sesiones
- UC-004: Control de Acceso por Roles
- UC-008: Gestión de Favoritos
- UC-009: Gestión de Notificaciones

**Justificación:**  
Estas historias se agrupan porque comparten el objetivo de gestionar el ciclo de vida completo del usuario como cliente, desde onboarding hasta retención. Todas se centran en la identidad, preferencias y comunicación con el usuario.

---

### EPI-02: Búsqueda y Descubrimiento

**Actores Principales:**
- 👤 **Usuario/Cliente:** Realiza búsquedas de autolavados
- 🗺️ **Google Maps API:** Proporciona geocodificación y mapas
- 🌐 **Navegador/GPS:** Provee ubicación del usuario
- 💾 **Sistema de Base de Datos (PostgreSQL+PostGIS):** Ejecuta consultas espaciales

**Descripción:**  
Esta épica engloba el motor de búsqueda y descubrimiento de proveedores, que es la funcionalidad core de la plataforma agregadora. Incluye búsqueda geolocalizada, filtros avanzados y visualización en mapa interactivo. El objetivo es permitir que los usuarios encuentren rápida y eficientemente autolavados que se ajusten a sus necesidades y ubicación.

**Objetivos:**
- Proporcionar un motor de búsqueda potente basado en geolocalización.
- Permitir refinamiento de búsquedas mediante filtros múltiples.
- Ofrecer visualización intuitiva de resultados en mapa interactivo.
- Optimizar experiencia de descubrimiento para maximizar conversión a reserva.

**Historias Incluidas:**  
HU-005, HU-006, HU-007

**Puntos de Historia Totales:** 21

**Casos de Uso Relacionados:**
- UC-005: Búsqueda de Proveedores
- UC-006: Geolocalización
- UC-007: Geocodificación
- UC-011: Historial de Búsquedas
- UC-015: Visualización en Mapa
- UC-016: Filtrado Avanzado

**Justificación:**  
Estas historias conforman el núcleo funcional de búsqueda y descubrimiento, todas trabajando juntas para que el usuario encuentre el proveedor ideal. Tienen alta interdependencia técnica (geolocalización, filtrado, mapas).

---

### EPI-03: Comparación y Evaluación de Proveedores

**Actores Principales:**
- 👤 **Usuario/Cliente:** Compara y evalúa proveedores
- 🏢 **Proveedores:** Entidades cuyos datos se comparan
- 💾 **Sistema de Base de Datos:** Provee información de proveedores y servicios

**Descripción:**  
Esta épica se centra en la propuesta de valor diferencial de Alto Carwash como agregador: la comparación transparente de precios y servicios. Incluye herramientas para comparar múltiples proveedores lado a lado y visualizar información detallada de cada uno. El objetivo es empoderar al usuario con información completa para tomar decisiones informadas.

**Objetivos:**
- Facilitar la comparación directa de precios y servicios entre proveedores.
- Mostrar información completa y transparente de cada proveedor.
- Ayudar al usuario a identificar la mejor opción según sus criterios.
- Diferenciarse como plataforma que prioriza transparencia y valor al cliente.

**Historias Incluidas:**  
HU-008, HU-009

**Puntos de Historia Totales:** 13

**Casos de Uso Relacionados:**
- UC-017: Comparación de Precios
- UC-018: Visualización de Detalles de Proveedor
- UC-019: Análisis de Servicios

**Justificación:**  
Estas historias implementan la funcionalidad core de comparación que define a Alto Carwash como agregador de servicios, similar a como SoloTodo compara precios de tecnología.

---

### EPI-04: Sistema de Reseñas y Reputación

**Actores Principales:**
- 👤 **Usuario/Cliente:** Crea y gestiona reseñas
- 🏢 **Proveedor:** Responde a reseñas y gestiona reputación
- 👨‍💼 **Administrador:** Modera contenido inapropiado
- 🤖 **Sistema de Moderación:** Detecta contenido automáticamente

**Descripción:**  
Esta épica cubre el sistema completo de reviews y calificaciones que permite a los usuarios compartir experiencias y a los proveedores gestionar su reputación. Incluye creación de reseñas, moderación, y respuestas de proveedores. El objetivo es construir confianza en la plataforma mediante feedback genuino de usuarios.

**Objetivos:**
- Permitir que usuarios compartan experiencias reales y detalladas.
- Proporcionar mecanismos de moderación para garantizar calidad y autenticidad.
- Dar a los proveedores herramientas para gestionar su reputación activamente.
- Construir un ecosistema de confianza basado en transparencia.

**Historias Incluidas:**  
HU-012, HU-025

**Puntos de Historia Totales:** 13

**Casos de Uso Relacionados:**
- UC-025: Gestión de Reseñas
- UC-026: Moderación de Contenido
- UC-027: Respuesta a Feedback
- UC-028: Cálculo de Rating

**Justificación:**  
Estas historias trabajan en conjunto para crear un sistema bidireccional de feedback entre usuarios y proveedores, fundamental para la confianza en la plataforma.

---

### EPI-05: Gestión de Reservas

**Actores Principales:**
- 👤 **Usuario/Cliente:** Crea, visualiza y cancela reservas
- 🏢 **Proveedor:** Gestiona y confirma reservas recibidas
- 📧 **Servicio de Email:** Envía confirmaciones y recordatorios
- 📱 **Servicio de Notificaciones (FCM):** Envía notificaciones push
- 🔔 **Sistema de Jobs:** Programa recordatorios automáticos
- 📅 **Sistema de Calendario:** Gestiona disponibilidad y slots

**Descripción:**  
Esta épica abarca todo el flujo de reservas desde la perspectiva del cliente y del proveedor. Incluye creación, confirmación, cancelación y seguimiento de reservas. El objetivo es proporcionar un sistema de agendamiento robusto que conecte eficientemente clientes con proveedores.

**Objetivos:**
- Permitir a usuarios reservar servicios de forma simple y confiable.
- Dar a proveedores control total sobre sus reservas y disponibilidad.
- Garantizar comunicación clara y oportuna entre ambas partes.
- Minimizar no-shows mediante recordatorios y políticas de cancelación.

**Historias Incluidas:**  
HU-013, HU-014, HU-015, HU-022

**Puntos de Historia Totales:** 22

**Casos de Uso Relacionados:**
- UC-010: Gestión de Reservas
- UC-011: Validación de Disponibilidad
- UC-012: Notificaciones de Reserva
- UC-013: Prevención de Conflictos
- UC-014: Generación de QR
- UC-029: Recordatorios Automáticos

**Justificación:**  
Estas historias conforman el sistema de reservas end-to-end, cubriendo tanto la experiencia del cliente como la gestión del proveedor. Es un flujo transaccional crítico que requiere coordinación entre múltiples actores.

---

### EPI-06: Inteligencia Artificial y Agregación de Datos

**Actores Principales:**
- 👤 **Usuario/Cliente:** Recibe recomendaciones personalizadas
- 🤖 **OpenAI API (GPT-4):** Genera recomendaciones con IA
- 📦 **Redis Cache:** Almacena recomendaciones temporalmente
- 🕷️ **Scrapers (Google Maps, Yapo):** Extraen datos de fuentes externas
- 🗺️ **Google Maps API:** Proporciona datos de autolavados
- 🌐 **Yapo.cl:** Fuente de anuncios de autolavados
- 🤖 **Puppeteer:** Motor de web scraping
- 👨‍💼 **Administrador:** Aprueba datos importados
- ⏰ **Cron Jobs:** Ejecuta scrapers programados

**Descripción:**  
Esta épica se enfoca en las capacidades de IA y automatización de la plataforma. Incluye recomendaciones personalizadas mediante OpenAI y el sistema de scraping/agregación automática de datos. El objetivo es diferenciarse mediante tecnología avanzada que mejore la experiencia del usuario y escale el catálogo de proveedores.

**Objetivos:**
- Proporcionar recomendaciones personalizadas que aumenten conversión.
- Automatizar la agregación de datos de múltiples fuentes públicas.
- Mantener el catálogo actualizado y completo sin intervención manual constante.
- Usar IA para análisis predictivo y mejora continua de la plataforma.

**Historias Incluidas:**  
HU-017, HU-030

**Puntos de Historia Totales:** 26

**Casos de Uso Relacionados:**
- UC-020: Sistema de Recomendaciones
- UC-021: Análisis de Comportamiento
- UC-022: Machine Learning
- UC-023: Personalización de Experiencia
- UC-024: Feedback Loop
- UC-030: Agregación Automática de Datos
- UC-031: Validación y Normalización
- UC-032: Deduplicación
- UC-033: Importación Masiva
- UC-034: Monitoreo de Fuentes

**Justificación:**  
Estas historias representan las capacidades tecnológicas más avanzadas de la plataforma, diferenciadores clave que requieren expertise en IA y scraping. Tienen complejidad técnica muy alta.

---

### EPI-07: Portal de Proveedores

**Actores Principales:**
- 🏢 **Proveedor:** Actor principal que gestiona su negocio
- 👨‍💼 **Administrador:** Verifica y aprueba proveedores nuevos
- 🗺️ **Google Maps API:** Para selección de ubicación
- 📧 **Servicio de Email:** Confirmaciones y notificaciones
- 📊 **Sistema de Analytics:** Genera estadísticas y reportes
- 👥 **Usuarios/Clientes:** Destinatarios de promociones y servicios

**Descripción:**  
Esta épica engloba todas las funcionalidades del panel de administración para proveedores. Incluye registro, gestión de perfil, servicios, horarios, promociones y analytics. El objetivo es proporcionar a los proveedores herramientas completas para gestionar su presencia en la plataforma y atraer clientes.

**Objetivos:**
- Facilitar el onboarding de nuevos proveedores a la plataforma.
- Dar autonomía a proveedores para actualizar su información.
- Proporcionar insights mediante analytics para mejorar su negocio.
- Permitir estrategias de marketing mediante promociones.

**Historias Incluidas:**  
HU-018, HU-019, HU-020, HU-021, HU-023, HU-024

**Puntos de Historia Totales:** 47

**Casos de Uso Relacionados:**
- UC-035: Registro de Proveedor
- UC-036: Gestión de Perfil de Negocio
- UC-037: Gestión de Catálogo
- UC-038: Configuración de Disponibilidad
- UC-039: Analytics de Proveedor
- UC-040: Gestión de Promociones

**Justificación:**  
Estas historias construyen el ecosistema completo de herramientas para proveedores, desde su ingreso a la plataforma hasta la optimización de su desempeño. Es crítico para el modelo de negocio de dos lados (marketplace).

---

### EPI-08: Administración y Gobernanza

**Actores Principales:**
- 👨‍💼 **Administrador:** Actor principal con privilegios elevados
- 🏢 **Proveedores:** Sujetos a verificación y moderación
- 👥 **Usuarios/Clientes:** Sujetos a moderación si violan políticas
- 🏛️ **API SII (Servicio de Impuestos Internos):** Validación de RUT
- 📊 **Sistema de Analytics:** Genera KPIs y métricas
- 📧 **Servicio de Email:** Notificaciones administrativas
- 🤖 **Sistema de Moderación:** Detección automática de contenido

**Descripción:**  
Esta épica cubre todas las herramientas administrativas necesarias para gestionar la plataforma, moderar contenido, y configurar el sistema. Incluye verificación de proveedores, dashboard administrativo, moderación de usuarios y configuración global. El objetivo es mantener la calidad, seguridad y buen funcionamiento de la plataforma.

**Objetivos:**
- Asegurar calidad mediante verificación rigurosa de proveedores.
- Monitorear la salud general de la plataforma con métricas clave.
- Moderar contenido para mantener un ambiente seguro y respetuoso.
- Configurar parámetros del sistema de forma centralizada.

**Historias Incluidas:**  
HU-026, HU-027, HU-028, HU-029

**Puntos de Historia Totales:** 34

**Casos de Uso Relacionados:**
- UC-041: Verificación de Proveedores
- UC-042: Monitoreo de Plataforma
- UC-043: Moderación de Contenido
- UC-044: Gestión de Usuarios
- UC-045: Configuración del Sistema
- UC-046: Auditoría y Logs

**Justificación:**  
Estas historias son las herramientas de gobierno y operación de la plataforma, necesarias para administradores. Comparten el objetivo de mantener control, calidad y seguridad del ecosistema.

---

## Diagrama de Casos de Uso

### Diagrama General del Sistema

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                        SISTEMA ALTO CARWASH - CASOS DE USO                      │
└─────────────────────────────────────────────────────────────────────────────────┘

                                    ┌───────────────────┐
                                    │   ALTO CARWASH    │
                                    │     PLATFORM      │
                                    └───────────────────┘
                                            │
        ┌───────────────────────────────────┼───────────────────────────────────┐
        │                                   │                                   │
        ▼                                   ▼                                   ▼
┌───────────────┐                   ┌───────────────┐                   ┌───────────────┐
│  USUARIO/     │                   │   PROVEEDOR   │                   │ ADMINISTRADOR │
│   CLIENTE     │                   │   (NEGOCIO)   │                   │   (ADMIN)     │
└───────┬───────┘                   └───────┬───────┘                   └───────┬───────┘
        │                                   │                                   │
        │  ┌─────────────────────────────────────────────────────────────┐     │
        │  │                      AUTENTICACIÓN                          │     │
        ├──┤ UC-001: Autenticación de Usuarios                           ├─────┤
        │  │ UC-002: Verificación de Email                               │     │
        │  │ UC-003: Gestión de Sesiones                                 │     │
        │  │ UC-004: Control de Acceso por Roles                         │     │
        │  └─────────────────────────────────────────────────────────────┘     │
        │                                                                       │
        │  ┌─────────────────────────────────────────────────────────────┐     │
        │  │                BÚSQUEDA Y DESCUBRIMIENTO                     │     │
        ├──┤ UC-005: Búsqueda de Proveedores                             │     │
        │  │ UC-006: Geolocalización ◄──────[include]──── UC-005         │     │
        │  │ UC-007: Geocodificación ◄──────[include]──── UC-005         │     │
        │  │ UC-015: Visualización en Mapa                                │     │
        │  │ UC-016: Filtrado Avanzado ◄────[extend]───── UC-005         │     │
        │  │ UC-011: Historial de Búsquedas ◄─[extend]─── UC-005         │     │
        │  └─────────────────────────────────────────────────────────────┘     │
        │                                                                       │
        │  ┌─────────────────────────────────────────────────────────────┐     │
        │  │              COMPARACIÓN Y EVALUACIÓN                        │     │
        ├──┤ UC-017: Comparación de Precios                              │     │
        │  │ UC-018: Visualización de Detalles de Proveedor              │     │
        │  │ UC-019: Análisis de Servicios                               │     │
        │  └─────────────────────────────────────────────────────────────┘     │
        │                                                                       │
        │  ┌─────────────────────────────────────────────────────────────┐     │
        │  │                  GESTIÓN DE FAVORITOS                        │     │
        ├──┤ UC-008: Gestión de Favoritos                                │     │
        │  │ UC-009: Gestión de Notificaciones                           │     │
        │  └─────────────────────────────────────────────────────────────┘     │
        │                                                                       │
        │  ┌─────────────────────────────────────────────────────────────┐     │
        │  │                  GESTIÓN DE RESERVAS                         │     │
        ├──┤ UC-010: Gestión de Reservas                                 ├─────┤
        │  │ UC-011: Validación de Disponibilidad ◄[include]─ UC-010     │     │
        │  │ UC-012: Notificaciones de Reserva ◄──[include]── UC-010     │     │
        │  │ UC-013: Prevención de Conflictos ◄───[include]── UC-010     │     │
        │  │ UC-014: Generación de QR ◄───────────[extend]─── UC-010     │     │
        │  │ UC-029: Recordatorios Automáticos                           │     │
        │  └─────────────────────────────────────────────────────────────┘     │
        │                                                                       │
        │  ┌─────────────────────────────────────────────────────────────┐     │
        │  │              RESEÑAS Y REPUTACIÓN                            │     │
        ├──┤ UC-025: Gestión de Reseñas                                  ├─────┤
        │  │ UC-026: Moderación de Contenido ◄────[include]── UC-025     │     │
        │  │ UC-027: Respuesta a Feedback ◄───────[include]── UC-025     │     │
        │  │ UC-028: Cálculo de Rating                                   │     │
        │  └─────────────────────────────────────────────────────────────┘     │
        │                                                                       │
        │  ┌─────────────────────────────────────────────────────────────┐     │
        │  │            RECOMENDACIONES CON IA                            │     │
        ├──┤ UC-020: Sistema de Recomendaciones                          │     │
        │  │ UC-021: Análisis de Comportamiento ◄[include]─ UC-020       │     │
        │  │ UC-022: Machine Learning ◄────────[include]─── UC-020       │     │
        │  │ UC-023: Personalización ◄─────────[extend]──── UC-020       │     │
        │  │ UC-024: Feedback Loop ◄───────────[extend]──── UC-020       │     │
        │  └─────────────────────────────────────────────────────────────┘     │
        │                                                                       │
        │                          ┌─────────────────────────────────────┐     │
        │                          │        PORTAL DE PROVEEDORES        │     │
        │                          │ UC-035: Registro de Proveedor       ├─────┤
        └──────────────────────────┤ UC-036: Gestión de Perfil           │     │
                                   │ UC-037: Gestión de Catálogo         ├─────┤
                                   │ UC-038: Config. Disponibilidad      │     │
                                   │ UC-039: Analytics de Proveedor      │     │
                                   │ UC-040: Gestión de Promociones      │     │
                                   └─────────────────────────────────────┘     │
                                                                               │
                                   ┌─────────────────────────────────────┐     │
                                   │      ADMINISTRACIÓN Y GOBERNANZA    │     │
                                   │ UC-041: Verificación Proveedores    ├─────┤
                                   │ UC-042: Monitoreo de Plataforma     ├─────┤
                                   │ UC-043: Moderación de Contenido     ├─────┤
                                   │ UC-044: Gestión de Usuarios         ├─────┤
                                   │ UC-045: Configuración del Sistema   ├─────┤
                                   │ UC-046: Auditoría y Logs            ├─────┘
                                   └─────────────────────────────────────┘

                          ┌────────────────────────────────────────┐
                          │      ACTORES EXTERNOS / SISTEMAS       │
                          └────────────────────────────────────────┘
                                          │
        ┌─────────────────────────────────┼─────────────────────────────────┐
        │                                 │                                 │
        ▼                                 ▼                                 ▼
┌───────────────┐              ┌───────────────┐               ┌───────────────┐
│ Clerk (Auth)  │              │  Google Maps  │               │   OpenAI API  │
│   UC-001      │              │  UC-006/007   │               │    UC-020     │
│   UC-002      │              │   UC-015      │               │    UC-022     │
│   UC-003      │              │   UC-030      │               └───────────────┘
└───────────────┘              └───────────────┘
        │                                 │
        ▼                                 ▼
┌───────────────┐              ┌───────────────┐               ┌───────────────┐
│    Firebase   │              │   Yapo.cl     │               │   SII API     │
│ Notifications │              │  (Scraping)   │               │  (Validación  │
│   UC-009      │              │   UC-030      │               │     RUT)      │
│   UC-012      │              └───────────────┘               │   UC-041      │
│   UC-029      │                                              └───────────────┘
└───────────────┘
```

### Casos de Uso por Épica

#### EPI-01: Gestión de Usuarios y Personalización
```
👤 Usuario/Cliente
    │
    ├── UC-001: Autenticación de Usuarios
    │   ├── [include] UC-002: Verificación de Email
    │   └── [include] UC-003: Gestión de Sesiones
    │
    ├── UC-004: Control de Acceso por Roles
    ├── UC-008: Gestión de Favoritos
    └── UC-009: Gestión de Notificaciones
        └── [include] Firebase Cloud Messaging
```

#### EPI-02: Búsqueda y Descubrimiento
```
👤 Usuario/Cliente ──────┐
🗺️ Google Maps API      │
                        │
    ┌───────────────────┴─────────────────┐
    │                                     │
    ├── UC-005: Búsqueda de Proveedores  │
    │   ├── [include] UC-006: Geolocalización
    │   ├── [include] UC-007: Geocodificación
    │   ├── [extend] UC-011: Historial de Búsquedas
    │   └── [extend] UC-016: Filtrado Avanzado
    │
    └── UC-015: Visualización en Mapa
        └── [include] Google Maps JavaScript API
```

#### EPI-03: Comparación y Evaluación
```
👤 Usuario/Cliente
    │
    ├── UC-017: Comparación de Precios
    ├── UC-018: Visualización de Detalles de Proveedor
    └── UC-019: Análisis de Servicios
```

#### EPI-04: Reseñas y Reputación
```
👤 Usuario/Cliente ──────┐
🏢 Proveedor ───────────┤
👨‍💼 Administrador        │
                        │
    ┌───────────────────┴─────────────────┐
    │                                     │
    ├── UC-025: Gestión de Reseñas       │
    │   ├── [include] UC-026: Moderación de Contenido
    │   └── [include] UC-027: Respuesta a Feedback
    │
    └── UC-028: Cálculo de Rating
```

#### EPI-05: Gestión de Reservas
```
👤 Usuario/Cliente ──────┐
🏢 Proveedor ───────────┤
📧 Email Service        │
📱 FCM                  │
                        │
    ┌───────────────────┴─────────────────┐
    │                                     │
    ├── UC-010: Gestión de Reservas      │
    │   ├── [include] UC-011: Validación de Disponibilidad
    │   ├── [include] UC-012: Notificaciones de Reserva
    │   ├── [include] UC-013: Prevención de Conflictos
    │   └── [extend] UC-014: Generación de QR
    │
    └── UC-029: Recordatorios Automáticos
        └── [include] Background Jobs (Cron)
```

#### EPI-06: IA y Agregación de Datos
```
👤 Usuario/Cliente ──────┐
🤖 OpenAI API ─────────┤
📦 Redis Cache         │
🕷️ Scrapers            │
🗺️ Google Maps API     │
🌐 Yapo.cl             │
                       │
    ┌──────────────────┴──────────────────┐
    │                                     │
    ├── UC-020: Sistema de Recomendaciones
    │   ├── [include] UC-021: Análisis de Comportamiento
    │   ├── [include] UC-022: Machine Learning
    │   ├── [extend] UC-023: Personalización de Experiencia
    │   └── [extend] UC-024: Feedback Loop
    │
    └── UC-030: Agregación Automática de Datos
        ├── [include] UC-031: Validación y Normalización
        ├── [include] UC-032: Deduplicación
        ├── [include] UC-033: Importación Masiva
        └── [extend] UC-034: Monitoreo de Fuentes
```

#### EPI-07: Portal de Proveedores
```
🏢 Proveedor ───────────┐
👨‍💼 Administrador       │
📧 Email Service        │
📊 Analytics System     │
                        │
    ┌───────────────────┴─────────────────┐
    │                                     │
    ├── UC-035: Registro de Proveedor    │
    ├── UC-036: Gestión de Perfil de Negocio
    ├── UC-037: Gestión de Catálogo de Servicios
    ├── UC-038: Configuración de Disponibilidad
    ├── UC-039: Analytics de Proveedor
    └── UC-040: Gestión de Promociones
```

#### EPI-08: Administración y Gobernanza
```
👨‍💼 Administrador ──────┐
🏛️ SII API             │
📊 Analytics System     │
🤖 Moderation System    │
                        │
    ┌───────────────────┴─────────────────┐
    │                                     │
    ├── UC-041: Verificación de Proveedores
    │   └── [include] Validación RUT (SII API)
    │
    ├── UC-042: Monitoreo de Plataforma
    ├── UC-043: Moderación de Contenido
    │   └── [include] Detección Automática
    │
    ├── UC-044: Gestión de Usuarios
    ├── UC-045: Configuración del Sistema
    └── UC-046: Auditoría y Logs
```

---

## Catálogo Completo de Casos de Uso

### UC-001: Autenticación de Usuarios
**Actores:** Usuario/Cliente, Clerk API  
**Descripción:** Permite registro, login y recuperación de contraseña  
**Incluye:** UC-002 (Verificación), UC-003 (Sesiones)  
**HUs Relacionadas:** HU-001, HU-002, HU-003

### UC-002: Verificación de Email
**Actores:** Usuario/Cliente, Email Service, Clerk API  
**Descripción:** Envío y validación de emails de verificación  
**Incluido por:** UC-001  
**HUs Relacionadas:** HU-001

### UC-003: Gestión de Sesiones
**Actores:** Usuario/Cliente, Sistema  
**Descripción:** Creación, renovación y expiración de sesiones JWT  
**Incluido por:** UC-001  
**HUs Relacionadas:** HU-002

### UC-004: Control de Acceso por Roles
**Actores:** Usuario/Cliente, Proveedor, Administrador  
**Descripción:** Validación de permisos según rol (CUSTOMER, PROVIDER, ADMIN)  
**Extiende:** UC-001  
**HUs Relacionadas:** HU-002

### UC-005: Búsqueda de Proveedores
**Actores:** Usuario/Cliente, PostgreSQL+PostGIS  
**Descripción:** Motor de búsqueda geolocalizado con consultas espaciales  
**Incluye:** UC-006 (Geolocalización), UC-007 (Geocodificación)  
**Extendido por:** UC-011 (Historial), UC-016 (Filtros)  
**HUs Relacionadas:** HU-005

### UC-006: Geolocalización
**Actores:** Usuario/Cliente, Navegador GPS  
**Descripción:** Obtención de coordenadas del dispositivo del usuario  
**Incluido por:** UC-005  
**HUs Relacionadas:** HU-005

### UC-007: Geocodificación
**Actores:** Sistema, Google Maps Geocoding API  
**Descripción:** Conversión de direcciones a coordenadas geográficas  
**Incluido por:** UC-005, UC-030  
**HUs Relacionadas:** HU-005, HU-030

### UC-008: Gestión de Favoritos
**Actores:** Usuario/Cliente  
**Descripción:** Agregar, quitar y listar proveedores favoritos  
**HUs Relacionadas:** HU-010

### UC-009: Gestión de Notificaciones
**Actores:** Usuario/Cliente, Firebase Cloud Messaging  
**Descripción:** Configuración y envío de notificaciones push  
**HUs Relacionadas:** HU-016

### UC-010: Gestión de Reservas
**Actores:** Usuario/Cliente, Proveedor  
**Descripción:** Creación, confirmación y seguimiento de reservas  
**Incluye:** UC-011 (Validación), UC-012 (Notificaciones), UC-013 (Conflictos)  
**Extendido por:** UC-014 (QR)  
**HUs Relacionadas:** HU-013, HU-014, HU-015, HU-022

### UC-011: Validación de Disponibilidad
**Actores:** Sistema  
**Descripción:** Verificación de slots disponibles con locks transaccionales  
**Incluido por:** UC-010  
**HUs Relacionadas:** HU-013

### UC-012: Notificaciones de Reserva
**Actores:** Email Service, Firebase Cloud Messaging  
**Descripción:** Envío de confirmaciones y recordatorios de reservas  
**Incluido por:** UC-010  
**HUs Relacionadas:** HU-013, HU-016

### UC-013: Prevención de Conflictos
**Actores:** Sistema  
**Descripción:** Manejo de concurrencia para evitar doble-booking  
**Incluido por:** UC-010  
**HUs Relacionadas:** HU-013

### UC-014: Generación de QR
**Actores:** Sistema  
**Descripción:** Creación de códigos QR únicos para reservas  
**Extiende:** UC-010  
**HUs Relacionadas:** HU-013

### UC-015: Visualización en Mapa
**Actores:** Usuario/Cliente, Google Maps JavaScript API  
**Descripción:** Mapa interactivo con marcadores de proveedores  
**HUs Relacionadas:** HU-007

### UC-016: Filtrado Avanzado
**Actores:** Usuario/Cliente  
**Descripción:** Aplicación de filtros múltiples a búsquedas  
**Extiende:** UC-005  
**HUs Relacionadas:** HU-006

### UC-017: Comparación de Precios
**Actores:** Usuario/Cliente  
**Descripción:** Tabla comparativa lado a lado de múltiples proveedores  
**HUs Relacionadas:** HU-008

### UC-018: Visualización de Detalles de Proveedor
**Actores:** Usuario/Cliente  
**Descripción:** Página completa con información del proveedor  
**HUs Relacionadas:** HU-009

### UC-019: Análisis de Servicios
**Actores:** Usuario/Cliente  
**Descripción:** Comparación detallada de servicios ofrecidos  
**HUs Relacionadas:** HU-008, HU-009

### UC-020: Sistema de Recomendaciones
**Actores:** Usuario/Cliente, OpenAI API, Redis  
**Descripción:** Generación de recomendaciones personalizadas con IA  
**Incluye:** UC-021 (Análisis), UC-022 (ML)  
**Extendido por:** UC-023 (Personalización), UC-024 (Feedback)  
**HUs Relacionadas:** HU-017

### UC-021: Análisis de Comportamiento
**Actores:** Sistema  
**Descripción:** Análisis de patrones de búsqueda y reservas del usuario  
**Incluido por:** UC-020  
**HUs Relacionadas:** HU-017

### UC-022: Machine Learning
**Actores:** OpenAI API  
**Descripción:** Integración con modelos de IA para recomendaciones  
**Incluido por:** UC-020  
**HUs Relacionadas:** HU-017

### UC-023: Personalización de Experiencia
**Actores:** Usuario/Cliente  
**Descripción:** Adaptación de UI según preferencias del usuario  
**Extiende:** UC-020  
**HUs Relacionadas:** HU-017

### UC-024: Feedback Loop
**Actores:** Usuario/Cliente, Sistema  
**Descripción:** Aprendizaje continuo basado en interacciones  
**Extiende:** UC-020  
**HUs Relacionadas:** HU-017

### UC-025: Gestión de Reseñas
**Actores:** Usuario/Cliente, Proveedor  
**Descripción:** Creación, moderación y respuesta a reseñas  
**Incluye:** UC-026 (Moderación), UC-027 (Respuesta)  
**HUs Relacionadas:** HU-012, HU-025

### UC-026: Moderación de Contenido
**Actores:** Administrador, Sistema de Moderación  
**Descripción:** Detección y eliminación de contenido inapropiado  
**Incluido por:** UC-025  
**HUs Relacionadas:** HU-012, HU-028

### UC-027: Respuesta a Feedback
**Actores:** Proveedor  
**Descripción:** Respuesta pública a reseñas de clientes  
**Incluido por:** UC-025  
**HUs Relacionadas:** HU-025

### UC-028: Cálculo de Rating
**Actores:** Sistema  
**Descripción:** Actualización automática de ratings de proveedores  
**HUs Relacionadas:** HU-012

### UC-029: Recordatorios Automáticos
**Actores:** Background Jobs (Cron), Email Service, FCM  
**Descripción:** Envío programado de recordatorios de reservas  
**HUs Relacionadas:** HU-016

### UC-030: Agregación Automática de Datos
**Actores:** Scrapers, Google Maps API, Yapo.cl  
**Descripción:** Scraping y extracción de datos de fuentes externas  
**Incluye:** UC-031 (Validación), UC-032 (Deduplicación), UC-033 (Importación)  
**Extendido por:** UC-034 (Monitoreo)  
**HUs Relacionadas:** HU-030

### UC-031: Validación y Normalización
**Actores:** Sistema  
**Descripción:** Limpieza y estandarización de datos scrapeados  
**Incluido por:** UC-030  
**HUs Relacionadas:** HU-030

### UC-032: Deduplicación
**Actores:** Sistema  
**Descripción:** Detección y eliminación de proveedores duplicados  
**Incluido por:** UC-030  
**HUs Relacionadas:** HU-030

### UC-033: Importación Masiva
**Actores:** Sistema, Administrador  
**Descripción:** Carga de datos validados a la base de datos  
**Incluido por:** UC-030  
**HUs Relacionadas:** HU-030

### UC-034: Monitoreo de Fuentes
**Actores:** Sistema  
**Descripción:** Detección de cambios en estructura de fuentes externas  
**Extiende:** UC-030  
**HUs Relacionadas:** HU-030

### UC-035: Registro de Proveedor
**Actores:** Proveedor, Administrador  
**Descripción:** Onboarding de nuevos proveedores a la plataforma  
**HUs Relacionadas:** HU-018

### UC-036: Gestión de Perfil de Negocio
**Actores:** Proveedor  
**Descripción:** Edición de información pública del negocio  
**HUs Relacionadas:** HU-019

### UC-037: Gestión de Catálogo de Servicios
**Actores:** Proveedor  
**Descripción:** CRUD de servicios ofrecidos por el proveedor  
**HUs Relacionadas:** HU-020

### UC-038: Configuración de Disponibilidad
**Actores:** Proveedor  
**Descripción:** Gestión de horarios y slots de reserva  
**HUs Relacionadas:** HU-021

### UC-039: Analytics de Proveedor
**Actores:** Proveedor, Analytics System  
**Descripción:** Dashboard con métricas y estadísticas del negocio  
**HUs Relacionadas:** HU-023

### UC-040: Gestión de Promociones
**Actores:** Proveedor  
**Descripción:** Creación y administración de ofertas especiales  
**HUs Relacionadas:** HU-024

### UC-041: Verificación de Proveedores
**Actores:** Administrador, SII API  
**Descripción:** Validación y aprobación de nuevos proveedores  
**Incluye:** Validación RUT con API SII  
**HUs Relacionadas:** HU-026

### UC-042: Monitoreo de Plataforma
**Actores:** Administrador, Analytics System  
**Descripción:** Dashboard con KPIs generales de la plataforma  
**HUs Relacionadas:** HU-027

### UC-043: Moderación de Contenido
**Actores:** Administrador, Sistema de Moderación  
**Descripción:** Gestión de contenido reportado o inapropiado  
**Incluye:** Detección automática de lenguaje inapropiado  
**HUs Relacionadas:** HU-028

### UC-044: Gestión de Usuarios
**Actores:** Administrador  
**Descripción:** Administración de cuentas de usuarios y proveedores  
**HUs Relacionadas:** HU-028

### UC-045: Configuración del Sistema
**Actores:** Administrador  
**Descripción:** Configuración global de parámetros de la plataforma  
**HUs Relacionadas:** HU-029

### UC-046: Auditoría y Logs
**Actores:** Administrador, Sistema  
**Descripción:** Registro y consulta de acciones administrativas  
**HUs Relacionadas:** HU-029

---

## Notas de Planificación

### Priorización para Sprints

**Sprint 1-2 (MVP Básico - 50 puntos):**
- Épica EPI-01: Gestión de Usuarios (sin HU-011, HU-016) → 19 puntos
- Épica EPI-02: Búsqueda y Descubrimiento (sin HU-007) → 13 puntos  
- HU-009: Visualización de detalles del proveedor → 5 puntos
- HU-018: Registro de proveedor → 8 puntos
- HU-019: Gestión de perfil de negocio → 5 puntos

**Sprint 3-4 (Funcionalidad Core - 55 puntos):**
- HU-008: Comparación de precios → 8 puntos
- HU-013: Reserva de servicio → 8 puntos
- HU-014: Cancelación de reserva → 3 puntos
- HU-020: Gestión de catálogo de servicios → 8 puntos
- HU-021: Configuración de horarios → 5 puntos
- HU-022: Gestión de reservas (proveedor) → 8 puntos
- HU-026: Verificación de proveedores → 8 puntos
- HU-007: Visualización de mapa → 8 puntos

**Sprint 5-6 (Engagement y Calidad - 45 puntos):**
- HU-012: Sistema de reseñas → 8 puntos
- HU-025: Respuesta a reseñas → 5 puntos
- HU-010: Favoritos → 5 puntos
- HU-015: Historial de reservas → 3 puntos
- HU-016: Notificaciones push → 5 puntos
- HU-024: Promociones → 8 puntos
- HU-027: Dashboard administrativo → 13 puntos

**Sprint 7-8 (Diferenciadores y Escala - 60 puntos):**
- HU-030: Scraping y agregación → 13 puntos
- HU-017: Recomendaciones con IA → 13 puntos
- HU-023: Dashboard de proveedor → 13 puntos
- HU-028: Moderación → 8 puntos
- HU-011: Historial de búsquedas → 3 puntos
- HU-029: Configuración del sistema → 5 puntos
- HU-006: Filtros avanzados → 5 puntos

### Criterios de Aceptación que Requieren Discusión

1. **HU-013 (Reservas):** Definir política de cancelación estándar (actualmente 2 horas, podría ser 24h).
2. **HU-017 (IA):** Evaluar costos de OpenAI API vs desarrollo de modelo propio.
3. **HU-030 (Scraping):** Revisar aspectos legales de scraping de competidores.
4. **HU-023, HU-027:** Definir si se implementa modelo de comisiones y cómo afecta los dashboards.
5. **HU-026:** Establecer SLA para verificación de proveedores (recomendado: 24-48h).

### Consideraciones Técnicas Importantes

- **Geolocalización (HU-005, HU-007):** Requiere optimización de consultas espaciales en PostgreSQL con índices GiST.
- **Notificaciones (HU-016):** Implementar con Firebase Cloud Messaging para cross-platform.
- **Scraping (HU-030):** Considerar uso de proxies rotatorios y respeto de rate limits.
- **IA (HU-017):** Evaluar fine-tuning de modelos vs uso directo de API OpenAI.
- **Mapas (HU-007):** Google Maps API tiene costos, evaluar alternativas como Mapbox para reducir costos.

### Riesgos Identificados

1. **Dependencia de Google Maps API:** Alto costo a escala, considerar plan de migración.
2. **Complejidad del sistema de reservas:** Requiere manejo robusto de concurrencia y race conditions.
3. **Calidad de datos scrapeados:** Puede requerir validación manual intensiva inicialmente.
4. **Adopción de proveedores:** Estrategia de acquisition crítica para el éxito del marketplace.

### Definición de "Done"

Para que una historia se considere completa, debe cumplir:
- ✅ Todos los criterios de aceptación implementados y verificados
- ✅ Tests unitarios con cobertura mínima 80%
- ✅ Tests de integración para flujos críticos
- ✅ Documentación técnica actualizada (README, JSDoc)
- ✅ Code review aprobado por al menos un desarrollador senior
- ✅ Deploy exitoso en ambiente de staging
- ✅ QA manual completado
- ✅ Performance verificado (tiempos de respuesta < 2s)
- ✅ Accesibilidad validada (WCAG 2.1 nivel AA mínimo)

---

## Matrices de Trazabilidad

### Matriz de Dependencias entre Historias de Usuario

| Historia | Depende de | Es requerida por |
|---|---|---|
| HU-001 | - | HU-002, HU-010, HU-011, HU-016, HU-017 |
| HU-002 | HU-001 | HU-004, HU-010, HU-011, HU-013, HU-015, HU-016, HU-017 |
| HU-003 | HU-001, HU-002 | - |
| HU-004 | HU-002 | - |
| HU-005 | - | HU-006, HU-007, HU-008, HU-009, HU-010, HU-011, HU-017 |
| HU-006 | HU-005 | - |
| HU-007 | HU-005 | - |
| HU-008 | HU-005 | - |
| HU-009 | HU-005 | HU-013 |
| HU-010 | HU-002, HU-005 | HU-017 |
| HU-011 | HU-002, HU-005 | - |
| HU-012 | HU-013 | HU-025 |
| HU-013 | HU-002, HU-009, HU-021 | HU-012, HU-014, HU-015, HU-017 |
| HU-014 | HU-013 | - |
| HU-015 | HU-013 | - |
| HU-016 | HU-002, HU-013 | - |
| HU-017 | HU-002, HU-005, HU-013, HU-010 | - |
| HU-018 | - | HU-019, HU-020, HU-021, HU-022, HU-023, HU-024, HU-025, HU-026 |
| HU-019 | HU-018 | - |
| HU-020 | HU-018 | - |
| HU-021 | HU-018 | HU-013, HU-022 |
| HU-022 | HU-018, HU-021 | HU-023 |
| HU-023 | HU-018, HU-022 | - |
| HU-024 | HU-018, HU-020 | - |
| HU-025 | HU-018, HU-012 | - |
| HU-026 | HU-018 | HU-027, HU-030 |
| HU-027 | Todas | - |
| HU-028 | HU-001, HU-012 | - |
| HU-029 | - | - |
| HU-030 | - | HU-026 |

### Matriz de Historias por Rol

| Rol | Historias de Usuario | Total Puntos |
|---|---|---|
| **Usuario/Cliente** | HU-001 a HU-017 | 98 pts |
| **Proveedor** | HU-018 a HU-025 | 60 pts |
| **Administrador** | HU-026 a HU-029 | 34 pts |
| **Sistema** | HU-030 | 13 pts |
| **Total** | 30 historias | **205 pts** |

### Matriz de Prioridades

| Prioridad | Historias | Total Puntos | % del Total |
|---|---|---|---|
| **Must Have** | HU-001, HU-002, HU-003, HU-005, HU-008, HU-009, HU-012, HU-013, HU-014, HU-018, HU-019, HU-020, HU-021, HU-022, HU-026, HU-027, HU-028, HU-030 | 138 pts | 66% |
| **Should Have** | HU-004, HU-006, HU-007, HU-010, HU-015, HU-016, HU-023, HU-024, HU-025, HU-029 | 54 pts | 26% |
| **Could Have** | HU-011, HU-017 | 16 pts | 8% |
| **Won't Have (v1)** | - | 0 pts | 0% |

### Matriz de Complejidad Técnica

| Complejidad | Puntos | Historias | Características |
|---|---|---|---|
| **Muy Alta (13 pts)** | 13 | HU-017, HU-023, HU-027, HU-030 | IA, Analytics complejos, Scraping multi-fuente |
| **Alta (8 pts)** | 8 | HU-005, HU-007, HU-008, HU-012, HU-013, HU-018, HU-020, HU-022, HU-024, HU-026, HU-028 | Geolocalización, Concurrencia, APIs externas |
| **Media (5 pts)** | 5 | HU-001, HU-006, HU-009, HU-010, HU-016, HU-019, HU-021, HU-025, HU-029 | CRUD complejo, Validaciones múltiples |
| **Baja (3 pts)** | 3 | HU-002, HU-003, HU-004, HU-011, HU-014, HU-015 | CRUD simple, Flujos estándar |

---

## Diagramas de Relaciones

### Diagrama de Flujo de Usuario (Customer Journey)

```
┌─────────────────────────────────────────────────────────────────────┐
│                      CUSTOMER JOURNEY - ALTO CARWASH                 │
└─────────────────────────────────────────────────────────────────────┘

1. ONBOARDING
   ┌──────────┐
   │ HU-001   │ Registro
   │ Register │──┐
   └──────────┘  │
                 ▼
   ┌──────────┐
   │ HU-002   │ Login
   │  Login   │──┐
   └──────────┘  │
                 ▼
   ┌──────────┐
   │ HU-004   │ Perfil
   │ Profile  │
   └──────────┘

2. DISCOVERY
   ┌──────────┐
   │ HU-005   │ Búsqueda por ubicación
   │  Search  │──┬──┐
   └──────────┘  │  │
                 ▼  ▼
   ┌──────────┐ ┌──────────┐
   │ HU-006   │ │ HU-007   │
   │ Filters  │ │   Map    │
   └──────────┘ └──────────┘
                 │
                 ▼
   ┌──────────┐ ┌──────────┐
   │ HU-008   │ │ HU-009   │
   │ Compare  │ │ Details  │
   └──────────┘ └──────────┘

3. ENGAGEMENT
   ┌──────────┐ ┌──────────┐
   │ HU-010   │ │ HU-017   │
   │Favorites │ │   AI     │
   └──────────┘ └──────────┘

4. BOOKING
   ┌──────────┐
   │ HU-013   │ Crear reserva
   │  Book    │──┬──┐
   └──────────┘  │  │
                 ▼  ▼
   ┌──────────┐ ┌──────────┐
   │ HU-016   │ │ HU-015   │
   │ Notifs   │ │ History  │
   └──────────┘ └──────────┘
                 │
                 ▼
   ┌──────────┐
   │ HU-014   │ Cancelar
   │ Cancel   │
   └──────────┘

5. FEEDBACK
   ┌──────────┐
   │ HU-012   │ Dejar review
   │ Review   │
   └──────────┘
```

### Diagrama de Flujo de Proveedor

```
┌─────────────────────────────────────────────────────────────────────┐
│                    PROVIDER JOURNEY - ALTO CARWASH                   │
└─────────────────────────────────────────────────────────────────────┘

1. ONBOARDING
   ┌──────────┐
   │ HU-018   │ Registro
   │ Register │──┐
   └──────────┘  │
                 ▼
   ┌──────────┐
   │ HU-026   │ Verificación (Admin)
   │ Verify   │──┐
   └──────────┘  │
                 ▼
   ┌──────────┐
   │ HU-019   │ Setup perfil
   │ Profile  │
   └──────────┘

2. SETUP
   ┌──────────┐
   │ HU-020   │ Catálogo de servicios
   │ Services │
   └──────────┘
                 │
                 ▼
   ┌──────────┐
   │ HU-021   │ Configurar horarios
   │ Schedule │
   └──────────┘

3. OPERATIONS
   ┌──────────┐
   │ HU-022   │ Gestionar reservas
   │ Bookings │──┐
   └──────────┘  │
                 ▼
   ┌──────────┐
   │ HU-025   │ Responder reviews
   │ Reviews  │
   └──────────┘

4. MARKETING
   ┌──────────┐
   │ HU-024   │ Promociones
   │Promotions│
   └──────────┘

5. ANALYTICS
   ┌──────────┐
   │ HU-023   │ Dashboard
   │Analytics │
   └──────────┘
   ┌──────────┐
   │ HU-044   │ Métricas visualizaciones
   │ Views    │
   └──────────┘
```

### Diagrama de Arquitectura de Sistema

```
┌─────────────────────────────────────────────────────────────────────┐
│                    SYSTEM ARCHITECTURE OVERVIEW                      │
└─────────────────────────────────────────────────────────────────────┘

EXTERNAL SERVICES
┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│   Clerk     │  │ Google Maps │  │  OpenAI API │
│  (Auth)     │  │    (Maps)   │  │    (AI)     │
└──────┬──────┘  └──────┬──────┘  └──────┬──────┘
       │                │                │
       └────────────────┼────────────────┘
                        │
                        ▼
┌───────────────────────────────────────────────────────────┐
│                    BACKEND (NestJS)                       │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐ │
│  │   Auth   │  │  Search  │  │ Bookings │  │    IA    │ │
│  │ (HU-001) │  │ (HU-005) │  │ (HU-013) │  │ (HU-017) │ │
│  │ (HU-002) │  │ (HU-006) │  │ (HU-014) │  │ (HU-031) │ │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘ │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐ │
│  │Providers │  │ Reviews  │  │Analytics │  │  Email   │ │
│  │ (HU-018) │  │ (HU-012) │  │ (HU-023) │  │ (HU-016) │ │
│  │ (HU-019) │  │ (HU-025) │  │ (HU-027) │  │          │ │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘ │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐ │
│  │  Testing │  │  CI/CD   │  │  Backup  │  │  Audit   │ │
│  │ (HU-038) │  │ (HU-042) │  │ (HU-047) │  │ (HU-048) │ │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘ │
└────────────────────────┬──────────────────────────────────┘
                         │
                         ▼
┌───────────────────────────────────────────────────────────┐
│              DATABASE (PostgreSQL + PostGIS)              │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐ │
│  │  Users   │  │Providers │  │ Bookings │  │ Reviews  │ │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘ │
└───────────────────────────────────────────────────────────┘
                         │
                         ▼
┌───────────────────────────────────────────────────────────┐
│                    FRONTEND (Next.js)                     │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐ │
│  │  Pages   │  │Components│  │  Hooks   │  │ Contexts │ │
│  │ (Routes) │  │   (UI)   │  │ (Logic)  │  │ (State)  │ │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘ │
└───────────────────────────────────────────────────────────┘
                         │
                         ▼
┌───────────────────────────────────────────────────────────┐
│                  SCRAPER (Node.js)                        │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐                │
│  │  Google  │  │   Yapo   │  │ Importer │  (HU-030)      │
│  │   Maps   │  │ Scraper  │  │ (Prisma) │                │
│  └──────────┘  └──────────┘  └──────────┘                │
└───────────────────────────────────────────────────────────┘
```

---

## 📝 Historias de Usuario Nuevas (HU-031 a HU-048)

Las siguientes historias de usuario se agregaron para cubrir los requerimientos faltantes identificados en el análisis de cobertura.

---

### HU-031: Sistema de alertas de precios

**Título:** Como usuario, quiero configurar alertas de precios para ser notificado cuando el precio de un servicio baje a mi rango objetivo.

**Descripción:**  
Sistema de alertas personaliz</content>adas que monitorea cambios de precios y notifica al usuario cuando se cumplen las condiciones establecidas. Permite al usuario definir servicios de interés y umbrales de precio.

**Requisitos Asociados:**
- **REQ-FUNC-006:** Configuración de alertas de precios
- **REQ-FUNC-030:** Alertas de cambios de precios significativos
- **REQ-NF-039:** Notificaciones en tiempo real

**Constraints:**
- Usuario debe estar autenticado
- Máximo 10 alertas activas por usuario
- Monitoreo cada 6 horas (cron job)
- Alerta se desactiva automáticamente tras 30 días
- Requiere servicio de notificaciones activo
- Cambio mínimo de precio para activar: 5% o $1.000 CLP

**Entry Points:**
- **UI:** `/user/price-alerts` - Gestión de alertas
- **UI:** `/provider/[id]` - Botón "Crear alerta de precio"
- **API:** `POST /api/alerts/price` - Crear alerta
- **API:** `GET /api/alerts/price` - Listar alertas
- **API:** `DELETE /api/alerts/price/[id]` - Eliminar alerta
- **Cron:** Job cada 6h para verificar cambios de precios

**Context References:**
- **Módulos:** `backend/src/alerts`, `backend/src/notifications`, `backend/src/services`
- **Servicios:** `AlertsService`, `PriceMonitorService`, `NotificationsService`
- **Tablas:** `price_alerts`, `services`, `price_history`
- **Componentes:** `PriceAlertForm`, `PriceAlertList`, `PriceAlertCard`
- **Jobs:** `PriceMonitorJob` (cron every 6h)

**Criterios de Aceptación:**
1. **CA-1:** Usuario puede crear alerta especificando: servicio, proveedor, precio objetivo o % de descuento
2. **CA-2:** Sistema monitorea precios cada 6 horas y compara con alertas activas
3. **CA-3:** Cuando precio cumple condición, envía notificación push + email al usuario
4. **CA-4:** Usuario puede ver, editar y eliminar sus alertas desde `/user/price-alerts`
5. **CA-5:** Alerta incluye: precio anterior, precio nuevo, % ahorro, link directo al servicio
6. **CA-6:** Sistema desactiva alertas automáticamente tras 30 días sin activación

**Story Points:** 8  
**Prioridad:** Must  
**Dependencias:** HU-002, HU-009, HU-016

---

### HU-032: Importación masiva CSV/Excel

**Título:** Como admin o proveedor, quiero importar múltiples servicios/proveedores desde un archivo CSV/Excel para agilizar la carga de datos.

**Descripción:**  
Herramienta de importación que permite cargar masivamente datos de servicios y proveedores desde archivos CSV o Excel, con validación, preview y reporte de errores.

**Requisitos Asociados:**
- **REQ-FUNC-014:** Carga masiva de información vía CSV/Excel
- **REQ-NF-055:** Validación de datos antes de importar

**Constraints:**
- Archivo máximo: 10MB
- Formatos soportados: .csv, .xlsx
- Máximo 500 registros por archivo
- Requiere rol ADMIN o PROVIDER
- Validación de campos obligatorios antes de importar
- Modo dry-run para preview
- Codificación: UTF-8

**Entry Points:**
- **UI:** `/admin/import` - Herramienta de importación (admin)
- **UI:** `/provider/import` - Importar servicios (proveedor)
- **API:** `POST /api/import/preview` - Preview de datos
- **API:** `POST /api/import/execute` - Ejecutar importación
- **API:** `GET /api/import/template` - Descargar template

**Context References:**
- **Módulos:** `backend/src/import`, `backend/src/providers`, `backend/src/services`
- **Servicios:** `ImportService`, `CsvParser`, `ExcelParser`, `DataValidator`
- **Tablas:** `providers`, `services`, `import_logs`
- **Componentes:** `FileUploader`, `ImportPreview`, `ImportResults`
- **Libraries:** `papaparse` (CSV), `xlsx` (Excel)

**Criterios de Aceptación:**
1. **CA-1:** Usuario puede descargar template CSV/Excel con campos requeridos y ejemplos
2. **CA-2:** Sistema valida archivo antes de importar: formato, tamaño, estructura
3. **CA-3:** Preview muestra primeros 10 registros con validaciones (errores en rojo)
4. **CA-4:** Importación procesa en modo transaccional: todo o nada
5. **CA-5:** Reporte post-importación muestra: exitosos, fallidos, errores por línea
6. **CA-6:** Admin puede importar proveedores y servicios; Proveedor solo sus servicios

**Story Points:** 8  
**Prioridad:** Should  
**Dependencias:** HU-018, HU-020, HU-026

---

### HU-033: Comparación histórica de precios

**Título:** Como usuario, quiero ver la evolución histórica de precios de un servicio para tomar decisiones informadas sobre cuándo reservar.

**Descripción:**  
Gráfico interactivo que muestra la evolución de precios de un servicio específico en el tiempo, permitiendo identificar tendencias, temporadas altas/bajas y mejor momento para reservar.

**Requisitos Asociados:**
- **REQ-FUNC-031:** Comparación histórica de precios
- **REQ-NF-056:** Visualización de datos históricos

**Constraints:**
- Requiere mínimo 30 días de datos históricos
- Almacenar snapshot de precios diariamente
- Retención: últimos 12 meses
- Gráfico responsive
- Máximo 5 servicios comparables simultáneamente
- Actualización de historical data: diaria (cron)

**Entry Points:**
- **UI:** `/provider/[id]/service/[serviceId]/history` - Gráfico histórico
- **UI:** `/compare` - Comparación histórica de múltiples servicios
- **API:** `GET /api/services/[id]/price-history?range=30d` - Datos históricos
- **Cron:** Job diario para snapshot de precios

**Context References:**
- **Módulos:** `backend/src/analytics`, `backend/src/services`
- **Servicios:** `PriceHistoryService`, `AnalyticsService`
- **Tablas:** `price_history`, `services`
- **Componentes:** `PriceHistoryChart`, `TrendIndicator`, `SeasonalityCard`
- **Libraries:** `recharts` (gráficos), `date-fns` (fechas)
- **Jobs:** `PriceSnapshotJob` (daily)

**Criterios de Aceptación:**
1. **CA-1:** Gráfico de línea muestra evolución de precio en eje Y y fecha en eje X
2. **CA-2:** Usuario puede seleccionar rango: 7d, 30d, 90d, 6m, 12m
3. **CA-3:** Gráfico muestra indicadores: precio min, máx, promedio, precio actual
4. **CA-4:** Sistema detecta y muestra tendencia: alza, baja, estable
5. **CA-5:** Tooltip al hover muestra: fecha, precio, % cambio vs precio actual
6. **CA-6:** Exportar datos históricos a CSV

**Story Points:** 13  
**Prioridad:** Should  
**Dependencias:** HU-009, HU-020

---

### HU-034: Calculadora de ahorro

**Título:** Como usuario, quiero ver cuánto ahorro eligiendo la opción más barata para motivar mi decisión de compra.

**Descripción:**  
Calculadora que muestra el ahorro económico al comparar la opción más barata vs la más cara o vs el promedio del mercado, con visualización clara del impacto económico.

**Requisitos Asociados:**
- **REQ-FUNC-032:** Calculadora de ahorro potencial
- **REQ-NF-057:** Cálculo en tiempo real

**Constraints:**
- Cálculo en tiempo real sin llamadas extra a BD
- Basado en resultados de búsqueda actuales
- Mostrar ahorro en $ y %
- Considerar hasta 50 proveedores para estadísticas
- Cache de promedios de mercado (24h)

**Entry Points:**
- **UI:** `/results` - Widget de ahorro en resultados
- **UI:** `/compare` - Resumen de ahorro en comparación
- **API:** `GET /api/analytics/market-average?serviceType=FULL_WASH` - Promedio mercado

**Context References:**
- **Módulos:** `backend/src/analytics`, `backend/src/search`
- **Servicios:** `SavingsCalculator`, `MarketAnalyticsService`
- **Componentes:** `SavingsCard`, `SavingsHighlight`, `SavingsBadge`
- **Cache:** Redis para promedios de mercado

**Criterios de Aceptación:**
1. **CA-1:** Card muestra: "Ahorraste $X (Y%) vs precio promedio"
2. **CA-2:** Comparación muestra ahorro de opción más barata vs más cara
3. **CA-3:** Badge verde en resultado más barato: "¡Mejor precio! Ahorra $X"
4. **CA-4:** Tooltip explica cálculo: "Comparado con N proveedores en radio de X km"
5. **CA-5:** Ahorro proyectado anual si servicio es recurrente (ej: mensual)
6. **CA-6:** Ahorro se actualiza dinámicamente al filtrar resultados

**Story Points:** 5  
**Prioridad:** Should  
**Dependencias:** HU-005, HU-008

---

### HU-035: Exportar comparación (PDF)

**Título:** Como usuario, quiero exportar la tabla comparativa como PDF o imagen para compartir con otras personas o guardar para referencia.

**Descripción:**  
Funcionalidad de exportación que genera PDF o imagen de la tabla comparativa con diseño profesional, incluyendo logos, precios, ratings y servicios incluidos.

**Requisitos Asociados:**
- **REQ-FUNC-034:** Exportación de comparaciones (PDF)
- **REQ-NF-058:** Calidad de exportación

**Constraints:**
- Máximo 4 proveedores por exportación
- Formatos: PDF, PNG, JPG
- Tamaño máximo PDF: 5MB
- Incluir marca de agua "Alto Carwash"
- Resolución PNG: 1920x1080
- Generación del lado del servidor (puppeteer)

**Entry Points:**
- **UI:** `/compare` - Botón "Exportar PDF/Imagen"
- **API:** `POST /api/comparison/export` - Generar exportación
- **API:** `GET /api/comparison/export/[id]` - Descargar archivo

**Context References:**
- **Módulos:** `backend/src/export`, `backend/src/comparison`
- **Servicios:** `ExportService`, `PdfGenerator`, `ImageRenderer`
- **Libraries:** `puppeteer` (PDF), `sharp` (imagen)
- **Templates:** `comparison-template.html` (diseño)

**Criterios de Aceptación:**
1. **CA-1:** Usuario selecciona formato (PDF/PNG/JPG) desde modal
2. **CA-2:** PDF incluye: tabla comparativa, logos, precios, ratings, fecha generación
3. **CA-3:** Diseño profesional con marca "Alto Carwash" y colores corporativos
4. **CA-4:** Archivo descarga automáticamente con nombre: `comparacion-{fecha}.pdf`
5. **CA-5:** Generación completa en <10 segundos
6. **CA-6:** Botón de compartir directo a WhatsApp/Email

**Story Points:** 5  
**Prioridad:** Could  
**Dependencias:** HU-008

---

### HU-036: Compartir en redes sociales

**Título:** Como usuario, quiero compartir comparaciones, proveedores favoritos o búsquedas en redes sociales para recomendar a amigos o familiares.

**Descripción:**  
Integración con redes sociales que permite compartir contenido de la plataforma con previews enriquecidos (Open Graph), generando links únicos con metadata.

**Requisitos Asociados:**
- **REQ-FUNC-041:** Compartir comparaciones vía redes sociales
- **REQ-NF-059:** Open Graph metadata

**Constraints:**
- Redes soportadas: WhatsApp, Facebook, Twitter/X, LinkedIn
- Links con preview (og:image, og:title, og:description)
- Links dinámicos no expiran
- Track de compartidos (analytics)
- Imágenes de preview pre-generadas (Open Graph)

**Entry Points:**
- **UI:** Botón "Compartir" en proveedores, comparaciones, búsquedas
- **API:** `POST /api/share/generate` - Generar link compartible
- **API:** `GET /share/[id]` - Página de preview

**Context References:**
- **Módulos:** `backend/src/share`, `frontend/src/components/share`
- **Servicios:** `ShareService`, `MetaTagsGenerator`
- **Componentes:** `ShareModal`, `ShareButtons`, `SocialPreview`
- **Meta tags:** Open Graph, Twitter Cards

**Criterios de Aceptación:**
1. **CA-1:** Modal muestra botones para: WhatsApp, Facebook, Twitter, LinkedIn, Copiar link
2. **CA-2:** Link compartido incluye preview con imagen, título, descripción
3. **CA-3:** Preview de proveedor: logo, rating, precio desde, ubicación
4. **CA-4:** Preview de comparación: "Compara X autolavados | Alto Carwash"
5. **CA-5:** Click en link compartido redirige a página específica en la plataforma
6. **CA-6:** Sistema trackea compartidos para analytics

**Story Points:** 3  
**Prioridad:** Could  
**Dependencias:** HU-008, HU-009

---

### HU-037: Accesibilidad WCAG 2.1 AA

**Título:** Como usuario con discapacidad, quiero que la plataforma sea accesible para poder usar todos sus servicios sin barreras.

**Descripción:**  
Implementación de estándares de accesibilidad WCAG 2.1 nivel AA, incluyendo navegación por teclado, soporte para lectores de pantalla, contraste adecuado y ARIA labels.

**Requisitos Asociados:**
- **REQ-NF-072:** Accesibilidad web (WCAG 2.1 nivel AA)
- **REQ-NF-073:** Soporte para tecnologías asistivas

**Constraints:**
- Cumplimiento WCAG 2.1 AA completo
- Navegación 100% con teclado (tab, enter, esc)
- Contraste mínimo 4.5:1 (texto normal), 3:1 (texto grande)
- ARIA labels en todos los componentes interactivos
- Screen reader testing (NVDA, JAWS)
- Focus visible en todos los elementos interactivos

**Entry Points:**
- Toda la aplicación (transversal)
- Configuración en: `/user/accessibility-settings`

**Context References:**
- **Módulos:** Transversal a todo el frontend
- **Componentes:** Todos los componentes UI
- **Libraries:** `@react-aria/interactions`, `@axe-core/react`
- **Testing:** `jest-axe`, `pa11y`

**Criterios de Aceptación:**
1. **CA-1:** Navegación completa con teclado: Tab, Shift+Tab, Enter, Esc, Arrow keys
2. **CA-2:** Todos los elementos interactivos tienen focus visible (outline)
3. **CA-3:** ARIA labels descriptivos en botones, links, forms, modals
4. **CA-4:** Contraste de colores cumple 4.5:1 en texto y 3:1 en elementos grandes
5. **CA-5:** Lectores de pantalla anuncian correctamente: heading hierarchy, landmarks, status
6. **CA-6:** Formularios con labels asociados, errores descriptivos, instrucciones claras
7. **CA-7:** Skip links para saltar navegación principal
8. **CA-8:** Testing automatizado con axe-core y pa11y sin errores críticos

**Story Points:** 13  
**Prioridad:** Must  
**Dependencias:** Todas las HUs de UI

---

### HU-038: Suite de testing automatizado

**Título:** Como desarrollador, quiero una suite de testing completa para asegurar calidad del código y prevenir regresiones.

**Descripción:**  
Implementación de testing automatizado: unitario (Jest), integración (Supertest), E2E (Playwright), con coverage >80% y CI integration.

**Requisitos Asociados:**
- **REQ-NF-082:** Pruebas automatizadas (unitarias e integración)
- **REQ-NF-081:** Código mantenible

**Constraints:**
- Coverage mínimo: 80% líneas de código
- Tests deben ejecutarse en <5 minutos
- Tests E2E en múltiples navegadores (Chrome, Firefox, Safari)
- Tests en CI/CD pipeline (bloquean merge si fallan)
- Tests de API con casos edge y errores

**Entry Points:**
- **CLI:** `npm test` - Ejecutar tests unitarios
- **CLI:** `npm run test:e2e` - Tests E2E
- **CLI:** `npm run test:coverage` - Reporte de coverage
- **CI:** GitHub Actions / GitLab CI

**Context References:**
- **Frameworks:** Jest (unit), Supertest (API), Playwright (E2E)
- **Config:** `jest.config.js`, `playwright.config.ts`
- **Coverage:** Codecov / SonarQube
- **Files:** `**/*.spec.ts`, `**/*.test.ts`, `e2e/**/*.spec.ts`

**Criterios de Aceptación:**
1. **CA-1:** Tests unitarios para servicios críticos: Auth, Booking, Search, Payment
2. **CA-2:** Tests de integración para endpoints API críticos (>50 tests)
3. **CA-3:** Tests E2E para flujos principales: registro, login, búsqueda, reserva
4. **CA-4:** Coverage total >80% en backend y >70% en frontend
5. **CA-5:** Tests ejecutan en CI/CD, fallos bloquean merge
6. **CA-6:** Reportes de coverage publicados y visibles en PR
7. **CA-7:** Tests de regresión para bugs críticos corregidos

**Story Points:** 13  
**Prioridad:** Must  
**Dependencias:** Todas las HUs

---

### HU-039: Preferencias de búsqueda avanzadas

**Título:** Como usuario, quiero configurar preferencias de búsqueda por defecto para agilizar futuras búsquedas.

**Descripción:**  
Panel de preferencias donde usuario configura defaults: tipos de servicio favoritos, rango de precio, radio de búsqueda, ordenamiento preferido.

**Requisitos Asociados:**
- **REQ-FUNC-007:** Preferencias de búsqueda personalizadas
- **REQ-NF-060:** Persistencia de preferencias

**Constraints:**
- Usuario debe estar autenticado
- Preferencias se aplican automáticamente en búsquedas
- Usuario puede override en búsqueda específica
- Sincronización entre dispositivos
- Preferencias en tabla `user_preferences`

**Entry Points:**
- **UI:** `/user/preferences/search` - Configuración
- **API:** `PUT /api/users/preferences/search` - Actualizar
- **API:** `GET /api/users/preferences/search` - Obtener

**Context References:**
- **Módulos:** `backend/src/users`, `backend/src/search`
- **Tablas:** `user_preferences`
- **Componentes:** `SearchPreferencesForm`, `PreferenceToggle`

**Criterios de Aceptación:**
1. **CA-1:** Usuario configura: tipos de servicio preferidos (multiselect)
2. **CA-2:** Usuario configura: rango de precio (min-max slider)
3. **CA-3:** Usuario configura: radio de búsqueda default (1, 5, 10, 20 km)
4. **CA-4:** Usuario configura: ordenamiento default (distancia, precio, rating)
5. **CA-5:** Preferencias se pre-llenan automáticamente en barra de búsqueda
6. **CA-6:** Usuario puede resetear a defaults del sistema

**Story Points:** 5  
**Prioridad:** Should  
**Dependencias:** HU-004, HU-005, HU-006

---

### HU-040: Modo offline (PWA)

**Título:** Como usuario, quiero acceder a mis búsquedas recientes y favoritos sin conexión para consultar información offline.

**Descripción:**  
Implementación de Progressive Web App (PWA) con Service Worker que cachea búsquedas recientes, favoritos y páginas de proveedores visitados para acceso offline.

**Requisitos Asociados:**
- **REQ-FUNC-040:** Modo offline para datos consultados frecuentemente
- **REQ-NF-075:** Modo offline básico para aplicación móvil

**Constraints:**
- Caché máximo: 50MB
- Datos offline: últimas 10 búsquedas, todos los favoritos, últimos 20 proveedores
- Sync automático al recuperar conexión
- Indicador visual de modo offline
- Service Worker compatible: Chrome, Firefox, Safari 11.1+

**Entry Points:**
- **PWA:** `manifest.json`, `service-worker.js`
- **UI:** Indicador "Offline" en header
- **Cache:** Service Worker Cache API

**Context References:**
- **Files:** `public/manifest.json`, `public/service-worker.js`
- **Libraries:** Workbox (Google)
- **Strategies:** Network First (API), Cache First (static)

**Criterios de Aceptación:**
1. **CA-1:** App instalable como PWA en móviles (botón "Agregar a pantalla de inicio")
2. **CA-2:** Service Worker cachea: últimas búsquedas, favoritos, proveedores visitados
3. **CA-3:** Sin conexión, usuario puede ver datos cacheados con banner "Modo Offline"
4. **CA-4:** Al recuperar conexión, sync automático actualiza datos desactualizados
5. **CA-5:** Íconos y splash screen para instalación PWA
6. **CA-6:** Funciona offline: ver favoritos, búsquedas recientes, detalles proveedores

**Story Points:** 13  
**Prioridad:** Should  
**Dependencias:** HU-005, HU-009, HU-010

---

### HU-041: Deep links a apps de navegación

**Título:** Como usuario, quiero abrir la dirección del proveedor directamente en mi app de navegación favorita (Google Maps, Waze, Apple Maps).

**Descripción:**  
Botones que generan deep links a aplicaciones de navegación instaladas en el dispositivo del usuario, pre-llenando la dirección de destino.

**Requisitos Asociados:**
- **REQ-FUNC-042:** Integración con aplicaciones de navegación
- **REQ-NF-061:** Deep linking móvil

**Constraints:**
- Detección automática de plataforma (iOS/Android/Desktop)
- Fallback a Google Maps web si apps no instaladas
- Deep links: `https://maps.google.com/`, `waze://`, `maps://`
- Coordenadas lat/lng para precisión

**Entry Points:**
- **UI:** `/provider/[id]` - Botones "Cómo llegar"
- **UI:** `/results` - Botón en cada card de proveedor

**Context References:**
- **Components:** `NavigationButtons`, `DirectionsButton`
- **Utils:** `generateDeepLink()`, `detectPlatform()`

**Criterios de Aceptación:**
1. **CA-1:** Botones: "Google Maps", "Waze", "Apple Maps" (iOS only)
2. **CA-2:** Click abre app correspondiente con dirección pre-cargada
3. **CA-3:** Si app no instalada, abre Google Maps en navegador
4. **CA-4:** Deep link usa coordenadas lat/lng para precisión
5. **CA-5:** Funciona en móviles y desktop (desktop abre web)

**Story Points:** 3  
**Prioridad:** Should  
**Dependencias:** HU-007, HU-009

---

### HU-042: Pipeline CI/CD

**Título:** Como equipo de desarrollo, queremos un pipeline CI/CD automatizado para deployment seguro y rápido a staging y producción.

**Descripción:**  
Pipeline automatizado con GitHub Actions / GitLab CI que ejecuta tests, linting, build y deploy a staging/production con aprobaciones.

**Requisitos Asociados:**
- **REQ-NF-079:** Procedimientos de despliegue automatizados
- **REQ-NF-080:** Sistema de versionado de API

**Constraints:**
- Pipeline en GitHub Actions o GitLab CI
- Tests obligatorios antes de merge (status checks)
- Deploy a staging automático en merge a `develop`
- Deploy a production manual (requiere aprobación)
- Rollback automático si health checks fallan
- Environments: staging, production

**Entry Points:**
- **CI/CD:** `.github/workflows/ci.yml`, `.github/workflows/deploy.yml`
- **Scripts:** `package.json` scripts

**Context References:**
- **Tools:** GitHub Actions, Docker, Vercel/Railway/AWS
- **Config:** `.github/workflows/`, `Dockerfile`, `docker-compose.yml`
- **Monitoring:** Health checks, Sentry

**Criterios de Aceptación:**
1. **CA-1:** Pipeline ejecuta en cada push: lint, test, build
2. **CA-2:** Merge a `develop` → deploy automático a staging
3. **CA-3:** Merge a `main` → deploy manual a production (con aprobación)
4. **CA-4:** Tests fallan → bloquea merge y deploy
5. **CA-5:** Deploy include health checks post-deployment
6. **CA-6:** Rollback automático si health checks fallan
7. **CA-7:** Notificaciones en Slack/Discord de deploy exitoso/fallido

**Story Points:** 8  
**Prioridad:** Must  
**Dependencias:** HU-038

---

### HU-043: Categorización avanzada de proveedores

**Título:** Como admin o proveedor, quiero categorizar proveedores con tags y especialidades para mejorar la búsqueda y filtrado.

**Descripción:**  
Sistema de tags y categorías que permite clasificar proveedores por especialidades, certificaciones, servicios destacados y características especiales.

**Requisitos Asociados:**
- **REQ-FUNC-016:** Sistema de categorización de proveedores
- **REQ-NF-062:** Taxonomía flexible

**Constraints:**
- Tags predefinidos + custom
- Máximo 10 tags por proveedor
- Tags en tabla `provider_tags` (many-to-many)
- Búsqueda por tags
- Admin puede crear nuevos tags

**Entry Points:**
- **UI:** `/provider/profile` - Selección de tags
- **UI:** `/admin/tags` - Gestión de tags (admin)
- **API:** `GET /api/tags` - Listar tags disponibles
- **API:** `PUT /api/providers/[id]/tags` - Actualizar tags

**Context References:**
- **Módulos:** `backend/src/providers`, `backend/src/tags`
- **Tablas:** `tags`, `provider_tags` (junction)
- **Components:** `TagSelector`, `TagBadge`, `TagFilter`

**Criterios de Aceptación:**
1. **CA-1:** Proveedor selecciona tags: "Lavado ecológico", "Servicio express", "Abierto 24/7"
2. **CA-2:** Tags se muestran como badges en card y perfil del proveedor
3. **CA-3:** Usuario puede filtrar por tags en búsqueda avanzada
4. **CA-4:** Admin puede crear, editar, eliminar tags desde panel
5. **CA-5:** Autocomplete de tags al escribir
6. **CA-6:** Tags populares se muestran primero en selector

**Story Points:** 5  
**Prioridad:** Could  
**Dependencias:** HU-006, HU-019

---

### HU-044: Métricas de visualizaciones

**Título:** Como proveedor, quiero ver cuántas veces mi perfil ha sido visualizado para medir el impacto de mi presencia en la plataforma.

**Descripción:**  
Dashboard de métricas que muestra visualizaciones de perfil, clicks, búsquedas que incluyeron el proveedor, conversión a reservas.

**Requisitos Asociados:**
- **REQ-FUNC-017:** Métricas básicas de visualizaciones
- **REQ-NF-063:** Analytics en tiempo real

**Constraints:**
- Tracking de eventos: profile_view, service_click, booking_started
- Retención de datos: 12 meses
- Actualización de dashboard: cada hora
- Privacidad: datos agregados, sin identificar usuarios
- Tabla `provider_analytics`

**Entry Points:**
- **UI:** `/provider/analytics` - Dashboard de métricas
- **API:** `GET /api/providers/[id]/analytics?range=30d`
- **Event tracking:** Frontend analytics events

**Context References:**
- **Módulos:** `backend/src/analytics`
- **Tablas:** `provider_analytics`, `analytics_events`
- **Components:** `AnalyticsDashboard`, `MetricsCard`, `ViewsChart`
- **Libraries:** Google Analytics / Mixpanel

**Criterios de Aceptación:**
1. **CA-1:** Dashboard muestra: views totales, clicks, conversión a reservas
2. **CA-2:** Gráfico de views por día (últimos 7, 30, 90 días)
3. **CA-3:** Métricas: tasa de conversión (views → reservas), tiempo promedio en perfil
4. **CA-4:** Comparación vs periodo anterior (↑15% vs mes pasado)
5. **CA-5:** Top servicios más visualizados
6. **CA-6:** Fuentes de tráfico: búsqueda, comparación, favoritos, directo

**Story Points:** 5  
**Prioridad:** Could  
**Dependencias:** HU-023

---

### HU-045: Actualización automática de precios

**Título:** Como sistema, quiero scrapear y actualizar precios de proveedores automáticamente de forma periódica para mantener datos actualizados.

**Descripción:**  
Cron job que ejecuta scraping periódico de fuentes externas (Yapo, Google Maps, sitios web) para actualizar precios y servicios automáticamente.

**Requisitos Asociados:**
- **REQ-FUNC-029:** Sistema de actualización automática de precios
- **REQ-NF-064:** Scraping ético

**Constraints:**
- Cron: ejecución semanal o manual
- Rate limiting: max 10 req/s
- Respeto de robots.txt
- Detección de cambios: actualiza solo si diferencia >5%
- Notificación a proveedor de cambios detectados
- Requiere aprobación de proveedor antes de aplicar

**Entry Points:**
- **Cron:** Weekly scraper job
- **API:** `POST /api/scraper/run` - Trigger manual (admin)
- **UI:** `/admin/scraper` - Gestión de scraper

**Context References:**
- **Módulos:** `backend/src/aggregator`, `scraper/src`
- **Services:** `AutoScraperService`, `PriceComparator`
- **Jobs:** `WeeklyPriceUpdateJob`

**Criterios de Aceptación:**
1. **CA-1:** Cron ejecuta semanalmente, scrapea fuentes configuradas
2. **CA-2:** Detecta cambios de precio >5% y los marca como pendientes
3. **CA-3:** Envía email a proveedor: "Se detectaron cambios en tus precios"
4. **CA-4:** Proveedor aprueba/rechaza cambios desde panel
5. **CA-5:** Si aprobado, actualiza servicios; si rechazado, mantiene actual
6. **CA-6:** Log de cambios históricos de precios

**Story Points:** 13  
**Prioridad:** Could  
**Dependencias:** HU-030

---

### HU-046: API pública documentada (OpenAPI)

**Título:** Como desarrollador externo, quiero acceder a documentación completa de la API para integrar con Alto Carwash.

**Descripción:**  
Documentación interactiva de API REST con Swagger/OpenAPI, incluyendo endpoints, schemas, ejemplos y playground para testing.

**Requisitos Asociados:**
- **REQ-FUNC-035:** API para consulta externa de precios
- **REQ-NF-076:** Documentación técnica completa de la API

**Constraints:**
- Swagger UI accesible en `/api/docs`
- OpenAPI spec 3.0
- Autenticación: API keys
- Rate limiting: 100 req/min por API key
- Versionado: `/api/v1/`
- Documentación en español e inglés

**Entry Points:**
- **UI:** `/api/docs` - Swagger UI
- **API:** `/api/openapi.json` - OpenAPI spec
- **API:** `/api/v1/*` - Endpoints versionados

**Context References:**
- **Modules:** `backend/src/docs`
- **Libraries:** `@nestjs/swagger`
- **Decorators:** `@ApiOperation`, `@ApiResponse`, `@ApiProperty`

**Criterios de Aceptación:**
1. **CA-1:** Swagger UI en `/api/docs` lista todos los endpoints
2. **CA-2:** Cada endpoint documentado: descripción, parámetros, responses, ejemplos
3. **CA-3:** Schemas de datos con DTOs y tipos completos
4. **CA-4:** Playground interactivo: "Try it out" funciona con API keys
5. **CA-5:** Ejemplos de requests/responses para cada endpoint
6. **CA-6:** Guía de autenticación con API keys
7. **CA-7:** Changelog de versiones de API

**Story Points:** 8  
**Prioridad:** Should  
**Dependencias:** Todas las APIs

---

### HU-047: Sistema de backup automático

**Título:** Como admin, quiero que el sistema genere backups automáticos de la base de datos diariamente para prevenir pérdida de datos.

**Descripción:**  
Sistema automatizado de backups que genera snapshots diarios de PostgreSQL, los almacena en storage seguro (S3/GCS) con retención de 30 días y permite restauración.

**Requisitos Asociados:**
- **REQ-NF-066:** Sistema de backup automático diario
- **REQ-NF-065:** Recuperación ante desastres

**Constraints:**
- Backup diario a las 2:00 AM (timezone Chile)
- Retención: 30 días
- Storage: AWS S3 / Google Cloud Storage
- Backup incremental (delta)
- Encriptación AES-256
- Prueba de restauración mensual

**Entry Points:**
- **Cron:** Daily backup job (2 AM)
- **CLI:** `npm run db:backup` - Manual backup
- **API:** `/api/admin/backups` - Listar backups

**Context References:**
- **Scripts:** `scripts/backup-db.sh`
- **Storage:** AWS S3 bucket / GCS bucket
- **Tools:** `pg_dump`, `pg_restore`
- **Monitoring:** Backup success/failure alerts

**Criterios de Aceptación:**
1. **CA-1:** Cron ejecuta backup diario de PostgreSQL a las 2 AM
2. **CA-2:** Backup se sube a S3/GCS encriptado (AES-256)
3. **CA-3:** Retención: últimos 30 backups, los antiguos se eliminan automáticamente
4. **CA-4:** Admin puede listar backups disponibles desde panel
5. **CA-5:** Proceso de restauración documentado y probado mensualmente
6. **CA-6:** Alertas si backup falla o no se ejecuta
7. **CA-7:** Backup incluye: datos, schemas, stored procedures

**Story Points:** 5  
**Prioridad:** Must  
**Dependencias:** Infraestructura

---

### HU-048: Audit trail completo

**Título:** Como admin, quiero un registro completo de todas las acciones críticas del sistema para auditoría y compliance.

**Descripción:**  
Sistema de auditoría que registra todas las acciones críticas: CRUD de usuarios, proveedores, reservas, cambios de precios, con timestamp, usuario, acción y datos before/after.

**Requisitos Asociados:**
- **REQ-NF-062:** Sistema de auditoría de acceso a datos
- **REQ-NF-067:** Logs de seguridad

**Constraints:**
- Tabla `audit_logs` con particionamiento mensual
- Retención: 24 meses
- Campos: timestamp, userId, action, entityType, entityId, before, after, ip
- Acciones auditadas: CREATE, UPDATE, DELETE en tablas críticas
- Solo lectura para no-admins
- Export a CSV para compliance

**Entry Points:**
- **UI:** `/admin/audit-logs` - Visualización de logs
- **API:** `GET /api/admin/audit-logs?filter=...`
- **Middleware:** `AuditMiddleware` (intercepta acciones)

**Context References:**
- **Modules:** `backend/src/audit`
- **Tables:** `audit_logs` (partitioned)
- **Middleware:** `AuditInterceptor`
- **Components:** `AuditLogViewer`, `AuditLogFilter`

**Criterios de Aceptación:**
1. **CA-1:** Sistema registra: creación, edición, eliminación de usuarios, proveedores, reservas
2. **CA-2:** Log incluye: timestamp, usuario (quien hizo), acción, entidad afectada
3. **CA-3:** Para UPDATE: guarda valores before y after (diff)
4. **CA-4:** Admin puede filtrar logs: por usuario, acción, entidad, fecha
5. **CA-5:** Búsqueda full-text en logs
6. **CA-6:** Export logs a CSV para auditorías externas
7. **CA-7:** Logs inmutables (solo insert, no update/delete)

**Story Points:** 8  
**Prioridad:** Should  
**Dependencias:** HU-028

---

**Documento actualizado por:** GitHub Copilot  
**Fecha:** 20 de octubre de 2025  
**Proyecto:** Alto Carwash - Plataforma Agregadora de Servicios de Autolavado  
**Versión:** 3.0 (Ampliada con 18 HUs nuevas para cobertura 90%+)  
**Total de Historias:** 48 (30 originales + 18 nuevas)  
**Total de Épicas:** 8  
**Total de Puntos:** 354  
**Cobertura de Requerimientos:** 90.2% (74/82 requerimientos)
