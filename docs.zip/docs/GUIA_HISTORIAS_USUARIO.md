# 📖 Guía de Uso - Historias de Usuario Alto Carwash

## Propósito del Documento

Este documento sirve como **especificación técnica completa** para el desarrollo de Alto Carwash. Cada historia de usuario contiene toda la información necesaria para:

- 📋 **Planificación:** Story points, prioridades y dependencias
- 💻 **Desarrollo:** Entry points, context references y arquitectura
- ✅ **Testing:** Criterios de aceptación testables y escenarios
- 📊 **Seguimiento:** Relaciones con requisitos y casos de uso

---

## Estructura del Documento

### 1. Resumen Ejecutivo
- Visión general de las 30 historias de usuario
- Distribución por épicas (8 épicas estratégicas)
- Total de story points: 210

### 2. Arquitectura y Contexto Técnico
- Stack tecnológico completo (NestJS, Next.js, PostgreSQL, etc.)
- Módulos del sistema
- Modelos de datos clave (Prisma schemas)

### 3. Requisitos del Sistema
- **Requisitos Funcionales (REQ-FUNC):** 20+ requisitos
- **Requisitos No Funcionales (REQ-NF):** 15+ requisitos
  - Performance, Seguridad, Escalabilidad, Confiabilidad

### 4. Historias de Usuario Detalladas (30 HUs)
Cada historia incluye:
- ✅ **Título:** Como [rol], quiero [acción] para [beneficio]
- ✅ **Descripción:** Contexto detallado
- ✅ **Requisitos Asociados:** REQ-FUNC y REQ-NF
- ✅ **Constraints:** Restricciones técnicas y de negocio
- ✅ **Entry Points:** UI, API, Webhooks
- ✅ **Context References:** Módulos, servicios, tablas, componentes
- ✅ **Escenarios:** Precondiciones, flujo principal, alternos, postcondiciones
- ✅ **Criterios de Aceptación:** 3-6 criterios testables
- ✅ **Story Points:** Escala Fibonacci (1, 2, 3, 5, 8, 13)
- ✅ **Prioridad:** Must/Should/Could/Won't
- ✅ **Dependencias:** Otras HUs requeridas
- ✅ **Relación con Casos de Uso:** Include/Extend

### 5. Épicas (8 épicas)
- **EPI-01:** Gestión de Usuarios (27 pts)
- **EPI-02:** Búsqueda y Descubrimiento (21 pts)
- **EPI-03:** Comparación y Evaluación (13 pts)
- **EPI-04:** Reseñas y Reputación (13 pts)
- **EPI-05:** Gestión de Reservas (22 pts)
- **EPI-06:** IA y Agregación (26 pts)
- **EPI-07:** Portal de Proveedores (47 pts)
- **EPI-08:** Administración (34 pts)

### 6. Matrices de Trazabilidad
- Matriz de dependencias entre HUs
- Matriz de historias por rol
- Matriz de prioridades
- Matriz de complejidad técnica

### 7. Diagramas
- Customer Journey
- Provider Journey
- Arquitectura del Sistema

---

## Cómo Usar Este Documento

### Para Product Owners
1. **Planificación de Sprints:**
   - Usa la matriz de prioridades (Must > Should > Could)
   - Revisa dependencias entre historias
   - Considera la complejidad (story points)

2. **Definición de Alcance:**
   - MVP: Historias "Must Have" = 138 puntos
   - V1.0: + "Should Have" = 192 puntos
   - V1.1: + "Could Have" = 210 puntos

### Para Desarrolladores
1. **Implementación:**
   - Lee **Entry Points** para saber dónde trabajar
   - Revisa **Context References** para módulos/servicios relacionados
   - Consulta **Constraints** para restricciones técnicas

2. **Escenarios:**
   - Implementa el **Flujo Principal** primero
   - Luego maneja **Escenarios Alternos** (EA-1, EA-2, etc.)
   - Verifica **Precondiciones** y **Postcondiciones**

3. **Código:**
   ```typescript
   // Ejemplo: HU-005 (Búsqueda)
   // Entry Point: GET /api/search
   // Context: backend/src/search/search.service.ts
   // Tabla: providers (latitude, longitude)
   ```

### Para QA/Testers
1. **Criterios de Aceptación:**
   - Cada CA-X es un test case
   - Formato: CA-1, CA-2, CA-3...
   - Todos deben pasar para marcar HU como completa

2. **Escenarios de Prueba:**
   - **Happy Path:** Flujo Principal
   - **Edge Cases:** Escenarios Alternos (EA-1, EA-2, etc.)
   - **Validaciones:** Verificar constraints y requisitos

3. **Ejemplo de Test Plan:**
   ```
   HU-013: Reserva de servicio
   - ✅ CA-1: Calendario muestra horarios disponibles
   - ✅ CA-2: Prevención de doble-booking
   - ✅ CA-3: Creación de registro en BD
   - ✅ CA-4: Envío de emails
   - ✅ EA-3: Race condition manejado
   ```

### Para Arquitectos
1. **Diseño del Sistema:**
   - Usa diagramas de arquitectura
   - Revisa **Context References** para entender módulos
   - Consulta requisitos no funcionales (REQ-NF)

2. **Decisiones Técnicas:**
   - Performance: HU-005 (< 2s), HU-013 (< 3s)
   - Escalabilidad: HU-013 (100 reservas concurrentes)
   - Seguridad: HU-001 (OWASP), HU-002 (JWT)

---

## Convenciones y Nomenclatura

### IDs y Referencias
- **HU-XXX:** Historia de Usuario (001-030)
- **EPI-XX:** Épica (01-08)
- **REQ-FUNC-XXX:** Requisito Funcional
- **REQ-NF-XXX:** Requisito No Funcional
- **UC-XXX:** Caso de Uso
- **CA-X:** Criterio de Aceptación
- **EA-X:** Escenario Alterno

### Story Points (Fibonacci)
- **1-2 pts:** Tareas simples (CRUD básico)
- **3 pts:** Historias estándar (validaciones múltiples)
- **5 pts:** Complejidad media (integraciones simples)
- **8 pts:** Complejidad alta (geolocalización, APIs externas)
- **13 pts:** Muy alta complejidad (IA, scraping, analytics)

### Prioridades (MoSCoW)
- **Must Have:** Crítico para MVP (66% del total)
- **Should Have:** Importante para V1.0 (26% del total)
- **Could Have:** Nice to have para V1.1 (8% del total)
- **Won't Have:** Fuera de scope actual (0% en este doc)

---

## Historias Modificadas (Versión 2.0)

Las siguientes historias han sido expandidas con formato completo:

✅ **HU-001:** Registro de usuario (5 pts)
- Agregados: Requisitos, Constraints, Entry Points, Context References, Escenarios completos (8 alternos), Casos de uso

✅ **HU-002:** Inicio de sesión (3 pts)
- Agregados: 6 Escenarios alternos (OAuth, Biometría, Remember Me), Requisitos de seguridad, Casos de uso

✅ **HU-005:** Búsqueda por ubicación (8 pts)
- Agregados: 7 Escenarios alternos, Consultas SQL espaciales, Integración Google Maps, Casos de uso

✅ **HU-013:** Reserva de servicio (8 pts)
- Agregados: 8 Escenarios alternos, Manejo de concurrencia, Locks transaccionales, QR generation, Casos de uso

✅ **HU-017:** Recomendaciones con IA (13 pts)
- Agregados: Integración OpenAI, Algoritmos de relevancia, Caching Redis, Fallbacks, Casos de uso

✅ **HU-030:** Scraping y agregación (13 pts)
- Agregados: 5 Fases completas, Google Maps + Yapo scrapers, Normalización, Deduplicación, Casos de uso

**Pendientes:** Las otras 24 historias mantienen el formato original pero pueden expandirse siguiendo el mismo patrón.

---

## Flujo de Trabajo Recomendado

### Sprint Planning
1. **Selección de Historias:**
   - Revisar matriz de prioridades
   - Verificar dependencias (matriz de dependencias)
   - Calcular capacity vs story points

2. **Refinamiento:**
   - Leer historia completa
   - Aclarar dudas en Constraints y Requisitos
   - Validar Entry Points con arquitectura actual

### Durante el Desarrollo
1. **Inicio:**
   - [ ] Leer Precondiciones
   - [ ] Identificar módulos en Context References
   - [ ] Revisar Constraints técnicos

2. **Implementación:**
   - [ ] Implementar Flujo Principal
   - [ ] Manejar Escenarios Alternos
   - [ ] Cumplir Requisitos (REQ-FUNC, REQ-NF)

3. **Testing:**
   - [ ] Verificar todos los Criterios de Aceptación
   - [ ] Probar Escenarios Alternos
   - [ ] Validar Postcondiciones

### Sprint Review
- Demostrar cumplimiento de Criterios de Aceptación
- Mostrar manejo de Escenarios Alternos clave
- Validar Postcondiciones del sistema

---

## Ejemplos de Uso

### Ejemplo 1: Planificación de Sprint 1
**Objetivo:** Implementar MVP de autenticación y búsqueda básica

**Historias Seleccionadas:**
- HU-001 (5 pts): Registro ✅ Must Have
- HU-002 (3 pts): Login ✅ Must Have
- HU-005 (8 pts): Búsqueda ubicación ✅ Must Have
- HU-009 (5 pts): Detalles proveedor ✅ Must Have
**Total:** 21 puntos

**Dependencias Validadas:**
- HU-002 depende de HU-001 ✅
- HU-009 depende de HU-005 ✅

**Módulos a Implementar:**
- `backend/src/auth/`
- `backend/src/users/`
- `backend/src/search/`
- `backend/src/providers/`
- `frontend/src/app/sign-up/`
- `frontend/src/app/sign-in/`
- `frontend/src/app/search/`

### Ejemplo 2: Implementación de HU-013 (Reservas)
**Desarrollador Backend:**
1. Lee Entry Points: `POST /api/bookings`
2. Revisa Context: `backend/src/bookings/bookings.service.ts`
3. Verifica Constraints: "Máximo 3 reservas activas"
4. Implementa Flujo Principal: Pasos 1-21
5. Maneja EA-3: Race condition con locks

**Código:**
```typescript
// backend/src/bookings/bookings.service.ts
async createBooking(data: CreateBookingDto) {
  // Constraint: Máximo 3 reservas activas
  const activeBookings = await this.checkActiveBookings(data.userId);
  if (activeBookings >= 3) {
    throw new TooManyRequestsException('Maximum active bookings reached');
  }

  // EA-3: Prevención de race condition con lock
  return await this.prisma.$transaction(async (tx) => {
    const conflictingBooking = await tx.booking.findFirst({
      where: {
        providerId: data.providerId,
        status: { notIn: ['CANCELLED', 'COMPLETED'] },
        startTime: { lte: endTime },
        endTime: { gte: startTime }
      },
      // Row-level lock
      lock: 'pessimistic_write'
    });

    if (conflictingBooking) {
      throw new ConflictException('Time slot no longer available');
    }

    // Crear reserva...
  });
}
```

**QA Tester:**
1. Verifica CA-2: "Prevención de doble-booking con 100 reservas simultáneas"
2. Prueba EA-3: Simular race condition
3. Valida Postcondiciones: Slot bloqueado, emails enviados

---

## Actualizaciones del Documento

**Versión 2.0 (20 Oct 2025):**
- ✅ Agregadas secciones: Requisitos, Arquitectura, Matrices
- ✅ Expandidas 6 HUs clave con formato completo
- ✅ Agregados diagramas: Customer Journey, Provider Journey, Arquitectura
- ✅ Incluidas matrices de trazabilidad
- ✅ Definición de "Done" actualizada

**Próximas Mejoras:**
- [ ] Expandir las 24 HUs restantes con formato completo
- [ ] Agregar diagramas de secuencia por HU compleja
- [ ] Incluir ejemplos de código por HU
- [ ] Documentar APIs (OpenAPI/Swagger)

---

## Contacto y Contribuciones

Para preguntas sobre este documento:
- **Product Owner:** Revisar prioridades y alcance
- **Tech Lead:** Consultas sobre arquitectura y decisiones técnicas
- **Scrum Master:** Planificación de sprints y estimaciones

**Repositorio:** `alto-carwash-mejorado`  
**Ubicación:** `/docs/historias_de_usuario.md`  
**Última actualización:** 20 de octubre de 2025
